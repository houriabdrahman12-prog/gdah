'use strict';
const db = require('../src/db');
db.open();
const applied = db.migrate();
db.seed();
console.log(applied.length ? `Applied migrations: ${applied.join(', ')}` : 'Database is up to date.');
db.close();
