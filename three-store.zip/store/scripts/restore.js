'use strict';
// Usage: node scripts/restore.js path/to/backup.db     (STOP the server first!)
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const config = require('../src/config');
const src = process.argv[2];
if (!src || !fs.existsSync(src)) { console.error('Usage: node scripts/restore.js <backup-file.db>'); process.exit(1); }
// 1) verify the backup is a healthy SQLite database with our schema
const t = new DatabaseSync(path.resolve(src), { readOnly: true });
const ok = t.prepare('PRAGMA integrity_check').get();
const hasOrders = t.prepare("SELECT name FROM sqlite_master WHERE name='orders'").get();
t.close();
if (Object.values(ok)[0] !== 'ok' || !hasOrders) { console.error('This file is not a valid backup of the store database.'); process.exit(1); }
// 2) keep the current database aside, never overwrite blindly
fs.mkdirSync(config.BACKUP_DIR, { recursive: true });
if (fs.existsSync(config.DB_FILE)) {
  const aside = path.join(config.BACKUP_DIR, `before-restore-${new Date().toISOString().replace(/[:.]/g, '-')}.db`);
  fs.copyFileSync(config.DB_FILE, aside); console.log('Current database saved as ' + aside);
}
for (const ext of ['-wal', '-shm']) { try { fs.unlinkSync(config.DB_FILE + ext); } catch {} }
fs.copyFileSync(path.resolve(src), config.DB_FILE);
console.log('Restored. Start the server again.');
