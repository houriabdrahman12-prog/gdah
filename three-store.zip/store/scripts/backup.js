'use strict';
const path = require('node:path');
const config = require('../src/config');
const db = require('../src/db');
db.open();
const target = process.argv[2] || path.join(config.BACKUP_DIR, `manual-${db.stamp()}.db`);
db.backupTo(path.resolve(target));
console.log('Backup written to ' + path.resolve(target));
db.close();
