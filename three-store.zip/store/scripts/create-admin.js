'use strict';
// Usage:  node scripts/create-admin.js            (interactive, password is hidden)
//         ADMIN_USERNAME=owner ADMIN_PASSWORD='...' node scripts/create-admin.js   (non-interactive, e.g. on a host shell)
const readline = require('node:readline');
const db = require('../src/db');
const sec = require('../src/security');

function ask(q, hidden) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    if (hidden) { rl._writeToOutput = (s) => { if (s.includes(q)) rl.output.write(s); else rl.output.write(''); }; }
    rl.question(q, (a) => { rl.close(); if (hidden) process.stdout.write('\n'); resolve(a); });
  });
}

(async () => {
  db.open(); db.migrate(); db.seed();
  let username = process.env.ADMIN_USERNAME, password = process.env.ADMIN_PASSWORD;
  if (!username) username = (await ask('Admin username: ')).trim();
  if (!password) { password = await ask('Password (min 12 chars, 3 character types): ', true); const again = await ask('Repeat password: ', true); if (again !== password) { console.error('Passwords do not match.'); process.exit(1); } }
  if (!/^[\w.\-]{3,40}$/.test(username)) { console.error('Invalid username (3-40 letters/digits/._-).'); process.exit(1); }
  const prob = sec.passwordProblem(password);
  if (prob) { console.error('Weak password: ' + prob); process.exit(1); }
  const d = db.get();
  const existing = d.prepare('SELECT id FROM admins WHERE username=?').get(username);
  if (existing) {
    if (process.env.ADMIN_RESET !== '1') { console.error(`User "${username}" already exists. Set ADMIN_RESET=1 to reset its password.`); process.exit(1); }
    d.prepare('UPDATE admins SET password_hash=?, active=1 WHERE id=?').run(sec.hashPassword(password), existing.id);
    d.prepare('DELETE FROM admin_sessions WHERE admin_id=?').run(existing.id);
    console.log(`Password reset for "${username}".`);
  } else {
    const first = !d.prepare('SELECT 1 FROM admins').get();
    d.prepare('INSERT INTO admins(username,password_hash,role) VALUES (?,?,?)').run(username, sec.hashPassword(password), first || process.env.ADMIN_ROLE === 'owner' ? 'owner' : 'staff');
    console.log(`Administrator "${username}" created${first ? ' (owner)' : ''}.`);
  }
  db.close();
})();
