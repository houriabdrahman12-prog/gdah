# Installation (beginner friendly)

## 1. Install Node.js
Download the **LTS** version 22 (or newer) from https://nodejs.org and install it. Check in a terminal:
```bash
node -v      # v22.13.0 or higher
```

## 2. Get the project
Unzip the `store` folder somewhere, e.g. `C:\store` or `~/store`, and open a terminal **inside that folder**.

## 3. (Optional) install the image optimiser
```bash
npm install          # installs optional "sharp"; if it fails, ignore it — the store still works
```
Without `sharp` photos are stored exactly as uploaded (no resize/WebP). Everything else is identical.

## 4. Create the first administrator (no default password exists)
```bash
npm run create-admin
```
Type a username (letters/digits, e.g. `owner`) and a password with **12+ characters and 3 of: lowercase, uppercase, digits, symbols**. This also creates the database in `./data/store.db`.
To reset a forgotten password later: `ADMIN_USERNAME=owner ADMIN_PASSWORD='NewStrong!Pass1' ADMIN_RESET=1 node scripts/create-admin.js` (on Windows PowerShell: `$env:ADMIN_USERNAME='owner'; $env:ADMIN_PASSWORD='...'; $env:ADMIN_RESET='1'; node scripts/create-admin.js`).

## 5. Start
```bash
npm start
```
Store: http://localhost:3000 · Admin: http://localhost:3000/admin

## 6. Test (optional but recommended)
```bash
npm test
```

## Configuration
Copy `.env.example` to `.env` to change the port, data folder or `SITE_URL`. The database, uploaded photos and backups live in `DATA_DIR` (default `./data`) — **this folder is your store; back it up** (see BACKUP_AND_RESTORE.md).

## Troubleshooting
| Problem | Fix |
|---|---|
| `node: command not found` | Install Node.js 22+ and reopen the terminal |
| `Cannot find module 'node:sqlite'` | Node is too old — need ≥ 22.13 |
| `EADDRINUSE` | Port 3000 is used: `PORT=3001 npm start` |
| Can't log in / locked out | 5 wrong tries lock that username for 15 min (restart the server to clear), or reset the password (step 4) |
| Photos upload fails "نوع الملف غير مسموح" | Only JPG, PNG, WebP (and MP4/WebM for the hero video) are accepted; max 8MB images / 30MB video |
| `ExperimentalWarning: SQLite` | Harmless — `node:sqlite` is still marked experimental in Node 22 |
