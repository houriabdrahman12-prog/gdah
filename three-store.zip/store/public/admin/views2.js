/* لوحة التحكم — الشاشات (2): التصنيفات، الوسائط، التوصيل، الصفحة الرئيسية، التصميم، القوائم، الصفحات، الإعدادات، الحساب، السجل، النسخ */
(function () {
  'use strict';
  var A = window.A, h = A.h, api = A.api, R = A.ROUTES, money = A.money, dt = A.dt, toast = A.toast, fail = A.fail;

  /* ================= الفئات / المقاسات / الألوان ================= */
  R.taxonomy = function (v) {
    v.appendChild(h('h1', null, 'الفئات والمقاسات والألوان'));
    v.appendChild(h('p', { class: 'hint' }, 'هذه القوائم تتحكم في فلاتر المتجر وفي خيارات المنتجات. إخفاء عنصر يزيله من الفلاتر فقط.'));
    var kinds = [['categories', 'الفئات', false], ['sizes', 'المقاسات', false], ['colors', 'الألوان', true]];
    var tabs = h('div', { class: 'tabs', role: 'tablist' }), body = h('div'); var cur = 'categories';
    function draw() {
      A.clear(tabs); kinds.forEach(function (k) { tabs.appendChild(h('button', { type: 'button', role: 'tab', class: cur === k[0] ? 'on' : '', onclick: function () { cur = k[0]; draw(); } }, k[1])); });
      A.clear(body); var kind = kinds.filter(function (k) { return k[0] === cur; })[0];
      return api('GET', '/' + cur).then(function (r) {
        var items = r.items;
        var rows = items.map(function (it, i) {
          var name = h('input', { type: 'text', value: it.name, maxlength: 60 }), hex = kind[2] ? h('input', { type: 'color', value: it.hex }) : null, vis = h('input', { type: 'checkbox', checked: !!it.visible, 'aria-label': 'ظاهر' });
          return h('tr', null, h('td', null, name), kind[2] ? h('td', null, hex) : null, h('td', null, vis), h('td', null, h('div', { class: 'row' },
            h('button', { class: 'btn sm', type: 'button', disabled: i === 0, onclick: function () { reorder(items, i, -1); } }, '↑'), h('button', { class: 'btn sm', type: 'button', disabled: i === items.length - 1, onclick: function () { reorder(items, i, 1); } }, '↓'),
            h('button', { class: 'btn sm primary', type: 'button', onclick: function () { api('PUT', '/' + cur + '/' + it.id, { name: name.value, hex: hex ? hex.value : undefined, visible: vis.checked }).then(function () { toast('تم الحفظ'); }).catch(fail); } }, 'حفظ'),
            h('button', { class: 'btn sm danger', type: 'button', onclick: function () { if (A.sure('حذف «' + it.name + '»؟')) { api('DELETE', '/' + cur + '/' + it.id + '?confirm=1').then(function () { draw(); }).catch(fail); } } }, 'حذف'))));
        });
        function reorder(list, i, d) { var a = list.slice(); a.splice(i + d, 0, a.splice(i, 1)[0]); api('PUT', '/' + cur + '/order', { ids: a.map(function (x) { return x.id; }) }).then(draw).catch(fail); }
        body.appendChild(h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, h('th', null, 'الاسم'), kind[2] ? h('th', null, 'اللون') : null, h('th', null, 'ظاهر'), h('th', null, ''))), h('tbody', null, rows))));
        var nn = h('input', { type: 'text', placeholder: 'اسم جديد', maxlength: 60 }), nh = kind[2] ? h('input', { type: 'color', value: '#000000' }) : null;
        body.appendChild(h('div', { class: 'row card', style: 'margin-top:1rem' }, h('div', { class: 'grow' }, nn), nh, h('button', { class: 'btn primary', type: 'button', onclick: function () { api('POST', '/' + cur, { name: nn.value, hex: nh ? nh.value : undefined }).then(function () { draw(); }).catch(fail); } }, 'إضافة')));
      }).catch(fail);
    }
    v.appendChild(tabs); v.appendChild(body); return draw();
  };

  /* ================= الوسائط ================= */
  R.media = function (v) {
    v.appendChild(h('div', { class: 'row spread' }, h('h1', null, 'الوسائط')));
    var grid = h('div', { class: 'media-grid' }), file = h('input', { type: 'file', multiple: true, accept: 'image/jpeg,image/png,image/webp,image/x-icon,video/mp4,video/webm', hidden: true });
    file.addEventListener('change', function () { if (!file.files.length) { return; } A.uploadFiles(file.files, true).then(function () { toast('تم الرفع'); load(); }).catch(fail); file.value = ''; });
    v.appendChild(h('div', { class: 'card row' }, h('button', { class: 'btn primary', type: 'button', onclick: function () { file.click(); } }, 'رفع ملفات'), h('span', { class: 'hint' }, 'صور JPG/PNG/WebP (حتى 8MB) وفيديو MP4/WebM (حتى 30MB). يُتحقق من نوع الملف الحقيقي.'), file));
    v.appendChild(grid);
    function load() {
      return api('GET', '/media').then(function (r) {
        A.clear(grid); if (!r.items.length) { grid.appendChild(h('div', { class: 'empty' }, 'لا توجد ملفات')); }
        r.items.forEach(function (x) {
          grid.appendChild(h('div', { class: 'media-item' }, x.kind === 'video' ? h('video', { src: x.url, muted: true, preload: 'metadata' }) : h('img', { src: x.thumb_url, alt: '' }), h('small', null, x.original_name || x.file),
            h('div', { class: 'row', style: 'padding:.3rem' }, h('button', { class: 'btn sm', type: 'button', onclick: function () { navigator.clipboard && navigator.clipboard.writeText(location.origin + x.url).then(function () { toast('تم نسخ الرابط'); }); } }, 'نسخ'),
              h('button', { class: 'btn sm danger', type: 'button', onclick: function () { if (A.sure('حذف الملف؟')) { api('DELETE', '/media/' + x.id + '?confirm=1').then(load).catch(fail); } } }, 'حذف'))));
        });
      });
    }
    return load();
  };

  /* ================= التوصيل ================= */
  R.delivery = function (v) {
    v.appendChild(h('h1', null, 'التوصيل والأسعار'));
    return Promise.all([api('GET', '/settings'), api('GET', '/wilayas')]).then(function (res) {
      var s = res[0].delivery, ws = res[1].items;
      v.appendChild(h('div', { class: 'warnbox' }, 'أسعار التوصيل الحالية قيم افتراضية تقديرية وضعناها كبداية فقط. عدّلها حسب تعرفة شركة التوصيل التي تعملون معها قبل نشر المتجر.'));
      var f = A.form([{ k: 'home_enabled', label: 'تفعيل التوصيل إلى المنزل', type: 'bool' }, { k: 'desk_enabled', label: 'تفعيل التوصيل إلى مكتب التسليم', type: 'bool' }, { k: 'cod_enabled', label: 'استقبال الطلبات (الدفع عند الاستلام)', type: 'bool', hint: 'إيقافه يمنع تسجيل أي طلب جديد' },
        { k: 'free_threshold', label: 'حد التوصيل المجاني (د.ج)', type: 'int', min: 0, hint: '0 = لا يوجد توصيل مجاني' }, { k: 'info', label: 'نص معلومات التوصيل (يظهر في صفحة المنتج)', type: 'textarea', rows: 3, wide: true }], s);
      v.appendChild(h('div', { class: 'card' }, h('h2', null, 'الخيارات العامة'), f.el, A.saveBar('حفظ الخيارات', function () { return api('PUT', '/settings/delivery', f.get()).then(function () { toast('تم الحفظ'); }); })));
      var rows = ws.map(function (w) { w._h = h('input', { type: 'number', value: w.fee_home, min: 0, inputmode: 'numeric' }); w._d = h('input', { type: 'number', value: w.fee_desk, min: 0, inputmode: 'numeric' }); w._e = h('input', { type: 'checkbox', checked: !!w.enabled, 'aria-label': 'مفعّلة' });
        return h('tr', null, h('td', null, String(w.code).padStart(2, '0')), h('td', null, w.name_ar, h('div', { class: 'hint' }, w.name_fr)), h('td', null, w._h), h('td', null, w._d), h('td', null, w._e)); });
      var allH = h('input', { type: 'number', min: 0, placeholder: 'للمنزل' }), allD = h('input', { type: 'number', min: 0, placeholder: 'للمكتب' });
      v.appendChild(h('div', { class: 'card' }, h('h2', null, 'أسعار الولايات (58)'),
        h('div', { class: 'row', style: 'margin-bottom:.8rem' }, h('span', null, 'تطبيق سعر موحّد على الكل:'), h('div', { style: 'width:110px' }, allH), h('div', { style: 'width:110px' }, allD), h('button', { class: 'btn sm', type: 'button', onclick: function () { ws.forEach(function (w) { if (allH.value !== '') { w._h.value = allH.value; } if (allD.value !== '') { w._d.value = allD.value; } }); } }, 'تطبيق (لم يُحفظ بعد)')),
        h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, h('th', null, '#'), h('th', null, 'الولاية'), h('th', null, 'إلى المنزل (د.ج)'), h('th', null, 'إلى المكتب (د.ج)'), h('th', null, 'مفعّلة'))), h('tbody', null, rows))),
        h('div', { class: 'row end', style: 'margin-top:1rem' }, A.saveBar('حفظ أسعار الولايات', function () {
          return api('PUT', '/wilayas', { items: ws.map(function (w) { return { code: w.code, fee_home: parseInt(w._h.value, 10) || 0, fee_desk: parseInt(w._d.value, 10) || 0, enabled: w._e.checked }; }) }).then(function () { toast('تم الحفظ (أُخذت نسخة احتياطية تلقائياً)'); });
        }))));
    });
  };

  /* ================= الصفحة الرئيسية ================= */
  var SECDEFS = {
    hero: [{ k: 'giant', label: 'الكلمة العملاقة', type: 'text', max: 40, dir: 'ltr' }, { k: 'kicker', label: 'سطر صغير', type: 'text', dir: 'ltr' }, { k: 'title', label: 'العنوان الرئيسي', type: 'text', max: 200, wide: true },
      { k: 'button_text', label: 'نص الزر', type: 'text' }, { k: 'button_url', label: 'وجهة الزر', type: 'text', hint: 'مثال: /shop أو /p/about', dir: 'ltr' },
      { k: 'media_type', label: 'نوع الوسائط', type: 'select', opts: [['logo', 'الشعار (الأصلي)'], ['image', 'صورة'], ['video', 'فيديو'], ['none', 'بدون']] }, { k: 'media', label: 'الصورة / الفيديو', type: 'image', video: true }, { k: 'video_poster', label: 'صورة غلاف الفيديو', type: 'image' }],
    marquee: [{ k: 'text', label: 'النص المتحرك', type: 'text', max: 200, wide: true }],
    story: [{ k: 'label', label: 'التسمية الصغيرة', type: 'text' }, { k: 'heading', label: 'العنوان', type: 'text', wide: true }, { k: 'paragraphs', label: 'الفقرات (سطر لكل فقرة)', type: 'lines', rows: 6, wide: true }, { k: 'image', label: 'الصورة', type: 'image' }, { k: 'caption', label: 'تعليق الصورة', type: 'text' }, { k: 'stats', label: 'الأرقام', type: 'stats', wide: true }],
    products: [{ k: 'label', label: 'التسمية الصغيرة', type: 'text' }, { k: 'heading', label: 'العنوان', type: 'text', wide: true }, { k: 'source', label: 'مصدر المنتجات', type: 'select', opts: [['featured', 'المنتجات المميزة'], ['new', 'وصل حديثاً'], ['sale', 'التخفيضات'], ['category', 'فئة محددة'], ['all', 'الأحدث']] }, { k: 'category_id', label: 'رقم الفئة (عند اختيار فئة)', type: 'select', opts: [] }, { k: 'limit', label: 'عدد المنتجات (1-12)', type: 'int', min: 1, max: 12 }, { k: 'button_text', label: 'نص الزر', type: 'text' }, { k: 'button_url', label: 'وجهة الزر', type: 'text', dir: 'ltr' }],
    banner: [{ k: 'image', label: 'صورة الخلفية', type: 'image' }, { k: 'title', label: 'العنوان', type: 'text' }, { k: 'text', label: 'النص', type: 'textarea', rows: 3, wide: true }, { k: 'button_text', label: 'نص الزر', type: 'text' }, { k: 'button_url', label: 'وجهة الزر', type: 'text', dir: 'ltr' }, { k: 'align', label: 'المحاذاة', type: 'select', opts: [['center', 'وسط'], ['start', 'بداية'], ['end', 'نهاية']] }],
    richtext: [{ k: 'label', label: 'التسمية الصغيرة', type: 'text' }, { k: 'heading', label: 'العنوان', type: 'text', wide: true }, { k: 'body', label: 'المحتوى', type: 'textarea', rows: 8, wide: true, hint: '# عنوان، - قائمة، **غامق**' }],
    manifesto: [{ k: 'label', label: 'التسمية الصغيرة', type: 'text' }, { k: 'line1', label: 'السطر الأول', type: 'text' }, { k: 'line2', label: 'السطر الثاني (مفرّغ)', type: 'text' }],
    finale: [{ k: 'label', label: 'التسمية الصغيرة', type: 'text' }, { k: 'heading', label: 'العنوان', type: 'text', wide: true }, { k: 'image', label: 'الشعار / الصورة', type: 'image' }, { k: 'button_text', label: 'نص الزر', type: 'text' }, { k: 'button_url', label: 'وجهة الزر', type: 'text', dir: 'ltr' }]
  };
  var SECNAME = { hero: 'الواجهة', marquee: 'شريط متحرك', story: 'القصة', products: 'منتجات', banner: 'بانر ترويجي', richtext: 'نص', manifesto: 'البيان', finale: 'الخاتمة' };
  R.homepage = function (v) {
    v.appendChild(h('div', { class: 'row spread' }, h('h1', null, 'الصفحة الرئيسية'), h('a', { class: 'btn', href: '/', target: '_blank', rel: 'noopener' }, 'معاينة الموقع')));
    v.appendChild(h('p', { class: 'hint' }, 'رتّب الأقسام بالأسهم، أخفِ أو أظهر أي قسم، وعدّل محتواه ثم احفظ. التغييرات تظهر مباشرة في الموقع.'));
    var box = h('div');
    function draw() {
      return Promise.all([api('GET', '/sections'), api('GET', '/categories')]).then(function (res) {
        var items = res[0].items, core = res[0].core, cats = res[1].items; A.clear(box);
        items.forEach(function (s, i) {
          var defs = (SECDEFS[s.type] || []).map(function (d) { return d.k === 'category_id' ? Object.assign({}, d, { opts: [[0, '—']].concat(cats.map(function (c) { return [c.id, c.name]; })) }) : d; });
          var f = A.form(defs, s.data), body = h('div', { class: 'sec-body', hidden: true }, f.el), vis = h('input', { type: 'checkbox', checked: !!s.visible, 'aria-label': 'ظاهر' });
          var title = h('input', { type: 'text', value: s.title, maxlength: 60, 'aria-label': 'اسم داخلي' });
          function move(d) { var a = items.slice(); a.splice(i + d, 0, a.splice(i, 1)[0]); api('PUT', '/sections/order', { ids: a.map(function (x) { return x.id; }) }).then(draw).catch(fail); }
          box.appendChild(h('div', { class: 'sec-item' }, h('div', { class: 'sec-head' }, h('b', null, (i + 1) + '. ' + SECNAME[s.type]), h('div', { class: 'grow' }, title), h('label', { class: 'check' }, vis, 'ظاهر'),
            h('button', { class: 'btn sm', type: 'button', disabled: i === 0, onclick: function () { move(-1); }, 'aria-label': 'للأعلى' }, '↑'), h('button', { class: 'btn sm', type: 'button', disabled: i === items.length - 1, onclick: function () { move(1); }, 'aria-label': 'للأسفل' }, '↓'),
            h('button', { class: 'btn sm', type: 'button', onclick: function () { body.hidden = !body.hidden; } }, 'تعديل'),
            core.indexOf(s.type) === -1 ? h('button', { class: 'btn sm danger', type: 'button', onclick: function () { if (A.sure('حذف هذا القسم؟')) { api('DELETE', '/sections/' + s.id + '?confirm=1').then(draw).catch(fail); } } }, 'حذف') : null),
            h('div', null, body, (function () { body.appendChild(h('div', { class: 'row end' }, A.saveBar('حفظ القسم', function () { return api('PUT', '/sections/' + s.id, { data: f.get(), visible: vis.checked, title: title.value }).then(function () { toast('تم الحفظ'); }); }))); return null; })())));
          vis.addEventListener('change', function () { api('PUT', '/sections/' + s.id, { data: {}, visible: vis.checked }).then(function () { toast(vis.checked ? 'القسم ظاهر' : 'القسم مخفي'); }).catch(fail); });
        });
        var type = h('select', null, [['products', 'قسم منتجات'], ['banner', 'بانر ترويجي'], ['richtext', 'نص حر']].map(function (o) { return h('option', { value: o[0] }, o[1]); }));
        box.appendChild(h('div', { class: 'card row' }, h('span', null, 'إضافة قسم:'), h('div', { style: 'width:200px' }, type), h('button', { class: 'btn primary', type: 'button', onclick: function () { api('POST', '/sections', { type: type.value, title: SECNAME[type.value] }).then(draw).catch(fail); } }, 'إضافة')));
      });
    }
    v.appendChild(box); return draw();
  };

  /* ================= التصميم ================= */
  R.design = function (v) {
    v.appendChild(h('h1', null, 'التصميم والحركة'));
    return api('GET', '/settings').then(function (s) {
      var fonts = A.me().fonts.map(function (n) { return [n, n]; });
      var theme = A.form([{ k: 'bg', label: 'لون الخلفية', type: 'color' }, { k: 'bg_soft', label: 'خلفية ثانوية', type: 'color' }, { k: 'surface', label: 'لون البطاقات', type: 'color' }, { k: 'ink', label: 'لون النص', type: 'color' }, { k: 'ink_dim', label: 'نص خافت', type: 'color' }, { k: 'accent', label: 'لون التمييز (الأزرار)', type: 'color' }, { k: 'accent_ink', label: 'لون نص الأزرار', type: 'color' },
        { k: 'font_display', label: 'خط العناوين', type: 'select', opts: fonts }, { k: 'font_body', label: 'خط النص', type: 'select', opts: fonts }, { k: 'font_latin', label: 'خط اللاتينية', type: 'select', opts: fonts },
        { k: 'logo_size', label: 'حجم الشعار في الترويسة (24-120)', type: 'int', min: 24, max: 120 }, { k: 'base_font_size', label: 'حجم الخط الأساسي (13-22)', type: 'int', min: 13, max: 22 }], s.theme);
      v.appendChild(h('div', { class: 'card' }, h('h2', null, 'الألوان والخطوط'), theme.el, h('div', { class: 'row end' },
        h('button', { class: 'btn', type: 'button', onclick: function () { if (A.sure('استعادة الألوان والخطوط الافتراضية؟')) { api('PUT', '/settings/theme', { bg: '#000000', bg_soft: '#0a0a0a', surface: '#111111', ink: '#f5f5f5', ink_dim: '#9a9d9f', accent: '#f5f5f5', accent_ink: '#000000', font_display: 'Noto Kufi Arabic', font_body: 'IBM Plex Sans Arabic', font_latin: 'Archivo', logo_size: 40, base_font_size: 16 }).then(function () { toast('تمت الاستعادة'); A.route(); }).catch(fail); } } }, 'استعادة الافتراضي'),
        A.saveBar('حفظ', function () { return api('PUT', '/settings/theme', theme.get()).then(function () { toast('تم الحفظ — افتح الموقع للمعاينة'); }); }))));
      var br = A.form([{ k: 'logo', label: 'الشعار', type: 'image', hint: 'يظهر في الترويسة وفي قسم الواجهة (عند اختيار «الشعار»)' }, { k: 'favicon', label: 'أيقونة الموقع (Favicon)', type: 'image', hint: 'PNG/ICO مربّعة يُفضّل' }, { k: 'og_image', label: 'صورة المشاركة (واتساب/فيسبوك)', type: 'image' }], s.branding);
      v.appendChild(h('div', { class: 'card' }, h('h2', null, 'الشعار والأيقونة'), br.el, h('div', { class: 'row end' }, A.saveBar('حفظ', function () { return api('PUT', '/settings/branding', br.get()).then(function () { toast('تم الحفظ'); }); }))));
      var an = A.form([{ k: 'preloader', label: 'شاشة التحميل الافتتاحية (مرة كل جلسة)', type: 'bool' }, { k: 'cursor', label: 'المؤشر المخصص (سطح المكتب)', type: 'bool' }, { k: 'reveal', label: 'ظهور العناصر عند التمرير', type: 'bool' }, { k: 'words', label: 'كشف كلمات العناوين', type: 'bool' }, { k: 'parallax', label: 'البارالاكس وتكبير الشعار', type: 'bool' }, { k: 'marquee', label: 'الأشرطة المتحركة', type: 'bool' }, { k: 'elastic', label: 'الخط المرن', type: 'bool' }, { k: 'orbit', label: 'دوران المدار', type: 'bool' }, { k: 'hover', label: 'تأثيرات التحويم على المنتجات', type: 'bool' }], s.anim);
      v.appendChild(h('div', { class: 'card' }, h('h2', null, 'الحركة'), h('p', { class: 'hint' }, 'الزوّار الذين فعّلوا «تقليل الحركة» في أجهزتهم لا يرون الحركة مهما كانت هذه الإعدادات.'), an.el, h('div', { class: 'row end' }, A.saveBar('حفظ', function () { return api('PUT', '/settings/anim', an.get()).then(function () { toast('تم الحفظ'); }); }))));
    });
  };

  /* ================= القوائم ================= */
  R.nav = function (v) {
    v.appendChild(h('h1', null, 'القوائم'));
    return api('GET', '/nav').then(function (r) {
      var items = r.items.map(function (x) { return { location: x.location, label: x.label, url: x.url, visible: !!x.visible }; }); var box = h('div');
      function draw() {
        A.clear(box);
        [['header', 'قائمة الترويسة'], ['footer', 'قائمة التذييل']].forEach(function (loc) {
          var list = items.filter(function (x) { return x.location === loc[0]; });
          var tb = h('tbody', null, list.map(function (x) {
            var l = h('input', { type: 'text', value: x.label, maxlength: 40 }), u = h('input', { type: 'text', value: x.url, dir: 'ltr', maxlength: 300 }), vis = h('input', { type: 'checkbox', checked: x.visible, 'aria-label': 'ظاهر' });
            l.addEventListener('input', function () { x.label = l.value; }); u.addEventListener('input', function () { x.url = u.value; }); vis.addEventListener('change', function () { x.visible = vis.checked; });
            var idx = items.indexOf(x);
            function move(d) { var j = idx; do { j += d; } while (j >= 0 && j < items.length && items[j].location !== loc[0]); if (j < 0 || j >= items.length) { return; } var t = items[idx]; items[idx] = items[j]; items[j] = t; draw(); }
            return h('tr', null, h('td', null, l), h('td', null, u), h('td', null, vis), h('td', null, h('div', { class: 'row' }, h('button', { class: 'btn sm', type: 'button', onclick: function () { move(-1); }, 'aria-label': 'للأعلى' }, '↑'), h('button', { class: 'btn sm', type: 'button', onclick: function () { move(1); }, 'aria-label': 'للأسفل' }, '↓'), h('button', { class: 'btn sm danger', type: 'button', onclick: function () { items.splice(idx, 1); draw(); } }, 'حذف'))));
          }));
          box.appendChild(h('div', { class: 'card' }, h('h2', null, loc[1]), h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, h('th', null, 'النص'), h('th', null, 'الرابط'), h('th', null, 'ظاهر'), h('th', null, ''))), tb)),
            h('button', { class: 'btn sm', type: 'button', style: 'margin-top:.8rem', onclick: function () { items.push({ location: loc[0], label: 'رابط جديد', url: '/shop', visible: true }); draw(); } }, '+ إضافة رابط')));
        });
      }
      draw(); v.appendChild(box); v.appendChild(h('p', { class: 'hint' }, 'الروابط المقبولة: مسارات داخلية (/shop، /p/about، /#story) أو روابط https://.'));
      v.appendChild(A.saveBar('حفظ القوائم', function () { return api('PUT', '/nav', { items: items }).then(function () { toast('تم الحفظ'); }); }));
    });
  };

  /* ================= الصفحات ================= */
  R.pages = function (v, args) {
    if (args[0]) { return pageEditor(v, args[0]); }
    v.appendChild(h('div', { class: 'row spread' }, h('h1', null, 'الصفحات'), h('a', { class: 'btn primary', href: '#/pages/new' }, '+ صفحة جديدة')));
    return api('GET', '/pages').then(function (r) {
      v.appendChild(h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, h('th', null, 'العنوان'), h('th', null, 'الرابط'), h('th', null, 'الحالة'), h('th', null, ''))),
        h('tbody', null, r.items.map(function (p) { return h('tr', null, h('td', null, p.title, p.system ? h('span', { class: 'hint' }, ' (أساسية)') : null), h('td', { class: 'mono' }, '/p/' + p.slug), h('td', null, h('span', { class: 'pill ' + (p.published ? 's-published' : 's-draft') }, p.published ? 'منشورة' : 'غير منشورة')), h('td', null, h('a', { class: 'btn sm', href: '#/pages/' + p.id }, 'تعديل'))); })))));
    });
  };
  function pageEditor(v, id) {
    v.appendChild(h('p', null, h('a', { href: '#/pages' }, '→ الصفحات')));
    return (id === 'new' ? Promise.resolve({ title: '', content: '', published: 1, seo_title: '', seo_description: '', slug: '' }) : api('GET', '/pages').then(function (r) { return r.items.filter(function (x) { return x.id === +id; })[0]; })).then(function (p) {
      v.appendChild(h('h1', null, id === 'new' ? 'صفحة جديدة' : 'تعديل: ' + p.title));
      var f = A.form([{ k: 'title', label: 'العنوان', type: 'text', max: 120 }, { k: 'published', label: 'منشورة', type: 'bool' }, { k: 'content', label: 'المحتوى', type: 'textarea', rows: 14, wide: true, hint: 'تنسيق بسيط: # عنوان كبير، ## عنوان صغير، - عنصر قائمة، > اقتباس، **غامق**، [نص](/رابط)' }, { k: 'seo_title', label: 'عنوان SEO', type: 'text', max: 120 }, { k: 'seo_description', label: 'وصف SEO', type: 'text', max: 300 }], p);
      v.appendChild(h('div', { class: 'card' }, f.el, h('div', { class: 'row' }, A.saveBar('حفظ الصفحة', function () { return api(id === 'new' ? 'POST' : 'PUT', '/pages' + (id === 'new' ? '' : '/' + id), f.get()).then(function (r) { toast('تم الحفظ'); if (id === 'new') { location.hash = '#/pages/' + r.id; } }); }),
        id !== 'new' ? h('a', { class: 'btn', href: '/p/' + p.slug, target: '_blank', rel: 'noopener' }, 'عرض') : null,
        id !== 'new' && !p.system ? h('button', { class: 'btn danger', type: 'button', onclick: function () { if (A.sure('حذف الصفحة؟')) { api('DELETE', '/pages/' + id + '?confirm=1').then(function () { location.hash = '#/pages'; }).catch(fail); } } }, 'حذف') : null)));
    });
  }

  /* ================= إعدادات المتجر ================= */
  R.settings = function (v) {
    v.appendChild(h('h1', null, 'إعدادات المتجر'));
    return api('GET', '/settings').then(function (s) {
      var groups = [
        ['store', 'معلومات المتجر', [{ k: 'name', label: 'اسم المتجر', type: 'text', max: 60 }, { k: 'tagline', label: 'الشعار النصي', type: 'text' }, { k: 'description', label: 'وصف المتجر', type: 'textarea', rows: 3, wide: true }, { k: 'phone', label: 'هاتف التواصل', type: 'text', dir: 'ltr', hint: 'مثال: 0555 12 34 56' }, { k: 'whatsapp', label: 'رقم واتساب', type: 'text', dir: 'ltr', hint: 'يظهر زر واتساب في الموقع عند إدخاله' }, { k: 'email', label: 'البريد الإلكتروني', type: 'text', dir: 'ltr' }, { k: 'instagram', label: 'إنستغرام (رابط أو @اسم)', type: 'text', dir: 'ltr' }, { k: 'facebook', label: 'فيسبوك', type: 'text', dir: 'ltr' }, { k: 'tiktok', label: 'تيك توك', type: 'text', dir: 'ltr' }, { k: 'address', label: 'العنوان', type: 'text' }, { k: 'currency_label', label: 'رمز العملة', type: 'text', hint: 'العملة: الدينار الجزائري (DZD)' }]],
        ['status', 'حالة المتجر', [{ k: 'open', label: 'المتجر مفتوح', type: 'bool', hint: 'عند الإغلاق يرى الزوار صفحة صيانة ولا تُقبل طلبات' }, { k: 'maintenance_message', label: 'رسالة الصيانة', type: 'textarea', rows: 3, wide: true }]],
        ['announcement', 'شريط الإعلان', [{ k: 'enabled', label: 'إظهار الشريط', type: 'bool' }, { k: 'text', label: 'النص', type: 'text', max: 160, wide: true }, { k: 'url', label: 'رابط (اختياري)', type: 'text', dir: 'ltr' }]],
        ['seo', 'SEO', [{ k: 'title_suffix', label: 'لاحقة عنوان الصفحات', type: 'text', max: 40, dir: 'ltr' }, { k: 'default_description', label: 'وصف افتراضي', type: 'textarea', rows: 3, wide: true }]],
        ['footer', 'التذييل', [{ k: 'text', label: 'نص التذييل', type: 'text', max: 200, wide: true }, { k: 'show_marquee', label: 'إظهار الشريط العملاق', type: 'bool' }]]
      ];
      groups.forEach(function (g) {
        var f = A.form(g[2], s[g[0]]); v.appendChild(h('div', { class: 'card' }, h('h2', null, g[1]), f.el, h('div', { class: 'row end' }, A.saveBar('حفظ', function () { return api('PUT', '/settings/' + g[0], f.get()).then(function () { toast('تم الحفظ'); }); }))));
      });
    });
  };

  /* ================= الحساب والمشرفون ================= */
  R.account = function (v) {
    var me = A.me(); v.appendChild(h('h1', null, 'حسابي'));
    var cur = h('input', { type: 'password', autocomplete: 'current-password' }), nw = h('input', { type: 'password', autocomplete: 'new-password' });
    v.appendChild(h('div', { class: 'card' }, h('h2', null, 'تغيير كلمة المرور'), h('div', { class: 'form-grid' }, h('div', { class: 'field' }, h('label', null, 'كلمة المرور الحالية'), cur), h('div', { class: 'field' }, h('label', null, 'كلمة المرور الجديدة'), nw, h('div', { class: 'hint' }, '12 حرفاً على الأقل، وثلاثة أنواع من (صغيرة، كبيرة، أرقام، رموز)'))),
      A.saveBar('تغيير', function () { return api('POST', '/password', { current: cur.value, new: nw.value }).then(function () { cur.value = nw.value = ''; toast('تم تغيير كلمة المرور وإنهاء الجلسات الأخرى'); }); })));
    var tb = h('div'); v.appendChild(h('div', { class: 'card' }, h('h2', null, 'التحقق بخطوتين (اختياري)'), tb));
    function drawTotp() {
      A.clear(tb);
      if (me.totp_enabled) { tb.appendChild(h('p', { class: 's-published' }, 'مفعّل ✓')); tb.appendChild(h('button', { class: 'btn danger', type: 'button', onclick: function () { A.askPassword('أدخل كلمة المرور لتعطيل التحقق بخطوتين').then(function (pw) { return api('POST', '/totp/disable', { password: pw }); }).then(function () { me.totp_enabled = false; drawTotp(); toast('تم التعطيل'); }).catch(fail); } }, 'تعطيل')); return; }
      tb.appendChild(h('p', { class: 'hint' }, 'يتطلب تطبيق مصادقة (Google Authenticator، Aegis، Microsoft Authenticator…). أدخل المفتاح يدوياً في التطبيق.'));
      tb.appendChild(h('button', { class: 'btn', type: 'button', onclick: function () {
        A.askPassword().then(function (pw) { return api('POST', '/totp/setup', { password: pw }); }).then(function (r) {
          var code = h('input', { type: 'text', inputmode: 'numeric', maxlength: 6, placeholder: '123456' }); A.clear(tb);
          tb.appendChild(h('p', null, 'المفتاح السري (أدخله في تطبيق المصادقة): ')); tb.appendChild(h('p', { class: 'mono' }, h('b', null, r.secret)));
          tb.appendChild(h('div', { class: 'field' }, h('label', null, 'أدخل الرمز المكوّن من 6 أرقام للتأكيد'), code));
          tb.appendChild(A.saveBar('تفعيل', function () { return api('POST', '/totp/enable', { code: code.value }).then(function () { me.totp_enabled = true; drawTotp(); toast('تم التفعيل'); }); }));
        }).catch(fail);
      } }, 'إعداد'));
    }
    drawTotp();
    if (me.role !== 'owner') { return; }
    v.appendChild(h('h2', null, 'المشرفون'));
    var box = h('div'); v.appendChild(box);
    function drawAdmins() {
      return api('GET', '/admins').then(function (r) {
        A.clear(box);
        box.appendChild(h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, h('th', null, 'المستخدم'), h('th', null, 'الدور'), h('th', null, 'آخر دخول'), h('th', null, 'الحالة'), h('th', null, ''))),
          h('tbody', null, r.items.map(function (a) { return h('tr', null, h('td', null, a.username + (a.totp_enabled ? ' 🔐' : '')), h('td', null, a.role === 'owner' ? 'مالك' : 'موظف'), h('td', null, dt(a.last_login_at)), h('td', null, a.active ? 'نشط' : 'معطّل'),
            h('td', null, h('div', { class: 'row' },
              h('button', { class: 'btn sm', type: 'button', onclick: function () { var np = window.prompt('كلمة مرور جديدة لـ ' + a.username + ':'); if (!np) { return; } A.askPassword().then(function (pw) { return api('PATCH', '/admins/' + a.id, { password: np, password_confirm: pw }); }).then(function () { toast('تم'); }).catch(fail); } }, 'تغيير كلمة المرور'),
              h('button', { class: 'btn sm', type: 'button', onclick: function () { A.askPassword().then(function (pw) { return api('PATCH', '/admins/' + a.id, { active: !a.active, password_confirm: pw }); }).then(drawAdmins).catch(fail); } }, a.active ? 'تعطيل' : 'تفعيل'),
              h('button', { class: 'btn sm danger', type: 'button', onclick: function () { if (!A.sure('حذف المشرف ' + a.username + '؟')) { return; } A.askPassword().then(function (pw) { return api('DELETE', '/admins/' + a.id + '?confirm=1', { password_confirm: pw }); }).then(drawAdmins).catch(fail); } }, 'حذف')))); })))));
        var un = h('input', { type: 'text', autocomplete: 'off', dir: 'ltr' }), pw = h('input', { type: 'password', autocomplete: 'new-password' }), role = h('select', null, h('option', { value: 'staff' }, 'موظف (طلبات ومنتجات)'), h('option', { value: 'owner' }, 'مالك (كل الصلاحيات)'));
        box.appendChild(h('div', { class: 'card', style: 'margin-top:1rem' }, h('h3', null, 'إضافة مشرف'), h('div', { class: 'form-grid' }, h('div', { class: 'field' }, h('label', null, 'اسم المستخدم (لاتيني)'), un), h('div', { class: 'field' }, h('label', null, 'كلمة المرور'), pw), h('div', { class: 'field' }, h('label', null, 'الدور'), role)),
          A.saveBar('إضافة', function () { return A.askPassword('أدخل كلمة مرورك لتأكيد إضافة مشرف').then(function (c) { return api('POST', '/admins', { username: un.value, password: pw.value, role: role.value, password_confirm: c }); }).then(function () { un.value = pw.value = ''; toast('تمت الإضافة'); drawAdmins(); }); })));
      });
    }
    return drawAdmins();
  };

  /* ================= السجل والنسخ الاحتياطي ================= */
  R.audit = function (v) {
    v.appendChild(h('h1', null, 'سجل العمليات'));
    return api('GET', '/audit').then(function (r) {
      v.appendChild(h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, h('th', null, 'الوقت'), h('th', null, 'المستخدم'), h('th', null, 'العملية'), h('th', null, 'الهدف'), h('th', null, 'IP'))),
        h('tbody', null, r.items.map(function (e) { return h('tr', null, h('td', null, dt(e.created_at)), h('td', null, e.admin_name), h('td', { class: 'mono' }, e.action), h('td', null, (e.entity ? e.entity + ' ' : '') + e.entity_id + (e.detail ? ' — ' + e.detail : '')), h('td', { class: 'mono' }, e.ip)); })))));
    });
  };
  R.backups = function (v) {
    v.appendChild(h('h1', null, 'النسخ الاحتياطي'));
    v.appendChild(h('div', { class: 'okbox' }, 'يأخذ الخادم نسخة يومية تلقائية (آخر 14 نسخة)، ونسخة قبل كل عملية جماعية أو ترقية لقاعدة البيانات. هذه النسخ تُحفظ على نفس القرص — حمّل نسخة دورياً واحفظها خارج الخادم (جهازك أو سحابة).'));
    var box = h('div');
    v.appendChild(h('div', { class: 'row' }, h('button', { class: 'btn primary', type: 'button', onclick: function () { api('POST', '/backups', {}).then(function () { toast('تم إنشاء النسخة'); load(); }).catch(fail); } }, 'إنشاء نسخة الآن'),
      h('button', { class: 'btn', type: 'button', onclick: function () { A.askPassword('أدخل كلمة المرور لتنزيل نسخة كاملة تحتوي بيانات الزبائن').then(function (pw) { return api('POST', '/backups/download', { password: pw }, true); }).then(function (res) { return res.blob(); }).then(function (b) { var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'store-backup-' + new Date().toISOString().slice(0, 10) + '.db'; document.body.appendChild(a); a.click(); a.remove(); }).catch(fail); } }, 'تنزيل نسخة على جهازي')));
    v.appendChild(h('h2', null, 'النسخ المحفوظة على الخادم')); v.appendChild(box);
    function load() { return api('GET', '/backups').then(function (r) { A.clear(box); if (!r.items.length) { box.appendChild(h('div', { class: 'empty card' }, 'لا توجد نسخ بعد')); return; } box.appendChild(h('div', { class: 'tablewrap' }, h('table', null, h('tbody', null, r.items.map(function (b) { return h('tr', null, h('td', { class: 'mono' }, b.name), h('td', null, Math.round(b.size / 1024) + ' KB')); }))))); }); }
    return load();
  };

  window.addEventListener('DOMContentLoaded', function () { window.__adminBoot(); });
  if (document.readyState !== 'loading') { window.__adminBoot(); }
})();
