/* لوحة التحكم — الشاشات (1): الرئيسية، الطلبات، المنتجات */
(function () {
  'use strict';
  var A = window.A, h = A.h, api = A.api, R = A.ROUTES, money = A.money, dt = A.dt, pill = A.pill, toast = A.toast, fail = A.fail;

  /* ================= لوحة المعلومات ================= */
  R.dashboard = function (v) {
    v.appendChild(h('h1', null, 'نظرة عامة'));
    return api('GET', '/dashboard').then(function (d) {
      var s = d.by_status;
      var stat = function (label, val, small) { return h('div', { class: 'stat' }, h('b', null, val), h('span', null, label), small ? h('small', null, small) : null); };
      if (d.products_published === 0) {
        v.appendChild(h('div', { class: 'warnbox' }, h('b', null, 'ابدأ من هنا: '), 'لا توجد منتجات منشورة بعد. افتح ', h('a', { href: '#/products' }, 'المنتجات'), '، حدّد السعر بالدينار والمخزون لكل مقاس، ثم غيّر الحالة إلى «منشور». كذلك راجع ', h('a', { href: '#/delivery' }, 'أسعار التوصيل'), ' (القيم الحالية افتراضية)، وأدخل أرقام الهاتف وواتساب من ', h('a', { href: '#/settings' }, 'الإعدادات'), '.'));
      }
      v.appendChild(h('div', { class: 'cards' }, stat('كل الطلبات', d.orders_total, 'اليوم: ' + d.orders_today), stat('جديدة', s.new), stat('قيد المعالجة', s.pending), stat('مؤكدة', s.confirmed), stat('مشحونة', s.shipped), stat('تم تسليمها', s.delivered), stat('ملغاة', s.cancelled)));
      v.appendChild(h('div', { class: 'cards' },
        stat('قيمة الطلبات المسجّلة', money(d.revenue_recorded), 'كل الطلبات غير الملغاة — ليست أموالاً محصّلة'),
        stat('قيمة الطلبات المؤكدة', money(d.revenue_confirmed), 'مؤكد + مشحون + مسلَّم'),
        stat('المبالغ المحصّلة (تم التسليم)', money(d.revenue_collected), 'الدفع عند الاستلام'),
        stat('المنتجات', d.products_total, 'منشور: ' + d.products_published)));
      v.appendChild(h('h2', null, 'آخر الطلبات'));
      v.appendChild(ordersTable(d.recent));
      v.appendChild(h('h2', null, 'مخزون منخفض (5 قطع أو أقل)'));
      if (!d.low_stock.length) { v.appendChild(h('div', { class: 'empty card' }, 'لا توجد منتجات منشورة بمخزون منخفض')); }
      else { v.appendChild(h('div', { class: 'card' }, h('ul', { class: 'check-list' }, d.low_stock.map(function (p) { return h('li', null, h('a', { href: '#/product/' + p.id }, p.name), ' — المتبقي: ', h('b', null, p.stock)); })))); }
    });
  };

  function ordersTable(rows, selectable, sel) {
    if (!rows.length) { return h('div', { class: 'empty card' }, 'لا توجد طلبات'); }
    var head = h('tr', null, selectable ? h('th', null, '') : null, h('th', null, 'الرقم'), h('th', null, 'التاريخ'), h('th', null, 'الزبون'), h('th', null, 'الولاية'), h('th', null, 'الإجمالي'), h('th', null, 'الحالة'));
    return h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, head), h('tbody', null, rows.map(function (o) {
      var cb = selectable ? h('td', null, h('input', { type: 'checkbox', 'aria-label': 'تحديد', onchange: function (e) { if (e.target.checked) { sel[o.id] = 1; } else { delete sel[o.id]; } } })) : null;
      return h('tr', null, cb, h('td', null, h('a', { class: 'mono', href: '#/order/' + o.id }, o.ref)), h('td', null, dt(o.created_at)), h('td', null, o.customer_name, o.phone ? h('div', { class: 'hint mono' }, o.phone) : null), h('td', null, o.wilaya_name), h('td', null, money(o.total)), h('td', null, pill(o.status)));
    }))));
  }

  /* ================= الطلبات ================= */
  R.orders = function (v) {
    var q = { q: '', status: '', wilaya: '', from: '', to: '', sort: '', page: 1 }, sel = {};
    v.appendChild(h('h1', null, 'الطلبات'));
    var box = h('div'); var filt = h('div', { class: 'card' });
    var fq = h('input', { type: 'search', placeholder: 'بحث: رقم الطلب، الاسم، الهاتف، البلدية' });
    var fs = h('select', null, h('option', { value: '' }, 'كل الحالات'), Object.keys(A.STATUS).map(function (k) { return h('option', { value: k }, A.STATUS[k]); }));
    var fw = h('select', null, h('option', { value: '' }, 'كل الولايات'));
    var ff = h('input', { type: 'date' }), ft = h('input', { type: 'date' });
    var so = h('select', null, [['', 'الأحدث'], ['oldest', 'الأقدم'], ['total_desc', 'الإجمالي: الأعلى'], ['total_asc', 'الإجمالي: الأقل']].map(function (o) { return h('option', { value: o[0] }, o[1]); }));
    api('GET', '/wilayas').then(function (r) { r.items.forEach(function (w) { fw.appendChild(h('option', { value: w.code }, w.code + ' - ' + w.name_ar)); }); });
    function qs() { var u = new URLSearchParams(); Object.keys(q).forEach(function (k) { if (q[k] !== '' && !(k === 'page' && q[k] === 1)) { u.set(k, q[k]); } }); return u.toString(); }
    function load() {
      q.q = fq.value.trim(); q.status = fs.value; q.wilaya = fw.value; q.from = ff.value; q.to = ft.value; q.sort = so.value; sel = {};
      return api('GET', '/orders?' + qs()).then(function (r) {
        A.clear(box); box.appendChild(h('p', { class: 'hint' }, r.total + ' طلب'));
        var table = ordersTable(r.items, true, sel); box.appendChild(table);
        if (r.items.length) {
          var bs = h('select', null, h('option', { value: '' }, 'تغيير حالة المحدد…'), Object.keys(A.STATUS).map(function (k) { return h('option', { value: k }, A.STATUS[k]); }));
          box.appendChild(h('div', { class: 'row', style: 'margin-top:.8rem' }, h('div', { style: 'width:220px' }, bs), h('button', { class: 'btn', type: 'button', onclick: function () {
            var ids = Object.keys(sel).map(Number); if (!ids.length || !bs.value) { toast('حدّد طلبات وحالة', 'err'); return; }
            var reason = ''; if (bs.value === 'cancelled') { reason = window.prompt('سبب الإلغاء (مطلوب):') || ''; if (!reason) { return; } }
            if (!A.sure('تغيير حالة ' + ids.length + ' طلب إلى «' + A.STATUS[bs.value] + '»؟ (سيُؤخذ نسخ احتياطي تلقائي)')) { return; }
            api('POST', '/orders/bulk', { ids: ids, status: bs.value, reason: reason }).then(function (res) { toast('تم: ' + res.ok + (res.failed.length ? ' — فشل: ' + res.failed.length : ''), res.failed.length ? 'err' : 'ok'); load(); }).catch(fail);
          } }, 'تطبيق')));
        }
        if (r.pages > 1) {
          box.appendChild(h('div', { class: 'row', style: 'margin-top:1rem;justify-content:center' }, h('button', { class: 'btn sm', type: 'button', disabled: q.page <= 1, onclick: function () { q.page--; load(); } }, 'السابق'), h('span', null, q.page + ' / ' + r.pages), h('button', { class: 'btn sm', type: 'button', disabled: q.page >= r.pages, onclick: function () { q.page++; load(); } }, 'التالي')));
        }
      });
    }
    var apply = h('button', { class: 'btn primary', type: 'button', onclick: function () { q.page = 1; load().catch(fail); } }, 'بحث');
    fq.addEventListener('keydown', function (e) { if (e.key === 'Enter') { q.page = 1; load().catch(fail); } });
    filt.appendChild(h('div', { class: 'form-grid' }, h('div', { class: 'field' }, h('label', null, 'بحث'), fq), h('div', { class: 'field' }, h('label', null, 'الحالة'), fs), h('div', { class: 'field' }, h('label', null, 'الولاية'), fw), h('div', { class: 'field' }, h('label', null, 'من تاريخ'), ff), h('div', { class: 'field' }, h('label', null, 'إلى تاريخ'), ft), h('div', { class: 'field' }, h('label', null, 'الترتيب'), so)));
    filt.appendChild(h('div', { class: 'row' }, apply, h('button', { class: 'btn', type: 'button', onclick: function () { var u = '/api/admin/orders.csv?' + (function () { q.q = fq.value.trim(); q.status = fs.value; q.wilaya = fw.value; q.from = ff.value; q.to = ft.value; q.sort = so.value; var p = Object.assign({}, q); delete p.page; var x = new URLSearchParams(); Object.keys(p).forEach(function (k) { if (p[k] !== '') { x.set(k, p[k]); } }); return x.toString(); })(); window.location.href = u; } }, 'تصدير CSV')));
    v.appendChild(filt); v.appendChild(box); return load();
  };

  R.order = function (v, args) {
    var id = args[0]; v.appendChild(h('p', null, h('a', { href: '#/orders' }, '→ كل الطلبات')));
    return api('GET', '/orders/' + id).then(function (o) {
      var phoneIntl = '213' + o.phone.replace(/^0/, '');
      var wa = 'https://wa.me/' + phoneIntl + '?text=' + encodeURIComponent('مرحباً ' + o.customer_name + '، بخصوص طلبكم رقم ' + o.ref + ' (الإجمالي ' + money(o.total) + ').');
      var print = h('div', { class: 'print-area card' },
        h('h1', null, 'طلب ' + o.ref), h('p', null, dt(o.created_at), ' — ', pill(o.status)),
        h('p', null, h('b', null, o.customer_name), ' — ', h('span', { class: 'mono' }, o.phone)), h('p', null, o.wilaya_name + ' / ' + o.commune + ' / ' + o.address), o.customer_notes ? h('p', null, 'ملاحظات الزبون: ' + o.customer_notes) : null,
        h('p', null, 'التوصيل: ' + (o.delivery_method === 'home' ? 'إلى المنزل' : 'إلى المكتب')),
        h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, h('th', null, 'المنتج'), h('th', null, 'المقاس'), h('th', null, 'اللون'), h('th', null, 'السعر'), h('th', null, 'الكمية'), h('th', null, 'المجموع'))),
          h('tbody', null, o.items.map(function (i) { return h('tr', null, h('td', null, i.image ? h('img', { class: 'thumb noprint', src: i.image, alt: '' }) : null, ' ' + i.name), h('td', null, i.size || '—'), h('td', null, i.color || '—'), h('td', null, money(i.unit_price)), h('td', null, i.qty), h('td', null, money(i.unit_price * i.qty))); })))),
        h('p', null, 'المجموع الفرعي: ', money(o.subtotal), ' — التوصيل: ', money(o.delivery_fee), ' — ', h('b', null, 'الإجمالي المطلوب عند الاستلام: ' + money(o.total))));
      v.appendChild(h('div', { class: 'row spread noprint' }, h('h1', null, 'الطلب ' + o.ref), h('div', { class: 'row' },
        h('a', { class: 'btn', href: 'tel:' + o.phone }, 'اتصال'), h('a', { class: 'btn', href: wa, target: '_blank', rel: 'noopener noreferrer' }, 'واتساب'), h('button', { class: 'btn', type: 'button', onclick: function () { window.print(); } }, 'طباعة'))));
      v.appendChild(print);

      var st = h('select', null, Object.keys(A.STATUS).map(function (k) { return h('option', { value: k, selected: k === o.status }, A.STATUS[k]); }));
      var reason = h('input', { type: 'text', value: o.cancel_reason, placeholder: 'سبب الإلغاء (مطلوب عند الإلغاء)', maxlength: 300 });
      var f = A.form([
        { k: 'tracking_number', label: 'رقم التتبع', type: 'text', max: 60 }, { k: 'actual_delivery_cost', label: 'تكلفة التوصيل الفعلية (د.ج)', type: 'int', min: 0, hint: 'ما دفعتموه فعلياً لشركة التوصيل' },
        { k: 'customer_name', label: 'اسم الزبون', type: 'text' }, { k: 'phone', label: 'الهاتف', type: 'text', dir: 'ltr' }, { k: 'commune', label: 'البلدية', type: 'text' }, { k: 'address', label: 'العنوان', type: 'text', max: 250 },
        { k: 'admin_notes', label: 'ملاحظات خاصة (لا تظهر للزبون)', type: 'textarea', wide: true }], o);
      v.appendChild(h('div', { class: 'card noprint' }, h('h2', null, 'إدارة الطلب'), h('div', { class: 'form-grid' }, h('div', { class: 'field' }, h('label', null, 'الحالة'), st), h('div', { class: 'field' }, h('label', null, 'سبب الإلغاء'), reason)), f.el,
        h('div', { class: 'row end' }, A.saveBar('حفظ التغييرات', function () {
          var body = f.get(); body.status = st.value; body.cancel_reason = reason.value;
          if (body.actual_delivery_cost === '') { body.actual_delivery_cost = null; }
          return api('PATCH', '/orders/' + id, body).then(function () { toast('تم الحفظ'); A.route(); });
        }))));
      v.appendChild(h('div', { class: 'card noprint' }, h('h2', null, 'السجل'), h('ul', { class: 'tl' }, o.events.map(function (e) { return h('li', null, h('b', null, e.event === 'created' ? 'تم إنشاء الطلب' : e.event === 'status' ? 'تغيير الحالة' : 'تعديل'), ' ', e.detail, h('br'), h('small', null, dt(e.created_at) + (e.username ? ' — ' + e.username : ''))); }))));
    });
  };

  /* ================= المنتجات ================= */
  R.products = function (v) {
    var filter = { status: '', q: '' }, box = h('div'), sel = {};
    v.appendChild(h('div', { class: 'row spread' }, h('h1', null, 'المنتجات'), h('a', { class: 'btn primary', href: '#/product/new' }, '+ منتج جديد')));
    var fs = h('select', null, [['', 'كل المنتجات (عدا المؤرشفة)'], ['published', 'منشورة'], ['draft', 'مخفية'], ['archived', 'مؤرشفة']].map(function (o) { return h('option', { value: o[0] }, o[1]); }));
    var fq = h('input', { type: 'search', placeholder: 'بحث بالاسم' });
    function load() {
      filter.status = fs.value; filter.q = fq.value.trim(); sel = {};
      return api('GET', '/products?status=' + encodeURIComponent(filter.status) + '&q=' + encodeURIComponent(filter.q)).then(function (r) {
        A.clear(box);
        if (!r.items.length) { box.appendChild(h('div', { class: 'empty card' }, 'لا توجد منتجات')); return; }
        box.appendChild(h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, h('th', null, ''), h('th', null, ''), h('th', null, 'المنتج'), h('th', null, 'السعر'), h('th', null, 'المخزون'), h('th', null, 'الحالة'), h('th', null, ''))),
          h('tbody', null, r.items.map(function (p) {
            return h('tr', null, h('td', null, h('input', { type: 'checkbox', 'aria-label': 'تحديد', onchange: function (e) { if (e.target.checked) { sel[p.id] = 1; } else { delete sel[p.id]; } } })),
              h('td', null, p.image ? h('img', { class: 'thumb', src: p.image, alt: '' }) : h('div', { class: 'thumb' })),
              h('td', null, h('a', { href: '#/product/' + p.id }, p.name), h('div', { class: 'hint' }, (p.category_name || 'بدون فئة') + (p.featured ? ' · مميز' : '') + (p.is_new ? ' · جديد' : ''))),
              h('td', null, p.price ? (p.sale_price ? h('span', null, h('s', null, money(p.price)), ' ', money(p.sale_price)) : money(p.price)) : h('span', { class: 's-pending' }, 'غير محدد')),
              h('td', null, p.stock + ' (' + p.variants + ' خيار)'), h('td', null, pill(p.status, A.PSTATUS)), h('td', null, h('a', { class: 'btn sm', href: '#/product/' + p.id }, 'تعديل')));
          })))));
        var act = h('select', null, h('option', { value: '' }, 'إجراء على المحدد…'), h('option', { value: 'publish' }, 'نشر'), h('option', { value: 'hide' }, 'إخفاء'), h('option', { value: 'archive' }, 'أرشفة'), h('option', { value: 'delete' }, 'حذف نهائي'));
        box.appendChild(h('div', { class: 'row', style: 'margin-top:.8rem' }, h('div', { style: 'width:220px' }, act), h('button', { class: 'btn', type: 'button', onclick: function () {
          var ids = Object.keys(sel).map(Number); if (!ids.length || !act.value) { toast('حدّد منتجات وإجراء', 'err'); return; }
          if (!A.sure('تنفيذ «' + act.options[act.selectedIndex].text + '» على ' + ids.length + ' منتج؟ سيُؤخذ نسخ احتياطي تلقائي.' + (act.value === 'delete' ? ' الحذف نهائي (الطلبات السابقة تبقى محفوظة).' : ''))) { return; }
          api('POST', '/products/bulk' + (act.value === 'delete' ? '?confirm=1' : ''), { ids: ids, action: act.value }).then(function () { toast('تم'); load(); }).catch(fail);
        } }, 'تطبيق')));
      });
    }
    v.appendChild(h('div', { class: 'card row' }, h('div', { class: 'grow' }, fq), h('div', { style: 'width:240px' }, fs), h('button', { class: 'btn primary', type: 'button', onclick: function () { load().catch(fail); } }, 'تصفية')));
    fq.addEventListener('keydown', function (e) { if (e.key === 'Enter') { load().catch(fail); } });
    v.appendChild(box); return load();
  };

  R.product = function (v, args) {
    var id = args[0] === 'new' ? 0 : +args[0];
    return Promise.all([id ? api('GET', '/products/' + id) : Promise.resolve({ name: '', slug: '', description: '', category_id: '', price: 0, sale_price: null, status: 'draft', featured: 0, is_new: 0, tags: '', seo_title: '', seo_description: '', images: [], variants: [], related: [] }),
      api('GET', '/categories'), api('GET', '/sizes'), api('GET', '/colors'), api('GET', '/products?status=published')]).then(function (res) {
      var p = res[0], cats = res[1].items, sizes = res[2].items, colors = res[3].items, others = res[4].items.filter(function (x) { return x.id !== id; });
      v.appendChild(h('p', null, h('a', { href: '#/products' }, '→ المنتجات')));
      v.appendChild(h('h1', null, id ? 'تعديل: ' + p.name : 'منتج جديد'));
      if (p.status === 'draft' && !(p.price > 0)) { v.appendChild(h('div', { class: 'warnbox' }, 'هذا المنتج مخفي ولا يظهر للزبائن. حدّد السعر بالدينار والمخزون وأضف صورة حقيقية، ثم غيّر الحالة إلى «منشور».')); }
      var f = A.form([
        { k: 'name', label: 'اسم المنتج', type: 'text', max: 120 }, { k: 'slug', label: 'الرابط (اختياري)', type: 'text', max: 80, dir: 'ltr', hint: id ? '' : 'يُولَّد تلقائياً من الاسم' },
        { k: 'category_id', label: 'الفئة', type: 'select', opts: [['', 'بدون فئة']].concat(cats.map(function (c) { return [c.id, c.name]; })) },
        { k: 'status', label: 'الحالة', type: 'select', opts: [['draft', 'مخفي (مسودة)'], ['published', 'منشور'], ['archived', 'مؤرشف']] },
        { k: 'price', label: 'السعر (د.ج)', type: 'int', min: 0 }, { k: 'sale_price', label: 'سعر التخفيض (اختياري)', type: 'int', min: 0, hint: 'يجب أن يكون أقل من السعر' },
        { k: 'featured', label: 'منتج مميز (يظهر في الرئيسية)', type: 'bool' }, { k: 'is_new', label: 'وصل حديثاً', type: 'bool' },
        { k: 'description', label: 'الوصف', type: 'textarea', rows: 6, wide: true, hint: 'يدعم: # عنوان، - قائمة، **غامق**' }, { k: 'tags', label: 'وسوم (مفصولة بفواصل)', type: 'text', max: 200 },
        { k: 'seo_title', label: 'عنوان SEO (اختياري)', type: 'text', max: 120 }, { k: 'seo_description', label: 'وصف SEO (اختياري)', type: 'text', max: 300 }], p);
      v.appendChild(h('div', { class: 'card' }, f.el));

      /* الصور */
      var images = p.images.map(function (i) { return { file: i.file, thumb: i.thumb, alt: i.alt }; }); var imgBox = h('div', { class: 'imglist' });
      function drawImgs() {
        A.clear(imgBox); if (!images.length) { imgBox.appendChild(h('div', { class: 'empty' }, 'لا توجد صور. المتجر يعرض بديلاً واضحاً حتى ترفع صور المنتج الحقيقية.')); }
        images.forEach(function (im, i) {
          var alt = h('input', { type: 'text', value: im.alt, placeholder: 'وصف الصورة (للقارئات الصوتية)', maxlength: 150 }); alt.addEventListener('input', function () { im.alt = alt.value; });
          imgBox.appendChild(h('div', { class: 'imgrow' }, h('img', { class: 'thumb', src: im.thumb || im.file, alt: '' }), alt, h('div', { class: 'row' },
            h('button', { class: 'btn sm', type: 'button', disabled: i === 0, 'aria-label': 'للأعلى', onclick: function () { images.splice(i - 1, 0, images.splice(i, 1)[0]); drawImgs(); } }, '↑'),
            h('button', { class: 'btn sm', type: 'button', disabled: i === images.length - 1, 'aria-label': 'للأسفل', onclick: function () { images.splice(i + 1, 0, images.splice(i, 1)[0]); drawImgs(); } }, '↓'),
            h('button', { class: 'btn sm danger', type: 'button', onclick: function () { images.splice(i, 1); drawImgs(); } }, 'حذف'))));
        });
      }
      drawImgs();
      var file = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', multiple: true, hidden: true });
      file.addEventListener('change', function () { if (!file.files.length) { return; } A.uploadFiles(file.files).then(function (r) { r.forEach(function (x) { images.push({ file: x.url, thumb: x.thumb, alt: '' }); }); drawImgs(); toast('تم رفع ' + r.length + ' صورة'); }).catch(fail); file.value = ''; });
      v.appendChild(h('div', { class: 'card' }, h('h2', null, 'الصور'), imgBox, file, h('div', { class: 'row', style: 'margin-top:.8rem' }, h('button', { class: 'btn', type: 'button', onclick: function () { file.click(); } }, 'رفع صور'), h('button', { class: 'btn', type: 'button', onclick: function () { A.mediaLibrary(function (x) { images.push({ file: x.url, thumb: x.thumb_url, alt: '' }); drawImgs(); }); } }, 'من المكتبة')), h('p', { class: 'hint' }, 'الصورة الأولى هي الرئيسية. JPG / PNG / WebP حتى 8MB.')));

      /* المتغيرات */
      var variants = p.variants.map(function (x) { return { size: x.size, color: x.color, stock: x.stock }; }); var vBox = h('tbody');
      var dlS = h('datalist', { id: 'dlS' }, sizes.map(function (s) { return h('option', { value: s.name }); })), dlC = h('datalist', { id: 'dlC' }, colors.map(function (c) { return h('option', { value: c.name }); }));
      function drawVars() {
        A.clear(vBox); if (!variants.length) { vBox.appendChild(h('tr', null, h('td', { colspan: 4, class: 'empty' }, 'أضف مقاساً/لوناً. للمنتج الموحّد اترك المقاس واللون فارغين وحدّد المخزون.'))); }
        variants.forEach(function (x, i) {
          var s = h('input', { type: 'text', value: x.size, list: 'dlS', maxlength: 40, placeholder: 'المقاس' }), c = h('input', { type: 'text', value: x.color, list: 'dlC', maxlength: 40, placeholder: 'اللون' }), n = h('input', { type: 'number', value: x.stock, min: 0, inputmode: 'numeric' });
          s.addEventListener('input', function () { x.size = s.value.trim(); }); c.addEventListener('input', function () { x.color = c.value.trim(); }); n.addEventListener('input', function () { x.stock = Math.max(0, parseInt(n.value, 10) || 0); });
          vBox.appendChild(h('tr', null, h('td', null, s), h('td', null, c), h('td', null, n), h('td', null, h('button', { class: 'btn sm danger', type: 'button', onclick: function () { variants.splice(i, 1); drawVars(); } }, 'حذف'))));
        });
      }
      drawVars();
      var genS = sizes.map(function (s) { return h('input', { type: 'checkbox', value: s.name }); }), genC = colors.map(function (c) { return h('input', { type: 'checkbox', value: c.name }); });
      var gen = h('details', null, h('summary', null, 'توليد تلقائي من المقاسات والألوان'), h('div', { class: 'row', style: 'margin:.6rem 0' }, sizes.map(function (s, i) { return h('label', { class: 'check' }, genS[i], s.name); })), h('div', { class: 'row', style: 'margin:.6rem 0' }, colors.map(function (c, i) { return h('label', { class: 'check' }, genC[i], c.name); })),
        h('button', { class: 'btn sm', type: 'button', onclick: function () {
          var ss = genS.filter(function (x) { return x.checked; }).map(function (x) { return x.value; }), cc = genC.filter(function (x) { return x.checked; }).map(function (x) { return x.value; }); if (!ss.length) { ss = ['']; } if (!cc.length) { cc = ['']; }
          ss.forEach(function (s) { cc.forEach(function (c) { if (!variants.some(function (x) { return x.size === s && x.color === c; })) { variants.push({ size: s, color: c, stock: 0 }); } }); }); drawVars();
        } }, 'إضافة التوليفات'));
      v.appendChild(h('div', { class: 'card' }, h('h2', null, 'المقاسات والألوان والمخزون'), dlS, dlC, h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, h('th', null, 'المقاس'), h('th', null, 'اللون'), h('th', null, 'المخزون'), h('th', null, ''))), vBox)),
        h('div', { class: 'row', style: 'margin:.8rem 0' }, h('button', { class: 'btn', type: 'button', onclick: function () { variants.push({ size: '', color: '', stock: 0 }); drawVars(); } }, '+ صف'), ), gen));

      /* منتجات مرتبطة */
      var rel = {}; (p.related || []).forEach(function (r) { rel[r] = 1; });
      v.appendChild(h('details', { class: 'card' }, h('summary', null, 'منتجات مرتبطة (اختياري — وإلا تُعرض منتجات من نفس الفئة)'), h('div', { class: 'row', style: 'margin-top:.6rem' }, others.map(function (o) { return h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!rel[o.id], onchange: function (e) { if (e.target.checked) { rel[o.id] = 1; } else { delete rel[o.id]; } } }), o.name); }))));

      v.appendChild(h('div', { class: 'row' }, A.saveBar('حفظ المنتج', function () {
        var body = f.get(); body.images = images; body.variants = variants; body.related = Object.keys(rel).map(Number);
        if (body.sale_price === '') { body.sale_price = null; }
        return api(id ? 'PUT' : 'POST', '/products' + (id ? '/' + id : ''), body).then(function (r) { toast('تم الحفظ'); if (!id) { location.hash = '#/product/' + r.id; } else { A.route(); } });
      }), id ? h('button', { class: 'btn danger', type: 'button', onclick: function () {
        if (!A.sure('حذف المنتج نهائياً؟ الطلبات السابقة تبقى محفوظة. (يُنصح بالأرشفة بدل الحذف)')) { return; }
        api('DELETE', '/products/' + id + '?confirm=1').then(function () { toast('تم الحذف'); location.hash = '#/products'; }).catch(fail);
      } }, 'حذف المنتج') : null, id && p.status === 'published' ? h('a', { class: 'btn', href: '/product/' + p.slug, target: '_blank', rel: 'noopener' }, 'عرض في المتجر') : null));
    });
  };
})();
