/* لوحة التحكم — جافاسكربت خالص. كل النصوص تُدرج بـ textContent (لا innerHTML إطلاقاً). */
(function () {
  'use strict';
  var me = null, csrf = '';
  var app = document.getElementById('app');

  /* ---------- أدوات DOM ---------- */
  function h(tag, attrs) {
    var e = document.createElement(tag);
    if (attrs) { Object.keys(attrs).forEach(function (k) {
      var v = attrs[k]; if (v === null || v === undefined || v === false) { return; }
      if (k === 'class') { e.className = v; }
      else if (k === 'style') { String(v).split(';').forEach(function (decl) { var i = decl.indexOf(':'); if (i > 0) { e.style.setProperty(decl.slice(0, i).trim(), decl.slice(i + 1).trim()); } }); }
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') { e.addEventListener(k.slice(2), v); }
      else if (k === 'value') { e.value = v; } else if (k === 'checked') { e.checked = !!v; } else if (k === 'disabled') { e.disabled = !!v; } else if (k === 'selected') { e.selected = !!v; }
      else { e.setAttribute(k, v === true ? '' : v); }
    }); }
    for (var i = 2; i < arguments.length; i++) { add(e, arguments[i]); }
    return e;
  }
  function add(e, c) {
    if (c === null || c === undefined || c === false) { return; }
    if (Array.isArray(c)) { c.forEach(function (x) { add(e, x); }); }
    else if (c.nodeType) { e.appendChild(c); } else { e.appendChild(document.createTextNode(String(c))); }
  }
  function clear(e) { while (e.firstChild) { e.removeChild(e.firstChild); } return e; }
  function money(n) { return String(Math.round(n || 0)) + ' د.ج'; }
  function dt(s) { if (!s) { return ''; } try { return new Date(s.replace(' ', 'T') + 'Z').toLocaleString('en-GB', { timeZone: 'Africa/Algiers', dateStyle: 'short', timeStyle: 'short' }); } catch (e) { return s; } }
  var STATUS = { new: 'جديد', pending: 'قيد المعالجة', confirmed: 'مؤكد', shipped: 'تم الشحن', delivered: 'تم التسليم', cancelled: 'ملغى' };
  var PSTATUS = { draft: 'مخفي (مسودة)', published: 'منشور', archived: 'مؤرشف' };
  function pill(s, map) { return h('span', { class: 'pill s-' + s }, (map || STATUS)[s] || s); }

  function toast(msg, kind) {
    var t = h('div', { class: 'toast ' + (kind || 'ok') }, msg); document.getElementById('toasts').appendChild(t);
    setTimeout(function () { t.remove(); }, kind === 'err' ? 6000 : 3000);
  }
  function api(method, path, body, raw) {
    var opts = { method: method, headers: {}, credentials: 'same-origin' };
    if (method !== 'GET') { opts.headers['X-CSRF-Token'] = csrf; }
    if (body instanceof FormData) { opts.body = body; } else if (body !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    return fetch('/api/admin' + path, opts).then(function (r) {
      if (raw && r.ok) { return r; }
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (r.status === 401 && path !== '/login') { me = null; showLogin('انتهت الجلسة، سجّل الدخول مجدداً'); throw new Error('unauthorized'); }
        if (!r.ok) { var e = new Error(j.error || 'خطأ'); e.data = j; throw e; }
        return j;
      });
    });
  }
  function fail(e) { if (e && e.message !== 'unauthorized') { toast(e.message || 'حدث خطأ', 'err'); } }
  function modal(title, body, small) {
    var bg = h('div', { class: 'modal-bg', role: 'dialog', 'aria-modal': 'true', 'aria-label': title });
    var box = h('div', { class: 'modal' + (small ? ' sm' : '') }, h('div', { class: 'row spread' }, h('h2', { style: null }, title), h('button', { class: 'btn sm', type: 'button', onclick: close }, 'إغلاق')), body);
    function close() { bg.remove(); }
    bg.addEventListener('click', function (e) { if (e.target === bg) { close(); } });
    bg.appendChild(box); document.body.appendChild(bg); return { close: close, box: box };
  }
  function askPassword(msg) {
    return new Promise(function (resolve) {
      var inp = h('input', { type: 'password', autocomplete: 'current-password' });
      var m = modal('تأكيد الهوية', h('div', null, h('p', null, msg || 'أدخل كلمة مرورك للمتابعة'), h('div', { class: 'field' }, inp),
        h('div', { class: 'row end' }, h('button', { class: 'btn primary', type: 'button', onclick: function () { var v = inp.value; m.close(); resolve(v); } }, 'تأكيد'))), true);
      inp.focus(); inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { var v = inp.value; m.close(); resolve(v); } });
    });
  }
  function sure(msg) { return window.confirm(msg); }

  /* ---------- مولّد النماذج ---------- */
  // defs: [{k, label, type: text|textarea|bool|int|color|select|image|url|lines|password, opts, hint, rows, video}]
  function form(defs, values) {
    var inputs = {}; var root = h('div', { class: 'form-grid' });
    defs.forEach(function (d) {
      var v = values[d.k], inp, wrap = h('div', { class: 'field' });
      if (d.type === 'bool') {
        inp = h('input', { type: 'checkbox', checked: !!v }); wrap.appendChild(h('label', { class: 'check' }, inp, d.label)); inputs[d.k] = { get: function () { return inp.checked; } };
      } else if (d.type === 'image') {
        var picker = imagePicker(v || '', d.video); wrap.appendChild(h('label', null, d.label)); wrap.appendChild(picker.el); inputs[d.k] = { get: picker.get };
      } else if (d.type === 'lines') {
        inp = h('textarea', { rows: d.rows || 4 }); inp.value = (v || []).join('\n'); wrap.appendChild(h('label', null, d.label)); wrap.appendChild(inp);
        inputs[d.k] = { get: function () { return inp.value.split(/\n+/).map(function (s) { return s.trim(); }).filter(Boolean); } };
      } else if (d.type === 'stats') {
        var rows = h('div'); var list = (v || []).slice(); while (list.length < 3) { list.push({ value: '', label: '' }); }
        var pairs = list.slice(0, 4).map(function (s) { var a = h('input', { type: 'text', value: s.value, placeholder: 'الرقم', maxlength: 8 }), b = h('input', { type: 'text', value: s.label, placeholder: 'الوصف', maxlength: 30 }); rows.appendChild(h('div', { class: 'row', style: null }, h('div', { style: 'width:110px' }, a), h('div', { class: 'grow' }, b))); return [a, b]; });
        wrap.appendChild(h('label', null, d.label)); wrap.appendChild(rows);
        inputs[d.k] = { get: function () { return pairs.map(function (p) { return { value: p[0].value.trim(), label: p[1].value.trim() }; }).filter(function (x) { return x.value || x.label; }); } };
      } else {
        if (d.type === 'textarea') { inp = h('textarea', { rows: d.rows || 4 }); inp.value = v == null ? '' : v; }
        else if (d.type === 'select') { inp = h('select', null, d.opts.map(function (o) { return h('option', { value: o[0], selected: String(o[0]) === String(v) }, o[1]); })); }
        else if (d.type === 'color') { inp = h('input', { type: 'color', value: v || '#000000' }); }
        else if (d.type === 'int') { inp = h('input', { type: 'number', value: v == null ? '' : v, min: d.min, max: d.max, inputmode: 'numeric' }); }
        else { inp = h('input', { type: d.type === 'password' ? 'password' : 'text', value: v == null ? '' : v, maxlength: d.max || 300, dir: d.dir }); }
        wrap.appendChild(h('label', null, d.label)); wrap.appendChild(inp);
        inputs[d.k] = { get: function () { return d.type === 'int' ? (inp.value === '' ? '' : parseInt(inp.value, 10)) : inp.value; } };
      }
      if (d.hint) { wrap.appendChild(h('div', { class: 'hint' }, d.hint)); }
      if (d.wide) { wrap.style.gridColumn = '1 / -1'; }
      root.appendChild(wrap);
    });
    return { el: root, get: function () { var o = {}; defs.forEach(function (d) { o[d.k] = inputs[d.k].get(); }); return o; } };
  }

  /* ---------- اختيار الصور / رفع ---------- */
  function uploadFiles(files, allowVideo) {
    var fd = new FormData(); Array.prototype.forEach.call(files, function (f) { fd.append('file', f, f.name); }); if (allowVideo) { fd.append('allowVideo', '1'); }
    return api('POST', '/upload', fd).then(function (r) { return r.items; });
  }
  function mediaLibrary(onPick, videoOk) {
    var grid = h('div', { class: 'media-grid' }); var m = modal('مكتبة الوسائط', h('div', null, grid));
    api('GET', '/media').then(function (r) {
      if (!r.items.length) { grid.appendChild(h('div', { class: 'empty' }, 'لا توجد ملفات بعد. ارفع صورة أولاً.')); }
      r.items.filter(function (x) { return videoOk || x.kind === 'image'; }).forEach(function (x) {
        var it = h('div', { class: 'media-item', tabindex: '0', role: 'button', 'aria-label': 'اختيار الملف' }, x.kind === 'video' ? h('video', { src: x.url, muted: true, preload: 'metadata' }) : h('img', { src: x.thumb_url, alt: '' }), h('small', null, x.original_name || x.file));
        var pick = function () { m.close(); onPick(x); }; it.addEventListener('click', pick); it.addEventListener('keydown', function (e) { if (e.key === 'Enter') { pick(); } }); grid.appendChild(it);
      });
    }).catch(fail);
  }
  function imagePicker(value, videoOk) {
    var cur = value, prev = h('div', { class: 'prev' }, 'لا توجد'), file = h('input', { type: 'file', accept: videoOk ? 'image/jpeg,image/png,image/webp,video/mp4,video/webm' : 'image/jpeg,image/png,image/webp', hidden: true });
    function draw() { var p = h('div', { class: 'prev' }); if (cur) { clear(prev); if (/\.(mp4|webm)$/.test(cur)) { prev.textContent = 'فيديو'; } else { prev.appendChild(h('img', { src: cur, alt: '', style: 'max-width:100%;max-height:100%' })); } } else { prev.textContent = 'لا توجد'; } }
    draw();
    file.addEventListener('change', function () { if (!file.files.length) { return; } uploadFiles(file.files, videoOk).then(function (r) { cur = r[0].url; draw(); toast('تم الرفع'); }).catch(fail); file.value = ''; });
    var el = h('div', { class: 'imgpick' }, prev, h('div', { class: 'row' },
      h('button', { class: 'btn sm', type: 'button', onclick: function () { file.click(); } }, 'رفع ملف'),
      h('button', { class: 'btn sm', type: 'button', onclick: function () { mediaLibrary(function (x) { cur = x.url; draw(); }, videoOk); } }, 'من المكتبة'),
      h('button', { class: 'btn sm', type: 'button', onclick: function () { cur = ''; draw(); } }, 'إزالة')), file);
    return { el: el, get: function () { return cur; } };
  }
  function saveBar(label, fn) {
    var b = h('button', { class: 'btn primary', type: 'button' }, label || 'حفظ');
    b.addEventListener('click', function () { b.disabled = true; Promise.resolve().then(fn).then(function () { b.disabled = false; }, function (e) { b.disabled = false; fail(e); }); });
    return b;
  }

  /* ---------- الدخول ---------- */
  function showLogin(msg) {
    clear(app); document.title = 'تسجيل الدخول';
    var u = h('input', { type: 'text', autocomplete: 'username', required: true }), p = h('input', { type: 'password', autocomplete: 'current-password', required: true }), t = h('input', { type: 'text', inputmode: 'numeric', autocomplete: 'one-time-code', maxlength: 6, placeholder: '123456' });
    var tw = h('div', { class: 'field', hidden: true }, h('label', null, 'رمز التحقق بخطوتين'), t); var err = h('p', { class: 's-cancelled', role: 'alert' }, msg || '');
    var f = h('form', { class: 'card login' }, h('h1', null, 'لوحة التحكم'), err, h('div', { class: 'field' }, h('label', null, 'اسم المستخدم'), u), h('div', { class: 'field' }, h('label', null, 'كلمة المرور'), p), tw, h('button', { class: 'btn primary', type: 'submit', style: 'width:100%;justify-content:center' }, 'دخول'));
    f.addEventListener('submit', function (e) {
      e.preventDefault(); err.textContent = '';
      api('POST', '/login', { username: u.value, password: p.value, totp: t.value }).then(function (r) {
        if (r.need_totp) { tw.hidden = false; t.focus(); err.textContent = 'أدخل رمز التحقق من تطبيق المصادقة'; return; }
        return boot();
      }).catch(function (e2) { err.textContent = e2.message; });
    });
    app.appendChild(f); u.focus();
  }

  /* ---------- الإطار والتوجيه ---------- */
  var ROUTES = {};
  var NAV = [
    ['#/', 'الرئيسية', 'dashboard'], ['#/orders', 'الطلبات', 'orders'], ['#/products', 'المنتجات', 'products'], ['#/taxonomy', 'الفئات والمقاسات والألوان', 'taxonomy'], ['#/media', 'الوسائط', 'media'],
    ['sep', 'الموقع'], ['#/homepage', 'الصفحة الرئيسية', 'homepage', 1], ['#/design', 'التصميم والحركة', 'design', 1], ['#/nav', 'القوائم', 'nav', 1], ['#/pages', 'الصفحات', 'pages', 1],
    ['sep', 'المتجر'], ['#/delivery', 'التوصيل والأسعار', 'delivery', 1], ['#/settings', 'إعدادات المتجر', 'settings', 1],
    ['sep', 'النظام'], ['#/account', 'حسابي والمشرفون', 'account'], ['#/audit', 'سجل العمليات', 'audit', 1], ['#/backups', 'النسخ الاحتياطي', 'backups', 1]
  ];
  function shell() {
    clear(app); var side = h('aside', { class: 'side', id: 'side' }, h('div', { class: 'brand' }, h('img', { src: '/assets/logo.jpeg', alt: '' }), h('span', null, 'لوحة التحكم')));
    var nav = h('nav', { class: 'nav', 'aria-label': 'القائمة' });
    NAV.forEach(function (n) {
      if (n[0] === 'sep') { nav.appendChild(h('div', { class: 'sep' }, n[1])); return; }
      if (n[3] && me.role !== 'owner') { return; }
      nav.appendChild(h('a', { href: n[0], 'data-r': n[2] }, n[1]));
    });
    side.appendChild(nav);
    side.appendChild(h('div', { class: 'who' }, h('div', null, me.username + ' (' + (me.role === 'owner' ? 'مالك' : 'موظف') + ')'), h('div', { class: 'row', style: 'margin-top:.5rem' },
      h('a', { class: 'btn sm', href: '/', target: '_blank', rel: 'noopener' }, 'عرض الموقع'), h('button', { class: 'btn sm', type: 'button', onclick: function () { api('POST', '/logout', {}).then(function () { me = null; showLogin(); }); } }, 'خروج'))));
    var top = h('div', { class: 'topbar' }, h('button', { class: 'btn sm', type: 'button', 'aria-label': 'القائمة', onclick: function () { side.classList.toggle('open'); } }, '☰'), h('b', null, 'لوحة التحكم'));
    var main = h('main', { class: 'main', id: 'view' });
    app.appendChild(h('div', null, top, h('div', { class: 'layout' }, side, main)));
    side.addEventListener('click', function (e) { if (e.target.tagName === 'A') { side.classList.remove('open'); } });
  }
  function route() {
    if (!me) { return; } var hash = location.hash || '#/'; var parts = hash.slice(2).split('/'); var name = parts[0] || 'dashboard';
    document.querySelectorAll('.nav a').forEach(function (a) { a.classList.toggle('on', a.getAttribute('data-r') === name || (name === 'order' && a.getAttribute('data-r') === 'orders') || (name === 'product' && a.getAttribute('data-r') === 'products')); });
    var view = document.getElementById('view'); if (!view) { return; } clear(view);
    var fn = ROUTES[name]; if (!fn) { view.appendChild(h('div', { class: 'empty' }, 'الصفحة غير موجودة')); return; }
    document.title = 'لوحة التحكم';
    try { var r = fn(view, parts.slice(1)); if (r && r.catch) { r.catch(fail); } } catch (e) { fail(e); }
  }
  window.addEventListener('hashchange', route);
  function boot() {
    return api('GET', '/me').then(function (r) { me = r; csrf = r.csrf; shell(); route(); }).catch(function () { showLogin(); });
  }
  window.A = { h: h, add: add, clear: clear, money: money, dt: dt, pill: pill, toast: toast, api: api, fail: fail, modal: modal, askPassword: askPassword, sure: sure, form: form, imagePicker: imagePicker, uploadFiles: uploadFiles, mediaLibrary: mediaLibrary, saveBar: saveBar, STATUS: STATUS, PSTATUS: PSTATUS, ROUTES: ROUTES, me: function () { return me; }, route: route };
  window.__adminBoot = boot;
})();
