(function () {
  'use strict';
  var Cart = window.Cart, S = window.Shop, form = document.getElementById('coForm'); if (!form) { return; }
  var loading = document.getElementById('coLoading'), lines = document.getElementById('coLines'), submit = document.getElementById('coSubmit'), topErr = document.getElementById('coErr');
  var IDEM = 'three_idem_v1', draftKey = 'three_draft_v1';
  var current = null;

  function idem() { var k = null; try { k = sessionStorage.getItem(IDEM); } catch (e) { /* ignore */ } if (!k) { k = (self.crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2) + '0000000000'; try { sessionStorage.setItem(IDEM, k); } catch (e) { /* ignore */ } } return k; }
  function val(n) { var f = form.elements[n]; return f ? f.value : ''; }
  function method() { var r = form.querySelector('input[name="method"]:checked'); return r ? r.value : 'home'; }
  function setErr(name, msg) { var p = form.querySelector('[data-err="' + name + '"]'); if (p) { p.textContent = msg || ''; } var f = form.elements[name]; if (f && f.setAttribute) { if (msg) { f.setAttribute('aria-invalid', 'true'); } else { f.removeAttribute('aria-invalid'); } } }

  function renderSummary(q) {
    lines.textContent = '';
    q.lines.forEach(function (l) {
      var r = S.el('div', 'co-line'); var left = S.el('span', '', l.name + ' × ' + l.qty); if (l.size || l.color) { left.appendChild(document.createElement('br')); left.appendChild(S.el('small', '', [l.size, l.color].filter(Boolean).join(' · '))); }
      r.appendChild(left); r.appendChild(S.el('b', '', S.money(l.line_total))); lines.appendChild(r);
    });
    document.getElementById('coSub').textContent = S.money(q.subtotal);
    document.getElementById('coFee').textContent = q.delivery_fee === null ? 'اختر الولاية' : (q.delivery_fee === 0 ? 'مجاني' : S.money(q.delivery_fee));
    document.getElementById('coTotal').textContent = S.money(q.total);
  }
  function refresh() {
    var w = parseInt(val('wilaya'), 10) || 0;
    return S.quote(w, method()).then(function (q) {
      var warn = q.problems.map(function (p) { return p.message; });
      if (warn.length) { S.reconcile(q); topErr.textContent = warn.join(' — ') + ' — تم تحديث سلتك.'; topErr.hidden = false; } else { topErr.hidden = true; }
      if (!q.lines.length) { location.href = '/cart'; return; }
      current = q; renderSummary(q);
    }).catch(function (e) { topErr.textContent = e.message; topErr.hidden = false; });
  }

  if (!Cart.count()) { loading.textContent = ''; var a = S.el('a', 'btn-solid', 'سلتك فارغة — تصفّح المتجر'); a.href = '/shop'; loading.appendChild(a); return; }
  try { var d = JSON.parse(localStorage.getItem(draftKey) || '{}'); ['name', 'phone', 'commune', 'address', 'notes'].forEach(function (k) { if (d[k] && form.elements[k]) { form.elements[k].value = d[k]; } }); if (d.wilaya) { form.elements.wilaya.value = d.wilaya; } } catch (e) { /* ignore */ }
  refresh().then(function () { loading.hidden = true; form.hidden = false; });
  form.elements.wilaya.addEventListener('change', refresh);
  form.querySelectorAll('input[name="method"]').forEach(function (r) { r.addEventListener('change', refresh); });
  form.addEventListener('input', function () { try { localStorage.setItem(draftKey, JSON.stringify({ name: val('name'), phone: val('phone'), wilaya: val('wilaya'), commune: val('commune'), address: val('address'), notes: val('notes') })); } catch (e) { /* ignore */ } });

  function clientValidate() {
    var ok = true; ['name', 'phone', 'wilaya', 'commune', 'address'].forEach(function (n) { setErr(n, ''); });
    if (val('name').trim().length < 3) { setErr('name', 'الاسم الكامل مطلوب'); ok = false; }
    var ph = val('phone').replace(/[\s.\-()]/g, '').replace(/^\+213/, '0').replace(/^00213/, '0');
    if (!/^0[567]\d{8}$/.test(ph) && !/^0[234]\d{7,8}$/.test(ph)) { setErr('phone', 'رقم هاتف جزائري غير صالح (مثال: 0555123456)'); ok = false; }
    if (!val('wilaya')) { setErr('wilaya', 'اختر الولاية'); ok = false; }
    if (val('commune').trim().length < 2) { setErr('commune', 'أدخل البلدية'); ok = false; }
    if (val('address').trim().length < 5) { setErr('address', 'أدخل عنوان التوصيل'); ok = false; }
    return ok;
  }
  form.addEventListener('submit', function (e) {
    e.preventDefault(); topErr.hidden = true;
    if (!clientValidate()) { var bad = form.querySelector('[aria-invalid="true"]'); if (bad) { bad.focus(); } return; }
    submit.disabled = true; submit.textContent = 'جاري إرسال الطلب…';
    var body = { items: Cart.payload(), name: val('name'), phone: val('phone'), wilaya: parseInt(val('wilaya'), 10), commune: val('commune'), address: val('address'), notes: val('notes'), method: method() };
    fetch('/api/orders', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Idempotency-Key': idem() }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, status: r.status, j: j }; }); })
      .then(function (res) {
        if (res.ok) { Cart.clear(); try { sessionStorage.removeItem(IDEM); localStorage.removeItem(draftKey); } catch (e) { /* ignore */ } location.href = res.j.url; return; }
        if (res.j.errors) { Object.keys(res.j.errors).forEach(function (k) { setErr(k, res.j.errors[k]); }); }
        if (res.j.stale) { try { sessionStorage.removeItem(IDEM); } catch (e) { /* ignore */ } refresh(); }
        topErr.textContent = res.j.error || 'تعذّر إرسال الطلب'; topErr.hidden = false; submit.disabled = false; submit.textContent = 'تأكيد الطلب';
      })
      .catch(function () { topErr.textContent = 'تعذّر الاتصال بالخادم. لم يتم تسجيل طلبك — حاول مرة أخرى.'; topErr.hidden = false; submit.disabled = false; submit.textContent = 'تأكيد الطلب'; });
  });
})();
