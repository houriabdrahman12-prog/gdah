/* مشترك لكل الصفحات: السلة، القائمة، الحركة العامة. بدون مكتبات خارجية. */
(function () {
  'use strict';
  var root = document.documentElement;
  root.classList.remove('no-js');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fx = (root.getAttribute('data-fx') || '').split(' ');
  var has = function (n) { return fx.indexOf(n) !== -1; };
  var fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  window.FX = { reduce: reduce, has: has, fine: fine };
  if (!reduce) root.classList.add('fx-on');

  /* ---------- السلة (localStorage للراحة فقط؛ الأسعار والمخزون تُحسب في الخادم) ---------- */
  var KEY = 'three_cart_v1';
  function read() {
    try { var v = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(v) ? v.filter(function (x) { return x && x.v > 0 && x.q > 0; }) : []; } catch (e) { return []; }
  }
  function write(items) { try { localStorage.setItem(KEY, JSON.stringify(items)); } catch (e) { /* التخزين غير متاح */ } badge(); }
  var Cart = window.Cart = {
    get: read, set: write,
    add: function (variantId, qty) {
      var items = read(), f = items.filter(function (i) { return i.v === variantId; })[0];
      if (f) { f.q = Math.min(99, f.q + qty); } else { items.push({ v: variantId, q: Math.min(99, qty) }); }
      write(items);
    },
    setQty: function (variantId, qty) { write(read().map(function (i) { return i.v === variantId ? { v: i.v, q: qty } : i; }).filter(function (i) { return i.q > 0; })); },
    remove: function (variantId) { write(read().filter(function (i) { return i.v !== variantId; })); },
    clear: function () { write([]); },
    count: function () { return read().reduce(function (a, i) { return a + i.q; }, 0); },
    payload: function () { return read().map(function (i) { return { variantId: i.v, qty: i.q }; }); }
  };
  function badge() {
    var el = document.getElementById('cartCount'); if (!el) return;
    var n = Cart.count(); el.textContent = String(n); el.hidden = n === 0;
  }
  badge(); window.addEventListener('storage', badge);

  /* ---------- ألوان العينات (CSSOM بدل style المضمّن بسبب CSP) ---------- */
  document.querySelectorAll('[data-bg]').forEach(function (el) { el.style.background = el.getAttribute('data-bg'); });

  /* ---------- قائمة الجوال ---------- */
  var burger = document.getElementById('burger'), overlay = document.getElementById('menuOverlay');
  if (burger && overlay) {
    var setMenu = function (open) {
      burger.classList.toggle('is-open', open); overlay.classList.toggle('is-open', open);
      burger.setAttribute('aria-expanded', String(open)); overlay.setAttribute('aria-hidden', String(!open));
      document.body.style.overflow = open ? 'hidden' : '';
    };
    burger.addEventListener('click', function () { setMenu(!overlay.classList.contains('is-open')); });
    overlay.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', function () { setMenu(false); }); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { setMenu(false); } });
  }

  /* ---------- الترويسة: تخفى عند النزول وتظهر عند الصعود ---------- */
  var header = document.getElementById('header');
  if (header) {
    var lastY = 0, ticking = false, solid = header.classList.contains('is-scrolled');
    window.addEventListener('scroll', function () {
      if (ticking) { return; } ticking = true;
      requestAnimationFrame(function () {
        var y = window.scrollY;
        if (!solid) { header.classList.toggle('is-scrolled', y > 40); }
        if (!reduce && y > lastY && y > 300 && !(overlay && overlay.classList.contains('is-open'))) { header.classList.add('is-hidden'); } else { header.classList.remove('is-hidden'); }
        lastY = y; ticking = false;
      });
    }, { passive: true });
  }

  /* ---------- روابط # الداخلية ---------- */
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href^="#"], a[href^="/#"]'); if (!a) { return; }
    var href = a.getAttribute('href'), hash = href.charAt(0) === '/' ? href.slice(1) : href;
    if (href.charAt(0) === '/' && location.pathname !== '/') { return; }
    var t = hash.length > 1 && document.querySelector(hash); if (!t) { return; }
    e.preventDefault(); t.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth' });
  });

  /* ---------- تقسيم النص ---------- */
  window.splitLatinChars = function (el) {
    var text = el.textContent; el.textContent = ''; var frag = document.createDocumentFragment();
    Array.prototype.forEach.call(text, function (ch) { var s = document.createElement('span'); s.className = 'char'; s.textContent = ch === ' ' ? ' ' : ch; frag.appendChild(s); });
    el.appendChild(frag); return el.querySelectorAll('.char');
  };
  function splitWords(el) {
    var words = el.textContent.trim().split(/\s+/); el.textContent = '';
    words.forEach(function (w, i) {
      var wrap = document.createElement('span'); wrap.className = 'word'; var inner = document.createElement('span'); inner.textContent = w; wrap.appendChild(inner); el.appendChild(wrap);
      if (i < words.length - 1) { el.appendChild(document.createTextNode(' ')); }
    });
    return el.querySelectorAll('.word > span');
  }
  window.splitWords = splitWords;

  /* ---------- الكشف عند التمرير ---------- */
  var animateReveal = !reduce && 'IntersectionObserver' in window;
  var wordEls = Array.prototype.slice.call(document.querySelectorAll('[data-words]'));
  wordEls.forEach(function (el) {
    var spans = splitWords(el);
    spans.forEach(function (s, i) { s.style.transitionDelay = (i * 0.07) + 's'; });
  });
  if (animateReveal) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) { return; }
        var el = en.target; io.unobserve(el);
        if (el.getAttribute('data-reveal') === 'wipe') { el.classList.add('is-revealed'); } else { el.classList.add('is-in'); }
        if (el.classList.contains('stat-num')) { countUp(el); }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
    document.querySelectorAll('[data-reveal], [data-words], .stat-num[data-count]').forEach(function (el) {
      if (el.classList.contains('hero__title') || el.closest('.hero')) { return; }
      if (el.hasAttribute('data-words') && !has('words')) { return; }
      if (el.hasAttribute('data-reveal') && !has('reveal')) { return; }
      io.observe(el);
    });
  } else {
    document.querySelectorAll('.stat-num[data-count]').forEach(function (el) { el.textContent = el.getAttribute('data-count'); });
  }
  function countUp(el) {
    var target = parseInt(el.getAttribute('data-count'), 10); if (isNaN(target)) { return; }
    var t0 = performance.now(), dur = 1400;
    (function step(t) { var p = Math.min(1, (t - t0) / dur); el.textContent = String(Math.round(target * (1 - Math.pow(1 - p, 3)))); if (p < 1) { requestAnimationFrame(step); } })(t0);
  }
  document.querySelectorAll('.stat-num[data-count]').forEach(function (el) { if (animateReveal && has('reveal')) { el.textContent = '0'; } else { el.textContent = el.getAttribute('data-count'); } });

  /* ---------- الأشرطة المتحركة (CSS) ---------- */
  function buildMarquee(id, speed) {
    var track = document.getElementById(id); if (!track || reduce || !has('marquee') || !track.children[0]) { return; }
    var item = track.children[0], w = item.offsetWidth; if (!w) { return; }
    var copies = 0; while (track.scrollWidth < window.innerWidth * 2 + w && copies < 20) { track.appendChild(item.cloneNode(true)); copies++; }
    track.appendChild(item.cloneNode(true));
    track.style.setProperty('--shift', w + 'px'); track.style.setProperty('--dur', (w / speed) + 's');
  }
  window.addEventListener('load', function () { buildMarquee('marqueeTrack', 60); buildMarquee('footerTrack', 110); });

  /* ---------- المؤشر المخصص ---------- */
  var cursor = document.getElementById('cursor');
  if (cursor && fine && !reduce && has('cursor')) {
    var label = document.getElementById('cursorLabel'), cx = 0, cy = 0, tx = 0, ty = 0, run = false;
    var loop = function () { cx += (tx - cx) * 0.2; cy += (ty - cy) * 0.2; cursor.style.transform = 'translate(' + cx + 'px,' + cy + 'px)'; if (Math.abs(tx - cx) + Math.abs(ty - cy) > 0.3) { requestAnimationFrame(loop); } else { run = false; } };
    window.addEventListener('mousemove', function (e) { tx = e.clientX; ty = e.clientY; if (!run) { run = true; requestAnimationFrame(loop); } }, { passive: true });
    document.addEventListener('mouseover', function (e) {
      var t = e.target.closest && e.target.closest('[data-cursor]');
      if (t) { label.textContent = t.getAttribute('data-cursor'); cursor.classList.add('is-active'); } else { cursor.classList.remove('is-active'); }
    });
  }
})();
