/* بعد تأكيد الطلب: نتأكد أن السلة فارغة. */
(function () { 'use strict'; try { window.Cart && window.Cart.clear(); } catch (e) { /* ignore */ } })();
