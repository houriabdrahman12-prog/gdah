(function () {
  'use strict';
  var dataEl = document.getElementById('pdata'); if (!dataEl) { return; }
  var P = JSON.parse(dataEl.textContent), form = document.getElementById('buyForm');
  var sizeRow = document.getElementById('sizeRow'), colorRow = document.getElementById('colorRow');
  var qty = document.getElementById('qty'), msg = document.getElementById('stockMsg'), err = document.getElementById('buyErr'), addBtn = document.getElementById('addBtn'), goCart = document.getElementById('goCart');
  var sel = { size: null, color: null };
  var hasSize = !!sizeRow, hasColor = !!colorRow;
  if (!hasSize) { sel.size = P.variants.length ? P.variants[0].size : ''; }
  if (!hasColor) { sel.color = P.variants.length ? P.variants[0].color : ''; }

  function find(size, color) { return P.variants.filter(function (v) { return v.size === size && v.color === color; })[0]; }
  function stockFor(size, color) {
    return P.variants.filter(function (v) { return (size === null || v.size === size) && (color === null || v.color === color); }).reduce(function (a, v) { return a + v.stock; }, 0);
  }
  function refresh() {
    if (sizeRow) { sizeRow.querySelectorAll('button').forEach(function (b) {
      var s = b.getAttribute('data-size'); b.setAttribute('aria-pressed', String(sel.size === s));
      b.disabled = stockFor(s, hasColor ? sel.color : null) <= 0 && stockFor(s, null) <= 0;
    }); }
    if (colorRow) { colorRow.querySelectorAll('button').forEach(function (b) {
      var c = b.getAttribute('data-color'); b.setAttribute('aria-pressed', String(sel.color === c));
      b.disabled = stockFor(hasSize ? sel.size : null, c) <= 0 && stockFor(null, c) <= 0;
    }); }
    var v = (sel.size !== null && sel.color !== null) ? find(sel.size, sel.color) : null;
    if (v) {
      if (v.stock <= 0) { msg.textContent = 'هذا الخيار نفد من المخزون'; }
      else if (v.stock <= 5) { msg.textContent = 'بقي ' + v.stock + ' قطع فقط'; }
      else { msg.textContent = 'متوفر'; }
      qty.max = String(Math.min(99, v.stock));
      if (parseInt(qty.value, 10) > v.stock) { qty.value = String(Math.max(1, v.stock)); }
    } else { msg.textContent = ''; }
  }
  function onPick(row, key, attr) {
    if (!row) { return; }
    row.addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b || b.disabled) { return; } sel[key] = b.getAttribute(attr); err.hidden = true; refresh(); });
  }
  onPick(sizeRow, 'size', 'data-size'); onPick(colorRow, 'color', 'data-color');
  // اختيار تلقائي إذا كان هناك خيار واحد متاح
  if (hasSize) { var ss = [].concat.apply([], [P.variants.filter(function (v) { return v.stock > 0; }).map(function (v) { return v.size; })]).filter(function (x, i, a) { return a.indexOf(x) === i; }); if (ss.length === 1) { sel.size = ss[0]; } }
  if (hasColor) { var cs = P.variants.filter(function (v) { return v.stock > 0 && (!hasSize || sel.size === null || v.size === sel.size); }).map(function (v) { return v.color; }).filter(function (x, i, a) { return a.indexOf(x) === i; }); if (cs.length === 1) { sel.color = cs[0]; } }
  refresh();

  document.getElementById('qMinus').addEventListener('click', function () { qty.value = String(Math.max(1, (parseInt(qty.value, 10) || 1) - 1)); });
  document.getElementById('qPlus').addEventListener('click', function () { qty.value = String(Math.min(parseInt(qty.max, 10) || 99, (parseInt(qty.value, 10) || 1) + 1)); });

  form.addEventListener('submit', function (e) {
    e.preventDefault(); err.hidden = true;
    if (hasSize && sel.size === null) { err.textContent = 'اختر المقاس'; err.hidden = false; return; }
    if (hasColor && sel.color === null) { err.textContent = 'اختر اللون'; err.hidden = false; return; }
    var v = find(sel.size, sel.color);
    if (!v || v.stock <= 0) { err.textContent = 'هذا الخيار غير متوفر'; err.hidden = false; return; }
    var q = Math.max(1, Math.min(99, parseInt(qty.value, 10) || 1));
    var inCart = window.Cart.get().filter(function (i) { return i.v === v.id; })[0];
    if ((inCart ? inCart.q : 0) + q > v.stock) { err.textContent = 'الكمية المتاحة ' + v.stock + ' فقط' + (inCart ? ' (لديك ' + inCart.q + ' في السلة)' : ''); err.hidden = false; return; }
    window.Cart.add(v.id, q);
    addBtn.textContent = 'تمت الإضافة ✓'; goCart.hidden = false;
    setTimeout(function () { addBtn.textContent = 'أضف إلى السلة'; }, 2000);
  });

  /* المعرض والتكبير */
  var main = document.getElementById('galMain'), img = document.getElementById('galImg'), lb = document.getElementById('lightbox'), lbImg = document.getElementById('lbImg');
  document.querySelectorAll('.gallery__thumb').forEach(function (t) {
    t.addEventListener('click', function () {
      img.src = t.getAttribute('data-src'); img.alt = t.getAttribute('data-alt');
      document.querySelectorAll('.gallery__thumb').forEach(function (x) { x.classList.toggle('is-on', x === t); });
    });
  });
  if (main && lb) {
    main.addEventListener('click', function () { lbImg.src = img.src; lbImg.alt = img.alt; lb.hidden = false; document.getElementById('lbClose').focus(); });
    var close = function () { lb.hidden = true; main.focus(); };
    document.getElementById('lbClose').addEventListener('click', close);
    lb.addEventListener('click', function (e) { if (e.target === lb) { close(); } });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !lb.hidden) { close(); } });
  }
})();
