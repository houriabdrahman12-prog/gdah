/* صفحة السلة + مكتبة مساعدة للدفع. كل النصوص تُدرج بـ textContent. */
(function () {
  'use strict';
  var Cart = window.Cart;
  function money(n) { return String(Math.round(n)) + '\u00A0د.ج'; }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) { e.className = cls; } if (text !== undefined) { e.textContent = text; } return e; }
  window.Shop = { money: money, el: el, quote: quote };

  function quote(wilaya, method) {
    return fetch('/api/cart/quote', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: Cart.payload(), wilaya: wilaya || 0, method: method || 'home' }) })
      .then(function (r) { return r.json().then(function (j) { if (!r.ok) { throw new Error(j.error || 'خطأ'); } return j; }); });
  }
  /* يزيل من السلة العناصر التي لم تعد متاحة ويعدّل الكميات */
  window.Shop.reconcile = function (q) {
    var items = Cart.get(), valid = {};
    q.lines.forEach(function (l) { valid[l.variantId] = l.qty; });
    var next = items.filter(function (i) { return valid[i.v] !== undefined; }).map(function (i) { return { v: i.v, q: Math.min(i.q, valid[i.v]) }; });
    Cart.set(next);
  };

  var root = document.getElementById('cartRoot'); if (!root) { return; }
  function render() {
    if (!Cart.count()) {
      root.textContent = ''; var box = el('div', 'empty'); box.appendChild(el('p', '', 'سلتك فارغة.')); var a = el('a', 'btn-solid', 'تصفّح المتجر'); a.href = '/shop'; box.appendChild(a); root.appendChild(box); return;
    }
    quote().then(function (q) {
      var warn = q.problems.map(function (p) { return p.message; });
      window.Shop.reconcile(q);
      root.textContent = '';
      if (!q.lines.length) { render(); if (warn.length) { var w = el('div', 'cart-warn', warn.join(' — ')); root.prepend(w); } return; }
      if (warn.length) { root.appendChild(el('div', 'cart-warn', warn.join(' — '))); }
      var grid = el('div', 'cart-grid'), list = el('div', 'cart-list');
      q.lines.forEach(function (l) {
        var row = el('div', 'cart-line');
        if (l.image) { var im = el('img'); im.src = l.image; im.alt = l.name; im.width = 84; im.height = 105; row.appendChild(im); } else { row.appendChild(el('div', 'product__ph', '—')); }
        var info = el('div'); var h = el('h3'); var link = el('a', '', l.name); link.href = '/product/' + encodeURIComponent(l.slug); h.appendChild(link); info.appendChild(h);
        info.appendChild(el('small', '', [l.size, l.color].filter(Boolean).join(' · ')));
        info.appendChild(el('small', '', money(l.unit_price)));
        var side = el('div', 'cart-line__side');
        var qty = el('div', 'qty'), minus = el('button', '', '−'), plus = el('button', '', '+'), inp = el('input'); minus.type = plus.type = 'button'; minus.setAttribute('aria-label', 'إنقاص'); plus.setAttribute('aria-label', 'زيادة');
        inp.type = 'number'; inp.min = '1'; inp.max = String(Math.min(99, l.stock)); inp.value = String(l.qty); inp.setAttribute('aria-label', 'الكمية'); inp.inputMode = 'numeric';
        var setQ = function (n) { n = Math.max(1, Math.min(l.stock, n || 1)); Cart.setQty(l.variantId, n); render(); };
        minus.addEventListener('click', function () { setQ(l.qty - 1); }); plus.addEventListener('click', function () { setQ(l.qty + 1); }); inp.addEventListener('change', function () { setQ(parseInt(inp.value, 10)); });
        qty.appendChild(minus); qty.appendChild(inp); qty.appendChild(plus);
        side.appendChild(el('b', '', money(l.line_total))); side.appendChild(qty);
        var rm = el('button', 'link-btn', 'حذف'); rm.type = 'button'; rm.addEventListener('click', function () { Cart.remove(l.variantId); render(); }); side.appendChild(rm);
        row.appendChild(info); row.appendChild(side); list.appendChild(row);
      });
      grid.appendChild(list);
      var sum = el('aside', 'co-summary'); sum.appendChild(el('h2', 'section-title', 'الملخص'));
      var dl = el('dl', 'totals');
      var r1 = el('div'); r1.appendChild(el('dt', '', 'المجموع الفرعي')); r1.appendChild(el('dd', '', money(q.subtotal))); dl.appendChild(r1);
      var r2 = el('div'); r2.appendChild(el('dt', '', 'التوصيل')); r2.appendChild(el('dd', '', 'يُحسب حسب الولاية')); dl.appendChild(r2);
      sum.appendChild(dl);
      sum.appendChild(el('p', 'pay-note', 'الدفع نقداً عند الاستلام. سعر التوصيل يظهر عند اختيار الولاية.'));
      var go = el('a', 'btn-solid btn-solid--lg btn-block', 'إتمام الطلب'); go.href = '/checkout'; sum.appendChild(go);
      var more = el('a', 'link-btn', 'متابعة التسوق'); more.href = '/shop'; sum.appendChild(more);
      grid.appendChild(sum); root.appendChild(grid);
    }).catch(function (e) { root.textContent = ''; root.appendChild(el('p', 'empty-note', 'تعذّر تحميل السلة: ' + e.message)); });
  }
  render();
})();
