/* الصفحة الرئيسية: شاشة التحميل، دخول البطل، البارالاكس، الخط المرن، الخاتمة. */
(function () {
  'use strict';
  var root = document.documentElement, FX = window.FX || { reduce: false, has: function () { return true; }, fine: false };
  var hero = document.getElementById('hero'), heroGiant = document.getElementById('heroGiant');
  if (FX.reduce) { return; }

  var heroChars = null;
  if (hero) {
    root.classList.add('fx-hero');
    if (heroGiant) { heroChars = window.splitLatinChars(heroGiant); heroChars.forEach(function (c, i) { c.style.transitionDelay = (i * 0.06) + 's'; }); }
    var ht = hero.querySelector('.hero__title'); if (ht) { window.splitWords(ht).forEach(function (s, i) { s.style.transitionDelay = (0.65 + i * 0.08) + 's'; }); }
  }
  function heroIn() { requestAnimationFrame(function () { requestAnimationFrame(function () { root.classList.add('hero-in'); }); }); }

  /* ---------- شاشة التحميل (مرة واحدة لكل جلسة) ---------- */
  var pre = document.getElementById('preloader'), seen = false;
  try { seen = sessionStorage.getItem('three_seen') === '1'; } catch (e) { /* ignore */ }
  if (pre && FX.has('preloader') && !seen) {
    try { sessionStorage.setItem('three_seen', '1'); } catch (e) { /* ignore */ }
    document.body.style.overflow = 'hidden';
    var chars = window.splitLatinChars(document.getElementById('preloaderBrand'));
    chars.forEach(function (c, i) { c.style.transitionDelay = (0.1 + i * 0.07) + 's'; });
    var bar = document.getElementById('preloaderProgress'), cnt = document.getElementById('preloaderCount');
    requestAnimationFrame(function () { pre.classList.add('is-in'); });
    var t0 = performance.now(), dur = 1500;
    (function step(t) {
      var p = Math.min(1, (t - t0) / dur), e = p < .5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2;
      bar.style.transform = 'scaleX(' + e + ')'; cnt.textContent = Math.round(e * 100) + '%';
      if (p < 1) { requestAnimationFrame(step); } else { finish(); }
    })(t0);
    var finish = function () {
      setTimeout(function () {
        pre.classList.add('is-done'); heroIn();
        setTimeout(function () { pre.classList.add('is-gone'); document.body.style.overflow = ''; }, 1250);
      }, 250);
    };
  } else {
    if (pre) { pre.classList.add('is-gone'); }
    heroIn();
  }

  /* ---------- البارالاكس + تكبير الشعار في الخاتمة ---------- */
  var giant = document.querySelector('.hero__giant'), orbit = document.querySelector('.hero__orbit'), ring = document.querySelector('.manifesto__ring'), finale = document.getElementById('finaleLogo');
  if (FX.has('parallax') && (giant || ring || finale)) {
    var ticking = false;
    var prog = function (el, startOffset) { var r = el.getBoundingClientRect(), h = window.innerHeight; return Math.min(1, Math.max(0, (h * startOffset - r.top) / (h * startOffset + r.height))); };
    var update = function () {
      ticking = false; var y = window.scrollY, h = window.innerHeight;
      if (hero && y < h * 1.2) {
        var p = Math.min(1, y / h);
        if (giant) { giant.style.translate = '0 ' + (p * 35) + '%'; }
        if (orbit) { orbit.style.translate = '0 ' + (-p * 14) + '%'; }
      }
      if (ring) { var pr = prog(ring.parentElement, 1); ring.style.rotate = (-8 + pr * 16) + 'deg'; ring.style.scale = String(0.9 + pr * 0.15); }
      if (finale) { var pf = Math.min(1, prog(finale.closest('.finale'), 0.9) * 1.8); finale.style.scale = String(0.4 + 0.6 * pf); finale.style.rotate = (-40 * (1 - pf)) + 'deg'; finale.style.opacity = String(0.3 + 0.7 * pf); }
    };
    window.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
    update();
  }

  /* ---------- الخط المرن ---------- */
  (function elastic() {
    var box = document.getElementById('elasticBox'), path = document.getElementById('elasticPath');
    if (!box || !path || !FX.fine || !FX.has('elastic')) { return; }
    var t = 0, a = 0.5, l = Math.PI / 2, raf = null;
    function upd(d) { path.setAttribute('d', 'M0 25 Q ' + (a * 100) + ' ' + (25 + d) + ', 100 25'); }
    function spring() { var d = t * Math.sin(l); t += (0 - t) * 0.025; l += 0.2; upd(d); if (Math.abs(t) > 0.75) { raf = requestAnimationFrame(spring); } else { upd(0); raf = null; } }
    box.addEventListener('mousemove', function (e) {
      var r = box.getBoundingClientRect(); a = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
      t = Math.min(60, Math.max(-60, t + (e.movementY || 0))); upd(t); if (!raf) { raf = requestAnimationFrame(spring); }
    });
    box.addEventListener('mouseleave', function () { if (!raf) { raf = requestAnimationFrame(spring); } });
  })();
})();
