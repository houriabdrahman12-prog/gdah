# THREE — Algerian streetwear store (Node.js + SQLite)

A real e-commerce website for the Algerian market: Arabic/RTL storefront, cart, cash-on-delivery checkout for all 58 wilayas, and a private admin dashboard (CMS) to run the whole store without touching code.

* **No npm dependencies are required.** It runs on Node.js 22.13+ using the built-in `node:sqlite`. (`sharp` is an *optional* image optimiser — see below.)
* Brand, logo, product photos and the cinematic animations from your original design are preserved.

## Quick start (your computer)

```bash
cd store
node -v                      # must print v22.13.0 or higher
npm run create-admin         # asks for a username + strong password (12+ chars). Creates the database too.
npm start                    # open http://localhost:3000   (admin: http://localhost:3000/admin)
npm test                     # runs the automated test-suite
```

Full instructions: [INSTALLATION.md](INSTALLATION.md) · Going public: [DEPLOYMENT.md](DEPLOYMENT.md) · Security: [SECURITY.md](SECURITY.md) · Backups: [BACKUP_AND_RESTORE.md](BACKUP_AND_RESTORE.md)

## What the owner can manage from `/admin`

Orders (status, notes, tracking, print, CSV, WhatsApp/call buttons) · Products (photos, sizes/colors/stock, sale price, featured, publish/hide/archive) · Categories, sizes, colors (these drive the shop filters) · Delivery fees per wilaya and method, free-delivery threshold · Homepage sections (show/hide/reorder/edit/add banners) · Design (colors, fonts, logo, favicon, animations on/off) · Menus · Pages (About, policies, new pages) · Store settings (name, phone, WhatsApp, Instagram, maintenance mode, announcement bar) · Admin users (owner/staff, optional 2-step login) · Audit log · Backups.

## First things to do after installing

1. **Products → open each of the 3 seeded products** → set the real price in DZD, stock per size, upload real photos, status **Published**. (They are seeded *hidden with price 0* because your original files only had prices in SAR.)
2. **Delivery** → the 58 wilaya fees are *placeholder estimates*. Replace them with your delivery company's real prices.
3. **Settings** → phone, WhatsApp number (the WhatsApp button appears once set), Instagram.
4. **Pages** → review the policy texts (delivery, returns, privacy, terms). They are generic templates, **not legal advice**.

## Project layout

```
server.js            HTTP server + routing
src/                 db, store logic (orders/stock), security, admin API, views, upload
src/migrations/      SQL migrations (applied automatically, backup taken first)
public/              css, js, assets, admin dashboard UI
scripts/             migrate, create-admin, backup, restore
test/                automated tests (node:test)
deploy/              Caddyfile + systemd unit (VPS option)
Dockerfile, fly.toml Fly.io deployment
```

## Honest status & limits

* Arabic/RTL only (wilaya names also carry French). No French/English UI switch.
* No online payment (by design). No email/SMS/push notification of new orders — **check the dashboard** (or contact the customer via the WhatsApp button on the order page).
* One server instance only (SQLite). Rate-limit counters live in memory and reset on restart.
* The logo JPEG has a black background; if you switch the site to a non-black theme, upload a transparent PNG logo in Design → Logo.
* Fonts load from Google Fonts (falls back to system Arabic fonts if blocked). Animations are hand-written (no GSAP/Lenis) so there are no third-party scripts.
* Without `sharp`, uploaded photos are stored as uploaded (resize them to ≲1600px wide before upload). With `sharp`, they are auto-resized to WebP with thumbnails and metadata stripped.
