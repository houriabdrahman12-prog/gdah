# Deployment — making the store public

**Nothing is published yet.** Uploading this folder or buying a domain does not publish a site by itself; you need a host that runs Node.js and has a **persistent disk** (the database and product photos live on disk — an ephemeral filesystem would lose your orders).

## Choosing a host

| Option | Approx. cost (check current prices) | Notes |
|---|---|---|
| **Fly.io** (config included) | The smallest machine is listed at ≈ $2.19/month and volumes at $0.15/GB-month ([fly.io/pricing](https://fly.io/pricing.md)); with 512MB RAM and a 3GB volume expect roughly **$4–7/month**. Outbound traffic to Africa is listed at **$0.12/GB**, so image-heavy traffic from Algeria adds cost. | Needs a bank card. No permanent free tier is promised. HTTPS and `*.fly.dev` subdomain included. |
| **Small VPS in Europe** (Hetzner, OVH, etc.) | A few euros/month — check the provider's current price list | Most control and cheaper bandwidth; needs basic Linux skills. Files in `deploy/`. |
| Render / Railway | Paid plan with a persistent disk required | Works if you attach a disk mounted at `DATA_DIR`. **Free plans with ephemeral disk are NOT suitable.** |

Pricing above comes from the provider pages at the time of writing and **can change** — confirm before paying. I could not deploy for you: it needs your account and payment.

## Option A — Fly.io (step by step)

1. Create an account at https://fly.io (a card is required) and install the CLI: https://fly.io/docs/flyctl/install/
2. In a terminal inside the `store` folder:
   ```bash
   fly auth login
   fly launch --no-deploy --copy-config      # accept fly.toml; when asked for a name, choose a unique one, e.g. three-dz
   ```
   Open `fly.toml` and make sure `app = "..."` and `SITE_URL = "https://<that-name>.fly.dev"` match.
3. Create the persistent volume (this is where orders and photos live):
   ```bash
   fly volumes create data --size 3 --region cdg
   ```
4. Deploy:
   ```bash
   fly deploy
   fly scale count 1        # IMPORTANT: SQLite must run on exactly one machine
   ```
5. Create the first administrator on the server (type your own password; it is never stored in files):
   ```bash
   fly ssh console
   node scripts/create-admin.js
   exit
   ```
6. Smoke test (replace the name):
   ```bash
   curl -i https://<name>.fly.dev/health          # 200 {"ok":true}
   ```
   Then open `https://<name>.fly.dev/` on your phone, add a product to the cart, place a **test order**, log in at `/admin`, open the order, and **cancel it** (cancelling returns stock).
7. Updating later: change files, run `fly deploy`. Data on the volume is untouched. Migrations run automatically (a backup is taken first).
8. Backups: see BACKUP_AND_RESTORE.md. Also enable volume snapshots: `fly volumes list` shows snapshots Fly keeps for volumes.

## Option B — VPS (Ubuntu) outline

```bash
# as root
apt update && apt install -y curl caddy
curl -fsSL https://deb.nodesource.com/setup_22.x | bash - && apt install -y nodejs
adduser --system --group --home /opt/three-store store
# copy the project to /opt/three-store (scp / git), then:
mkdir -p /var/lib/three-store && chown store:store /var/lib/three-store
cd /opt/three-store && sudo -u store npm install --omit=dev
sudo -u store DATA_DIR=/var/lib/three-store node scripts/create-admin.js
cp deploy/three-store.service /etc/systemd/system/    # edit SITE_URL inside
systemctl daemon-reload && systemctl enable --now three-store
cp deploy/Caddyfile /etc/caddy/Caddyfile              # edit the domain
systemctl reload caddy
```
Caddy obtains and renews the HTTPS certificate automatically. `systemd` restarts the app if it crashes. Logs: `journalctl -u three-store -f`.

## Domains and HTTPS
* A **domain** is the address people type (e.g. `three-dz.com`). It is **optional**: Fly gives you `https://<name>.fly.dev` with HTTPS for free, which is enough to launch.
* To use your own domain: buy one from any registrar; on Fly run `fly certs add yourdomain.com` and create the DNS records Fly prints (an `A`/`AAAA` or `CNAME`); wait until `fly certs show yourdomain.com` says issued. Then change `SITE_URL` in `fly.toml` and `fly deploy`. (.dz domains are sold by Algerian registrars and may require business paperwork.)
* HTTPS certificates are issued/renewed automatically by Fly or Caddy.

## Monitoring and health checks
`/health` returns `{"ok":true}` when the app and database respond; Fly and the Docker image already poll it. For alerts, add a free uptime monitor (e.g. UptimeRobot) on that URL. Logs: `fly logs`.

## Status of this deployment kit
`fly.toml`, `Dockerfile`, `Caddyfile` and the systemd unit were written but **not executed here** (no Fly account and no Docker daemon in my environment). The application itself (server, database, tests) was run and tested — see the final report. If a deploy command errors, copy the error message and ask for help.
