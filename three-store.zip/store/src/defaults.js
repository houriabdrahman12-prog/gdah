'use strict';
// First-run defaults. Everything here is editable from the admin dashboard.
const settings = {
  store: {
    name: 'THREE',
    tagline: 'قصةُ ثلاثةِ أصدقاء',
    description: 'THREE — قصة ثلاثة أصدقاء. متجر ملابس ستريت وير جزائري: هوديات، تيشيرتات وقبعات بشعار المدار والنجمة.',
    phone: '', whatsapp: '', email: '', instagram: '', facebook: '', tiktok: '', address: '',
    currency_label: 'د.ج',
  },
  status: { open: true, maintenance_message: 'المتجر مغلق مؤقتاً للصيانة، سنعود قريباً.' },
  announcement: { enabled: false, text: '', url: '' },
  delivery: { home_enabled: true, desk_enabled: true, cod_enabled: true, free_threshold: 0, info: 'التوصيل إلى جميع الولايات الـ٥٨. الدفع نقداً عند الاستلام. سيتصل بك فريقنا هاتفياً لتأكيد الطلب.' },
  theme: {
    bg: '#000000', bg_soft: '#0a0a0a', surface: '#111111', ink: '#f5f5f5', ink_dim: '#9a9d9f', accent: '#f5f5f5', accent_ink: '#000000',
    font_display: 'Noto Kufi Arabic', font_body: 'IBM Plex Sans Arabic', font_latin: 'Archivo',
    logo_size: 40, base_font_size: 16,
  },
  anim: { preloader: true, cursor: true, reveal: true, words: true, parallax: true, marquee: true, elastic: true, orbit: true, hover: true },
  branding: { logo: '/assets/logo.jpeg', favicon: '/assets/logo.jpeg', og_image: '/assets/logo.jpeg' },
  seo: { title_suffix: ' — THREE', default_description: '' },
  footer: { text: '', show_marquee: true },
};

const mdPolicy = (t) => t;
const pages = [
  { slug: 'about', title: 'من نحن', content:
`# قصة THREE
بدأت الحكاية بثلاثة أصدقاء يجمعهم الإيمان بأن البساطة أعلى درجات الأناقة. THREE علامة ملابس ستريت وير جزائرية بهوية أبيض وأسود، شعارها كتابة عربية حرة يطوّقها مدار ونجمة.

# رؤيتنا
نصنع قطعاً بسيطة وعصرية تحمل هويتنا، ونحرص على تجربة شراء سهلة وموثوقة لكل زبائننا في الولايات الـ٥٨.

> هذه الصفحة قابلة للتعديل من لوحة التحكم (الصفحات ← من نحن).` },
  { slug: 'contact', title: 'اتصل بنا', content:
`# تواصل معنا
يمكنك التواصل معنا عبر الهاتف أو واتساب أو إنستغرام، وستجد بيانات التواصل الحالية أسفل كل صفحة من الموقع.

نرد على الرسائل في أقرب وقت ممكن.` },
  { slug: 'delivery', title: 'سياسة التوصيل', content:
`# التوصيل
- نوصل إلى جميع الولايات الجزائرية الـ٥٨.
- يختلف سعر التوصيل حسب الولاية وطريقة التوصيل (إلى المنزل أو إلى مكتب التسليم)، ويظهر بوضوح قبل تأكيد الطلب.
- الدفع نقداً عند الاستلام، ولا يوجد دفع إلكتروني.
- بعد تسجيل طلبك سيتصل بك فريقنا لتأكيده، ثم يُشحن الطلب.
- يرجى إبقاء هاتفك مفتوحاً حتى يتمكن المندوب من الوصول إليك.` },
  { slug: 'returns', title: 'سياسة الاستبدال والإرجاع', content:
`# الاستبدال والإرجاع
- يُرجى فحص الطلب عند الاستلام بحضور المندوب.
- لأي مشكلة في المقاس أو العيوب، تواصل معنا بأسرع وقت عبر الهاتف أو واتساب.
- تُحدَّد مدة وشروط الاستبدال من قِبل صاحب المتجر؛ عدّل هذا النص من لوحة التحكم ليعكس سياستكم الفعلية.` },
  { slug: 'privacy', title: 'سياسة الخصوصية', content:
`# الخصوصية
نجمع فقط المعلومات اللازمة لتنفيذ طلبك: الاسم، رقم الهاتف، الولاية، البلدية، وعنوان التوصيل.
- نستخدم هذه المعلومات حصراً لتأكيد الطلب وتوصيله والتواصل معك بشأنه.
- لا نبيع بياناتك ولا نشاركها مع أطراف أخرى إلا شركة التوصيل عند الحاجة لتسليم الطلب.
- لا نطلب أي معلومات بنكية، فالدفع عند الاستلام.
- يمكنك طلب حذف بياناتك بالتواصل معنا.` },
  { slug: 'terms', title: 'الشروط والأحكام', content:
`# الشروط والأحكام
- بإرسال طلبك فإنك تؤكد صحة المعلومات المُدخلة.
- الأسعار بالدينار الجزائري وقد تتغير دون إشعار مسبق، والسعر المعتمد هو الظاهر وقت تأكيد الطلب.
- نحتفظ بحق إلغاء أي طلب في حال نفاد المخزون أو تعذّر التواصل مع الزبون.
- يلتزم المتجر بتسليم الطلب بالمواصفات المعروضة.
- عدّل هذا النص من لوحة التحكم ليتوافق مع شروط متجرك.` },
];

const nav = [
  ['header', 'القصة', '/#story'], ['header', 'المتجر', '/shop'], ['header', 'من نحن', '/p/about'], ['header', 'اتصل بنا', '/p/contact'],
  ['footer', 'المتجر', '/shop'], ['footer', 'من نحن', '/p/about'], ['footer', 'سياسة التوصيل', '/p/delivery'],
  ['footer', 'الاستبدال والإرجاع', '/p/returns'], ['footer', 'الخصوصية', '/p/privacy'], ['footer', 'الشروط والأحكام', '/p/terms'],
];

const sections = [
  { type: 'hero', title: 'الواجهة الرئيسية', data: {
    giant: 'THREE', kicker: 'A STORY OF THREE FRIENDS', title: 'قصةُ ثلاثةِ أصدقاءٍ، تُروى بالأبيضِ والأسود',
    button_text: 'اكتشف المجموعة', button_url: '/shop', media_type: 'logo', media: '/assets/logo.jpeg', video_poster: '' } },
  { type: 'marquee', title: 'الشريط المتحرك', data: { text: 'THREE ✦ قصةُ ثلاثةِ أصدقاء ✦ EST. 2024 ✦ أبيض ✦ أسود ✦' } },
  { type: 'story', title: 'القصة', data: {
    label: '٠١ — القصة', heading: 'ثلاثةُ أصدقاء… مدارٌ واحد',
    paragraphs: ['بدأت الحكاية حول طاولةٍ صغيرة، بثلاثةِ أصدقاءٍ يؤمنون أنّ البساطة أعلى درجات الأناقة. لا ألوانَ صاخبة، لا ضجيج — فقط أبيضٌ وأسود، ومدارٌ يجمعنا.',
      'كلُّ قطعةٍ نصنعها تحمل حرفاً من حكايتنا: النجمةُ ترمز إلى الحلم، والمدارُ إلى الصداقة التي لا تنقطع، والخطُّ العربيُّ الحرُّ إلى هويّتنا.'],
    image: '/assets/logo.jpeg', caption: 'الشعار الأصلي — كما رُسم أول مرة',
    stats: [{ value: '3', label: 'أصدقاء' }, { value: '1', label: 'رؤية واحدة' }, { value: '∞', label: 'شغف' }] } },
  { type: 'products', title: 'المجموعة', data: {
    label: '٠٢ — المجموعة', heading: 'ثلاثُ قطعٍ، لثلاثةِ أصدقاء', source: 'featured', category_id: 0, limit: 6,
    button_text: 'عرض كل المنتجات', button_url: '/shop' } },
  { type: 'manifesto', title: 'البيان', data: { label: '٠٣ — البيان', line1: 'لا نصنعُ ملابس،', line2: 'بل ننسجُ صداقةً تُلبَس.' } },
  { type: 'finale', title: 'الخاتمة', data: {
    label: '٠٤ — النهاية', heading: 'النهايةُ… بدايةٌ أخرى', image: '/assets/logo.jpeg', button_text: 'تسوّق الآن', button_url: '/shop' } },
];

const sizes = ['S', 'M', 'L', 'XL', 'XXL', 'مقاس موحّد'];
const colors = [['أسود', '#000000'], ['أبيض', '#ffffff']];
const categories = [['hoodies', 'هوديات'], ['tshirts', 'تيشيرتات'], ['caps', 'قبعات'], ['accessories', 'إكسسوارات']];

// The three products from the original design. They are seeded as HIDDEN drafts with price 0 and no stock:
// the original files only had prices in the wrong currency (SAR), so the owner must set real DZD prices + stock.
const products = [
  { slug: 'orbit-hoodie', name: 'هودي المدار', description: 'هودي أسود أوفرسايز بشعار المدار والنجمة.', category: 'hoodies', price: 0,
    image: '/assets/product-1.jpg', alt: 'هودي THREE الأسود بشعار المدار والنجمة', sizes: ['S', 'M', 'L', 'XL'], colors: ['أسود'] },
  { slug: 'star-tshirt', name: 'تيشيرت النجمة', description: 'تيشيرت أسود بشعار المدار والنجمة.', category: 'tshirts', price: 0,
    image: '/assets/product-2.jpg', alt: 'تيشيرت THREE الأسود بشعار المدار والنجمة', sizes: ['S', 'M', 'L', 'XL'], colors: ['أسود'] },
  { slug: 'friendship-cap', name: 'قبعة الصداقة', description: 'قبعة سوداء بتطريز أبيض.', category: 'caps', price: 0,
    image: '/assets/product-3.jpg', alt: 'قبعة THREE السوداء بشعار مطرّز', sizes: ['مقاس موحّد'], colors: ['أسود'] },
];

module.exports = { settings, pages, nav, sections, sizes, colors, categories, products };
