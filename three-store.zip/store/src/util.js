'use strict';
const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ESC[c]);

function slugify(s) {
  const base = String(s || '').trim().toLowerCase()
    .replace(/[ً-ٰٟ]/g, '')             // Arabic diacritics
    .replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '').slice(0, 80);
  return base || 'item';
}

/** Western-digit price: 2500 -> "2 500 د.ج" */
function money(n, label = 'د.ج') {
  const v = Math.round(Number(n) || 0);
  return v.toString() + '\u00A0' + label;   // no digit grouping: avoids bidi reordering in RTL text
}

/** Algerian phone: accepts 05/06/07 mobiles and 02x/03x/04x landlines; +213 / 00213 / 0 prefixes. Returns "0XXXXXXXXX" or null. */
function normalizePhone(input) {
  let p = String(input || '').replace(/[\s.\-()]/g, '');
  p = p.replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
  if (p.startsWith('+213')) p = '0' + p.slice(4);
  else if (p.startsWith('00213')) p = '0' + p.slice(5);
  else if (/^213\d{9}$/.test(p)) p = '0' + p.slice(3);
  if (/^0[567]\d{8}$/.test(p)) return p;
  if (/^0[234]\d{7,8}$/.test(p)) return p;
  return null;
}
const waNumber = (phone) => { const d = String(phone || '').replace(/\D/g, ''); if (!d) return ''; if (d.startsWith('213')) return d; if (d.startsWith('00')) return d.slice(2); if (d.startsWith('0')) return '213' + d.slice(1); return d; };

/** Safe mini-markup → HTML (escape first, then format). # h2, ## h3, - list, > note, **bold**, [text](url) for http(s)/relative links. */
function renderMarkup(text) {
  const inline = (s) => esc(s)
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\[([^\]]+)\]\(((?:https?:\/\/|\/)[^)\s]*)\)/g, (m, t, u) => `<a href="${u}" rel="noopener noreferrer">${t}</a>`);
  const out = []; let list = false; let para = [];
  const flushP = () => { if (para.length) { out.push('<p>' + para.join('<br>') + '</p>'); para = []; } };
  const closeL = () => { if (list) { out.push('</ul>'); list = false; } };
  for (const raw of String(text || '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) { flushP(); closeL(); continue; }
    let m;
    if ((m = line.match(/^##\s+(.*)$/))) { flushP(); closeL(); out.push(`<h3>${inline(m[1])}</h3>`); }
    else if ((m = line.match(/^#\s+(.*)$/))) { flushP(); closeL(); out.push(`<h2>${inline(m[1])}</h2>`); }
    else if ((m = line.match(/^[-*]\s+(.*)$/))) { flushP(); if (!list) { out.push('<ul>'); list = true; } out.push(`<li>${inline(m[1])}</li>`); }
    else if ((m = line.match(/^>\s?(.*)$/))) { flushP(); closeL(); out.push(`<blockquote>${inline(m[1])}</blockquote>`); }
    else { closeL(); para.push(inline(line)); }
  }
  flushP(); closeL();
  return out.join('\n');
}

/** Only allow internal paths and http(s) URLs (blocks javascript:, data:, etc.). */
function safeUrl(u, fallback = '#') {
  u = String(u || '').trim();
  if (/^\/(?!\/)[^\s]*$/.test(u) || /^#[\w-]*$/.test(u)) return u;
  if (/^https?:\/\/[^\s]+$/i.test(u)) return u;
  if (/^(tel:\+?[\d]+|mailto:[^\s@]+@[^\s@]+)$/i.test(u)) return u;
  return fallback;
}
/** Only allow our own asset/upload paths for images. */
const safeImg = (u) => (/^\/(uploads|assets)\/[\w.\-]+$/.test(String(u || '')) ? u : '');
const safeHex = (c, fb) => (/^#[0-9a-fA-F]{6}$/.test(String(c)) ? c : fb);

const clampInt = (v, min, max, fb = min) => { const n = parseInt(v, 10); return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fb; };
/** Strict integer: returns null unless v is an integer within [min,max] (no silent clamping). */
const strictInt = (v, min, max) => { const n = typeof v === 'number' ? v : (typeof v === 'string' && /^-?\d{1,12}$/.test(v.trim()) ? parseInt(v, 10) : NaN); return Number.isInteger(n) && n >= min && n <= max ? n : null; };
const str = (v, max = 500) => String(v ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, max);

module.exports = { esc, slugify, money, normalizePhone, waNumber, renderMarkup, safeUrl, safeImg, safeHex, clampInt, strictInt, str };
