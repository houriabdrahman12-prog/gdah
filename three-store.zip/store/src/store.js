'use strict';
const crypto = require('node:crypto');
const db = require('./db');
const defaults = require('./defaults');
const { normalizePhone, str, clampInt, strictInt } = require('./util');
const { HttpError } = require('./http');

/* ---------------- Settings (cached, invalidated on write) ---------------- */
let cache = null; let version = 1;
function loadSettings() {
  const out = {};
  for (const [k, v] of Object.entries(defaults.settings)) out[k] = structuredClone(v);
  for (const r of db.get().prepare('SELECT key,value FROM settings').all()) {
    if (r.key === 'app_secret') continue;
    try { const v = JSON.parse(r.value); out[r.key] = (v && typeof v === 'object' && !Array.isArray(v)) ? { ...(out[r.key] || {}), ...v } : v; } catch {}
  }
  cache = out; return out;
}
const settings = () => cache || loadSettings();
const S = (k) => settings()[k] || {};
function setSetting(key, value) {
  db.get().prepare(`INSERT INTO settings(key,value,updated_at) VALUES (?,?,datetime('now')) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at`).run(key, JSON.stringify(value));
  cache = null; version++;
}
const settingsVersion = () => version;
function invalidate() { cache = null; version++; }

function appSecret() {
  const d = db.get(); let r = d.prepare("SELECT value FROM settings WHERE key='app_secret'").get();
  if (!r) { d.prepare("INSERT INTO settings(key,value) VALUES ('app_secret',?)").run(JSON.stringify(crypto.randomBytes(32).toString('hex'))); r = d.prepare("SELECT value FROM settings WHERE key='app_secret'").get(); }
  return JSON.parse(r.value);
}
const orderToken = (ref) => crypto.createHmac('sha256', appSecret()).update('order:' + ref).digest('base64url').slice(0, 22);

/* ---------------- Products ---------------- */
const effPrice = (p) => (p.sale_price != null && p.sale_price > 0 && p.sale_price < p.price ? p.sale_price : p.price);

function decorate(rows) {
  if (!rows.length) return rows;
  const d = db.get(); const ids = rows.map(r => r.id); const ph = ids.map(() => '?').join(',');
  const imgs = d.prepare(`SELECT * FROM product_images WHERE product_id IN (${ph}) ORDER BY sort, id`).all(...ids);
  const vars = d.prepare(`SELECT * FROM product_variants WHERE product_id IN (${ph}) ORDER BY id`).all(...ids);
  for (const r of rows) {
    r.images = imgs.filter(i => i.product_id === r.id);
    r.variants = vars.filter(v => v.product_id === r.id);
    r.stock = r.variants.reduce((a, v) => a + v.stock, 0);
    r.in_stock = r.stock > 0;
    r.final_price = effPrice(r);
    r.on_sale = r.final_price < r.price;
  }
  return rows;
}

/** Public catalogue query. All filters run on real DB data. */
function listProducts(o = {}) {
  const d = db.get(); const where = ["p.status = 'published'"]; const args = [];
  if (o.q) { where.push('(p.name LIKE ? ESCAPE \'\\\' OR p.description LIKE ? ESCAPE \'\\\' OR p.tags LIKE ? ESCAPE \'\\\')'); const l = '%' + String(o.q).replace(/[\\%_]/g, '\\$&') + '%'; args.push(l, l, l); }
  if (o.category) { where.push('c.slug = ?'); args.push(o.category); }
  if (o.featured) where.push('p.featured = 1');
  if (o.isNew) where.push('p.is_new = 1');
  if (o.sale) where.push('p.sale_price IS NOT NULL AND p.sale_price > 0 AND p.sale_price < p.price');
  if (o.size) { where.push('EXISTS (SELECT 1 FROM product_variants v WHERE v.product_id=p.id AND v.size=? AND v.stock>0)'); args.push(o.size); }
  if (o.color) { where.push('EXISTS (SELECT 1 FROM product_variants v WHERE v.product_id=p.id AND v.color=? AND v.stock>0)'); args.push(o.color); }
  const eff = 'CASE WHEN p.sale_price IS NOT NULL AND p.sale_price > 0 AND p.sale_price < p.price THEN p.sale_price ELSE p.price END';
  if (o.min != null) { where.push(`${eff} >= ?`); args.push(o.min); }
  if (o.max != null) { where.push(`${eff} <= ?`); args.push(o.max); }
  const order = { price_asc: `${eff} ASC`, price_desc: `${eff} DESC`, newest: 'p.created_at DESC, p.id DESC' }[o.sort] || 'p.featured DESC, p.created_at DESC, p.id DESC';
  const per = clampInt(o.perPage, 1, 60, 12), page = clampInt(o.page, 1, 10000, 1);
  const from = `FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE ${where.join(' AND ')} AND (c.id IS NULL OR c.visible = 1)`;
  const total = d.prepare(`SELECT COUNT(*) n ${from}`).get(...args).n;
  const rows = d.prepare(`SELECT p.*, c.name AS category_name, c.slug AS category_slug ${from} ORDER BY ${order} LIMIT ? OFFSET ?`).all(...args, per, (page - 1) * per);
  return { items: decorate(rows), total, page, pages: Math.max(1, Math.ceil(total / per)) };
}
function getProductBySlug(slug, { includeHidden = false } = {}) {
  const r = db.get().prepare(`SELECT p.*, c.name AS category_name, c.slug AS category_slug FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.slug=?`).get(slug);
  if (!r || (!includeHidden && r.status !== 'published')) return null;
  return decorate([r])[0];
}
function getProductById(id) {
  const r = db.get().prepare(`SELECT p.*, c.name AS category_name, c.slug AS category_slug FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=?`).get(id);
  return r ? decorate([r])[0] : null;
}
function relatedProducts(p, n = 4) {
  const d = db.get();
  let rows = d.prepare(`SELECT p.* FROM product_related pr JOIN products p ON p.id=pr.related_id WHERE pr.product_id=? AND p.status='published'`).all(p.id);
  if (rows.length < n) {
    const have = new Set([p.id, ...rows.map(r => r.id)]);
    const more = d.prepare(`SELECT * FROM products WHERE status='published' AND id != ? AND (category_id IS ? ) ORDER BY created_at DESC LIMIT 12`).all(p.id, p.category_id);
    for (const m of more) if (!have.has(m.id) && rows.length < n) { rows.push(m); have.add(m.id); }
    if (rows.length < n) for (const m of d.prepare(`SELECT * FROM products WHERE status='published' AND id != ? ORDER BY created_at DESC LIMIT 12`).all(p.id)) if (!have.has(m.id) && rows.length < n) { rows.push(m); have.add(m.id); }
  }
  return decorate(rows.slice(0, n));
}
function filterOptions() {
  const d = db.get();
  return {
    categories: d.prepare('SELECT * FROM categories WHERE visible=1 ORDER BY sort,id').all(),
    sizes: d.prepare('SELECT * FROM sizes WHERE visible=1 ORDER BY sort,id').all(),
    colors: d.prepare('SELECT * FROM colors WHERE visible=1 ORDER BY sort,id').all(),
  };
}

/* ---------------- Delivery + quoting ---------------- */
function deliveryFee(subtotal, wilayaCode, method) {
  const del = S('delivery');
  const w = db.get().prepare('SELECT * FROM wilayas WHERE code=?').get(wilayaCode);
  if (!w || !w.enabled) throw new HttpError(400, 'التوصيل غير متاح لهذه الولاية');
  if (method === 'home' && !del.home_enabled) throw new HttpError(400, 'التوصيل إلى المنزل غير متاح حالياً');
  if (method === 'desk' && !del.desk_enabled) throw new HttpError(400, 'التوصيل إلى المكتب غير متاح حالياً');
  if (method !== 'home' && method !== 'desk') throw new HttpError(400, 'طريقة التوصيل غير صالحة');
  let fee = method === 'home' ? w.fee_home : w.fee_desk;
  const free = del.free_threshold > 0 && subtotal >= del.free_threshold;
  if (free) fee = 0;
  return { wilaya: w, fee, free };
}

/** Rebuild cart lines from the DB. Never trusts client prices. Returns { lines, problems, subtotal }. */
function priceLines(items) {
  if (!Array.isArray(items)) throw new HttpError(400, 'السلة غير صالحة');
  if (items.length > 50) throw new HttpError(400, 'عدد المنتجات كبير جداً');
  const d = db.get(); const lines = [], problems = []; let subtotal = 0;
  const merged = new Map();
  for (const it of items) {
    const vid = strictInt(it && it.variantId, 1, 2 ** 31), qty = strictInt(it && it.qty, 1, 99);
    if (!vid || !qty) { problems.push({ variantId: vid, code: 'invalid', message: 'عنصر غير صالح' }); continue; }
    merged.set(vid, (merged.get(vid) || 0) + qty);
  }
  for (const [vid, want] of merged) {
    const r = d.prepare(`SELECT v.id vid, v.size, v.color, v.stock, p.id pid, p.slug, p.name, p.price, p.sale_price, p.status
      FROM product_variants v JOIN products p ON p.id=v.product_id WHERE v.id=?`).get(vid);
    if (!r || r.status !== 'published') { problems.push({ variantId: vid, code: 'unavailable', message: 'منتج لم يعد متاحاً' }); continue; }
    const img = d.prepare('SELECT file, thumb FROM product_images WHERE product_id=? ORDER BY sort,id LIMIT 1').get(r.pid);
    const unit = effPrice(r);
    if (unit <= 0) { problems.push({ variantId: vid, code: 'unavailable', message: 'منتج غير متاح للطلب' }); continue; }
    if (r.stock <= 0) { problems.push({ variantId: vid, code: 'out_of_stock', name: r.name, message: `${r.name} نفد من المخزون` }); continue; }
    const qty = Math.min(want, r.stock);
    if (qty < want) problems.push({ variantId: vid, code: 'reduced', name: r.name, message: `تم تعديل كمية ${r.name} إلى ${qty} حسب المخزون المتاح` });
    lines.push({ variantId: vid, productId: r.pid, slug: r.slug, name: r.name, size: r.size, color: r.color, unit_price: unit, qty, line_total: unit * qty, image: img ? (img.thumb || img.file) : '', full_image: img ? img.file : '', stock: r.stock });
    subtotal += unit * qty;
  }
  return { lines, problems, subtotal };
}

function quote(items, wilayaCode, method) {
  const { lines, problems, subtotal } = priceLines(items);
  let fee = null, free = false, wilaya = null;
  if (wilayaCode !== undefined && wilayaCode !== null && wilayaCode !== 0 && wilayaCode !== '') { const wc = strictInt(wilayaCode, 1, 58); if (!wc) throw new HttpError(400, 'ولاية غير صالحة');
    const f = deliveryFee(subtotal, wc, method || 'home'); fee = f.fee; free = f.free; wilaya = f.wilaya.name_ar; }
  return { lines, problems, subtotal, delivery_fee: fee, free_delivery: free, wilaya, total: subtotal + (fee || 0) };
}

/* ---------------- Orders ---------------- */
const REF_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function newRef() {
  const d = new Date(); const ymd = String(d.getUTCFullYear()).slice(2) + String(d.getUTCMonth() + 1).padStart(2, '0') + String(d.getUTCDate()).padStart(2, '0');
  let s = ''; for (const b of crypto.randomBytes(5)) s += REF_CHARS[b % REF_CHARS.length];
  return `T3-${ymd}-${s}`;
}

function validateCustomer(b) {
  const errors = {};
  const name = str(b.name, 80); if (name.length < 3 || !/\p{L}/u.test(name)) errors.name = 'الاسم الكامل مطلوب';
  const phone = normalizePhone(b.phone); if (!phone) errors.phone = 'رقم هاتف جزائري غير صالح (مثال: 0555123456)';
  const wilaya = strictInt(b.wilaya, 1, 58); if (!wilaya) errors.wilaya = 'اختر الولاية';
  const commune = str(b.commune, 80); if (commune.length < 2) errors.commune = 'أدخل البلدية';
  const address = str(b.address, 250); if (address.length < 5) errors.address = 'أدخل عنوان التوصيل';
  const notes = str(b.notes, 300);
  const method = b.method === 'desk' ? 'desk' : b.method === 'home' ? 'home' : '';
  if (!method) errors.method = 'اختر طريقة التوصيل';
  return { errors, v: { name, phone, wilaya, commune, address, notes, method } };
}

function createOrder(body, idemKey) {
  const { errors, v } = validateCustomer(body);
  if (Object.keys(errors).length) throw new HttpError(422, 'تحقق من البيانات المدخلة', { errors });
  if (!S('delivery').cod_enabled) throw new HttpError(400, 'الطلب غير متاح حالياً');
  idemKey = idemKey && /^[\w-]{16,64}$/.test(idemKey) ? idemKey : null;
  return db.tx((d) => {
    if (idemKey) {
      const ex = d.prepare('SELECT ref FROM orders WHERE idem_key=?').get(idemKey);
      if (ex) return { ref: ex.ref, token: orderToken(ex.ref), duplicate: true };
    }
    const { lines, problems, subtotal } = priceLines(body.items);
    const blocking = problems.filter(p => p.code !== 'reduced');
    if (blocking.length || problems.length || !lines.length) {
      throw new HttpError(409, problems[0] ? problems[0].message : 'السلة فارغة', { problems, stale: true });
    }
    const f = deliveryFee(subtotal, v.wilaya, v.method);
    const total = subtotal + f.fee;
    let ref; for (let i = 0; i < 8; i++) { ref = newRef(); if (!d.prepare('SELECT 1 FROM orders WHERE ref=?').get(ref)) break; }
    const tok = orderToken(ref);
    const r = d.prepare(`INSERT INTO orders(ref,token_hash,idem_key,customer_name,phone,wilaya_code,wilaya_name,commune,address,customer_notes,delivery_method,subtotal,delivery_fee,total)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(ref, crypto.createHash('sha256').update(tok).digest('hex'), idemKey, v.name, v.phone, v.wilaya, f.wilaya.name_ar, v.commune, v.address, v.notes, v.method, subtotal, f.fee, total);
    const oid = Number(r.lastInsertRowid);
    for (const l of lines) {
      const u = d.prepare('UPDATE product_variants SET stock = stock - ? WHERE id=? AND stock >= ?').run(l.qty, l.variantId, l.qty);
      if (u.changes !== 1) throw new HttpError(409, `نفد المخزون: ${l.name}`, { stale: true });
      d.prepare('INSERT INTO order_items(order_id,product_id,variant_id,name,size,color,unit_price,qty,image) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(oid, l.productId, l.variantId, l.name, l.size, l.color, l.unit_price, l.qty, l.image);
    }
    d.prepare("INSERT INTO order_events(order_id,event,detail) VALUES (?,'created','')").run(oid);
    return { ref, token: tok, duplicate: false, total };
  });
}

function getOrderPublic(ref, token) {
  const d = db.get(); const o = d.prepare('SELECT * FROM orders WHERE ref=?').get(String(ref || ''));
  const exp = o ? orderToken(o.ref) : '';
  const ok = o && typeof token === 'string' && token.length === exp.length && crypto.timingSafeEqual(Buffer.from(token), Buffer.from(exp));
  if (!ok) return null;
  o.items = d.prepare('SELECT * FROM order_items WHERE order_id=?').all(o.id);
  return o;
}

const STATUSES = ['new', 'pending', 'confirmed', 'shipped', 'delivered', 'cancelled'];
/** Change status; cancelling returns stock, un-cancelling takes it again (or fails if insufficient). */
function setOrderStatus(orderId, status, { reason = '', adminId = null } = {}) {
  if (!STATUSES.includes(status)) throw new HttpError(400, 'حالة غير صالحة');
  return db.tx((d) => {
    const o = d.prepare('SELECT * FROM orders WHERE id=?').get(orderId);
    if (!o) throw new HttpError(404, 'الطلب غير موجود');
    if (o.status === status) return o;
    const items = d.prepare('SELECT * FROM order_items WHERE order_id=?').all(orderId);
    if (status === 'cancelled') {
      for (const it of items) if (it.variant_id) d.prepare('UPDATE product_variants SET stock = stock + ? WHERE id=?').run(it.qty, it.variant_id);
    } else if (o.status === 'cancelled') {
      for (const it of items) if (it.variant_id) {
        const u = d.prepare('UPDATE product_variants SET stock = stock - ? WHERE id=? AND stock >= ?').run(it.qty, it.variant_id, it.qty);
        if (u.changes !== 1) throw new HttpError(409, `المخزون غير كافٍ لإعادة تفعيل الطلب: ${it.name}`);
      }
    }
    d.prepare("UPDATE orders SET status=?, cancel_reason=?, updated_at=datetime('now') WHERE id=?").run(status, status === 'cancelled' ? str(reason, 300) : '', orderId);
    d.prepare('INSERT INTO order_events(order_id,admin_id,event,detail) VALUES (?,?,?,?)').run(orderId, adminId, 'status', `${o.status} → ${status}${reason ? ': ' + str(reason, 300) : ''}`);
    return d.prepare('SELECT * FROM orders WHERE id=?').get(orderId);
  });
}

/* ---------------- Dashboard stats ---------------- */
function dashboard() {
  const d = db.get();
  const by = Object.fromEntries(STATUSES.map(s => [s, 0]));
  for (const r of d.prepare('SELECT status, COUNT(*) n FROM orders GROUP BY status').all()) by[r.status] = r.n;
  const sum = (sts) => d.prepare(`SELECT COALESCE(SUM(total),0) s FROM orders WHERE status IN (${sts.map(() => '?').join(',')})`).get(...sts).s;
  const low = d.prepare(`SELECT p.id, p.name, SUM(v.stock) stock FROM products p JOIN product_variants v ON v.product_id=p.id WHERE p.status='published' GROUP BY p.id HAVING stock <= 5 ORDER BY stock, p.name LIMIT 20`).all();
  const todayN = d.prepare("SELECT COUNT(*) n FROM orders WHERE date(created_at)=date('now')").get().n;
  return {
    orders_total: Object.values(by).reduce((a, b) => a + b, 0), by_status: by, orders_today: todayN,
    revenue_recorded: sum(['new', 'pending', 'confirmed', 'shipped', 'delivered']),   // all non-cancelled orders (NOT money collected)
    revenue_confirmed: sum(['confirmed', 'shipped', 'delivered']),
    revenue_collected: sum(['delivered']),                                           // cash-on-delivery: delivered ≈ collected
    products_total: d.prepare("SELECT COUNT(*) n FROM products WHERE status!='archived'").get().n,
    products_published: d.prepare("SELECT COUNT(*) n FROM products WHERE status='published'").get().n,
    low_stock: low,
    recent: d.prepare('SELECT id,ref,customer_name,wilaya_name,total,status,created_at FROM orders ORDER BY id DESC LIMIT 8').all(),
  };
}

module.exports = {
  S, settings, setSetting, settingsVersion, invalidate, appSecret, orderToken, effPrice,
  listProducts, getProductBySlug, getProductById, relatedProducts, filterOptions, decorate,
  deliveryFee, priceLines, quote, createOrder, getOrderPublic, setOrderStatus, validateCustomer, dashboard, STATUSES,
};
