'use strict';
const crypto = require('node:crypto');
const db = require('./db');
const config = require('./config');

/* ---------- Password hashing (scrypt) ---------- */
const SCRYPT = { N: 32768, r: 8, p: 1, keylen: 64, maxmem: 128 * 1024 * 1024 };
function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(password, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p, maxmem: SCRYPT.maxmem });
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${key.toString('base64')}`;
}
function verifyPassword(password, stored) {
  try {
    const [alg, N, r, p, salt, key] = stored.split('$');
    if (alg !== 'scrypt') return false;
    const expected = Buffer.from(key, 'base64');
    const got = crypto.scryptSync(password, Buffer.from(salt, 'base64'), expected.length, { N: +N, r: +r, p: +p, maxmem: SCRYPT.maxmem });
    return crypto.timingSafeEqual(got, expected);
  } catch { return false; }
}
// A throwaway hash used to equalize timing when the username does not exist.
let DUMMY; function dummyVerify(pw) { DUMMY = DUMMY || hashPassword('dummy-password-for-timing'); verifyPassword(pw, DUMMY); }

function passwordProblem(pw) {
  if (typeof pw !== 'string' || pw.length < 12) return 'كلمة المرور يجب ألا تقل عن 12 حرفاً';
  if (pw.length > 200) return 'كلمة المرور طويلة جداً';
  const classes = [/[a-z]/, /[A-Z]/, /\d/, /[^A-Za-z0-9]/].filter(r => r.test(pw)).length;
  if (classes < 3) return 'استخدم 3 أنواع على الأقل: أحرف صغيرة، كبيرة، أرقام، رموز';
  if (/^(.)\1+$/.test(pw) || /password|123456|qwerty|azerty/i.test(pw)) return 'كلمة المرور ضعيفة جداً';
  return null;
}

/* ---------- Random tokens ---------- */
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const token = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');
function safeEqual(a, b) {
  const ba = Buffer.from(String(a)), bb = Buffer.from(String(b));
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
}

/* ---------- Admin sessions (stored hashed in SQLite, survive restarts) ---------- */
function createSession(adminId, ip) {
  const id = token(32), csrf = token(24), now = Date.now();
  db.get().prepare('INSERT INTO admin_sessions(id_hash,admin_id,csrf,created_at,last_seen_at,expires_at,ip) VALUES (?,?,?,?,?,?,?)')
    .run(sha256(id), adminId, csrf, now, now, now + config.SESSION_MAX_MS, ip || '');
  return { id, csrf };
}
function getSession(id) {
  if (!id || typeof id !== 'string' || id.length > 100) return null;
  const d = db.get(), h = sha256(id), now = Date.now();
  const s = d.prepare(`SELECT s.*, a.username, a.role, a.active, a.totp_enabled FROM admin_sessions s JOIN admins a ON a.id = s.admin_id WHERE s.id_hash = ?`).get(h);
  if (!s) return null;
  if (!s.active || s.expires_at < now || now - s.last_seen_at > config.SESSION_IDLE_MS) {
    d.prepare('DELETE FROM admin_sessions WHERE id_hash = ?').run(h); return null;
  }
  if (now - s.last_seen_at > 60000) d.prepare('UPDATE admin_sessions SET last_seen_at = ? WHERE id_hash = ?').run(now, h);
  return { adminId: s.admin_id, username: s.username, role: s.role, csrf: s.csrf, totp_enabled: !!s.totp_enabled, hash: h };
}
function destroySession(id) { if (id) db.get().prepare('DELETE FROM admin_sessions WHERE id_hash = ?').run(sha256(id)); }
function destroyAllSessions(adminId, exceptHash) {
  db.get().prepare('DELETE FROM admin_sessions WHERE admin_id = ? AND id_hash != ?').run(adminId, exceptHash || '');
}
function purgeSessions() { db.get().prepare('DELETE FROM admin_sessions WHERE expires_at < ?').run(Date.now()); }

/* ---------- Rate limiting (in-memory sliding window) ---------- */
const buckets = new Map();
function rateLimit(key, max, windowMs) {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || b.reset < now) { b = { count: 0, reset: now + windowMs }; buckets.set(key, b); }
  b.count++;
  return { ok: b.count <= max, retryAfter: Math.ceil((b.reset - now) / 1000) };
}
function rateCheck(key, max) { const b = buckets.get(key); return !(b && b.reset > Date.now() && b.count >= max); }
function rateReset(key) { buckets.delete(key); }
function resetAllBuckets() { buckets.clear(); }
function sweepBuckets() { const n = Date.now(); for (const [k, b] of buckets) if (b.reset < n) buckets.delete(k); }

/* ---------- TOTP (RFC 6238) for optional 2-factor auth ---------- */
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function b32encode(buf) { let bits = '', out = ''; for (const b of buf) bits += b.toString(2).padStart(8, '0'); for (let i = 0; i < bits.length; i += 5) out += B32[parseInt(bits.slice(i, i + 5).padEnd(5, '0'), 2)]; return out; }
function b32decode(s) { let bits = ''; for (const c of s.replace(/=+$/, '').toUpperCase()) { const i = B32.indexOf(c); if (i < 0) continue; bits += i.toString(2).padStart(5, '0'); } const out = []; for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2)); return Buffer.from(out); }
function totpAt(secret, t) {
  const buf = Buffer.alloc(8); buf.writeBigUInt64BE(BigInt(Math.floor(t / 30000)));
  const h = crypto.createHmac('sha1', b32decode(secret)).update(buf).digest();
  const o = h[h.length - 1] & 15;
  const code = ((h[o] & 0x7f) << 24 | h[o + 1] << 16 | h[o + 2] << 8 | h[o + 3]) % 1000000;
  return String(code).padStart(6, '0');
}
function totpVerify(secret, code) {
  code = String(code || '').replace(/\s/g, '');
  if (!/^\d{6}$/.test(code)) return false;
  const now = Date.now();
  return [-30000, 0, 30000].some(d => safeEqual(totpAt(secret, now + d), code));
}
const totpNewSecret = () => b32encode(crypto.randomBytes(20));

/* ---------- Security headers ---------- */
function securityHeaders(isAdmin) {
  const h = {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
    'Cross-Origin-Opener-Policy': 'same-origin',
    'Content-Security-Policy': [
      "default-src 'self'", "script-src 'self'", "style-src 'self' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com", "img-src 'self' data:", "media-src 'self'", "connect-src 'self'",
      "object-src 'none'", "base-uri 'self'", "form-action 'self'", "frame-ancestors 'none'",
    ].join('; '),
  };
  if (config.PRODUCTION) h['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
  if (isAdmin) h['Cache-Control'] = 'no-store';
  return h;
}

module.exports = {
  hashPassword, verifyPassword, dummyVerify, passwordProblem, sha256, token, safeEqual,
  createSession, getSession, destroySession, destroyAllSessions, purgeSessions,
  rateLimit, rateCheck, rateReset, sweepBuckets, resetAllBuckets, totpAt, totpVerify, totpNewSecret, securityHeaders,
};
