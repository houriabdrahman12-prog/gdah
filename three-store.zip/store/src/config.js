'use strict';
const path = require('node:path');
const fs = require('node:fs');

function loadEnvFile() {
  const f = path.join(__dirname, '..', '.env');
  if (!fs.existsSync(f)) return;
  for (const line of fs.readFileSync(f, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}
loadEnvFile();

const env = process.env;
const DATA_DIR = path.resolve(env.DATA_DIR || path.join(__dirname, '..', 'data'));
module.exports = {
  NODE_ENV: env.NODE_ENV || 'development',
  PRODUCTION: env.NODE_ENV === 'production',
  PORT: parseInt(env.PORT || '3000', 10),
  HOST: env.HOST || '0.0.0.0',
  DATA_DIR,
  DB_FILE: env.DB_FILE || path.join(DATA_DIR, 'store.db'),
  UPLOAD_DIR: env.UPLOAD_DIR || path.join(DATA_DIR, 'uploads'),
  BACKUP_DIR: env.BACKUP_DIR || path.join(DATA_DIR, 'backups'),
  PUBLIC_DIR: path.join(__dirname, '..', 'public'),
  SITE_URL: (env.SITE_URL || '').replace(/\/+$/, ''),
  TRUST_PROXY: env.TRUST_PROXY === '1' || env.TRUST_PROXY === 'true',
  SECURE_COOKIES: env.NODE_ENV === 'production' && env.INSECURE_COOKIES !== '1',
  SESSION_IDLE_MS: 2 * 60 * 60 * 1000,
  SESSION_MAX_MS: 12 * 60 * 60 * 1000,
  MAX_JSON_BYTES: 256 * 1024,
  MAX_IMAGE_BYTES: 8 * 1024 * 1024,
  MAX_VIDEO_BYTES: 30 * 1024 * 1024,
};
