'use strict';
// The 58 wilayas of Algeria (2021 administrative division).
// Delivery fees below are PLACEHOLDER DEFAULTS — the owner must set real fees in Admin → Delivery.
const FAR_SOUTH = new Set([11, 33, 37, 49, 50, 52, 53, 54, 56]);
const SOUTH = new Set([1, 7, 8, 30, 39, 45, 47, 51, 55, 57, 58, 32, 3, 17]);
const LIST = [
  [1, 'أدرار', 'Adrar'], [2, 'الشلف', 'Chlef'], [3, 'الأغواط', 'Laghouat'], [4, 'أم البواقي', 'Oum El Bouaghi'],
  [5, 'باتنة', 'Batna'], [6, 'بجاية', 'Béjaïa'], [7, 'بسكرة', 'Biskra'], [8, 'بشار', 'Béchar'],
  [9, 'البليدة', 'Blida'], [10, 'البويرة', 'Bouira'], [11, 'تمنراست', 'Tamanrasset'], [12, 'تبسة', 'Tébessa'],
  [13, 'تلمسان', 'Tlemcen'], [14, 'تيارت', 'Tiaret'], [15, 'تيزي وزو', 'Tizi Ouzou'], [16, 'الجزائر', 'Alger'],
  [17, 'الجلفة', 'Djelfa'], [18, 'جيجل', 'Jijel'], [19, 'سطيف', 'Sétif'], [20, 'سعيدة', 'Saïda'],
  [21, 'سكيكدة', 'Skikda'], [22, 'سيدي بلعباس', 'Sidi Bel Abbès'], [23, 'عنابة', 'Annaba'], [24, 'قالمة', 'Guelma'],
  [25, 'قسنطينة', 'Constantine'], [26, 'المدية', 'Médéa'], [27, 'مستغانم', 'Mostaganem'], [28, 'المسيلة', "M'Sila"],
  [29, 'معسكر', 'Mascara'], [30, 'ورقلة', 'Ouargla'], [31, 'وهران', 'Oran'], [32, 'البيض', 'El Bayadh'],
  [33, 'إليزي', 'Illizi'], [34, 'برج بوعريريج', 'Bordj Bou Arréridj'], [35, 'بومرداس', 'Boumerdès'], [36, 'الطارف', 'El Tarf'],
  [37, 'تندوف', 'Tindouf'], [38, 'تيسمسيلت', 'Tissemsilt'], [39, 'الوادي', 'El Oued'], [40, 'خنشلة', 'Khenchela'],
  [41, 'سوق أهراس', 'Souk Ahras'], [42, 'تيبازة', 'Tipaza'], [43, 'ميلة', 'Mila'], [44, 'عين الدفلى', 'Aïn Defla'],
  [45, 'النعامة', 'Naâma'], [46, 'عين تموشنت', 'Aïn Témouchent'], [47, 'غرداية', 'Ghardaïa'], [48, 'غليزان', 'Relizane'],
  [49, 'تيميمون', 'Timimoun'], [50, 'برج باجي مختار', 'Bordj Badji Mokhtar'], [51, 'أولاد جلال', 'Ouled Djellal'],
  [52, 'بني عباس', 'Béni Abbès'], [53, 'عين صالح', 'In Salah'], [54, 'عين قزام', 'In Guezzam'], [55, 'تقرت', 'Touggourt'],
  [56, 'جانت', 'Djanet'], [57, 'المغير', "El M'Ghair"], [58, 'المنيعة', 'El Meniaa'],
];
module.exports = LIST.map(([code, ar, fr]) => {
  const tier = FAR_SOUTH.has(code) ? 2 : SOUTH.has(code) ? 1 : 0;
  return { code, name_ar: ar, name_fr: fr, fee_home: [600, 1000, 1400][tier], fee_desk: [400, 800, 1200][tier] };
});
