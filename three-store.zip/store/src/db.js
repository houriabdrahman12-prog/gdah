'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const config = require('./config');
const WILAYAS = require('./wilayas');
const defaults = require('./defaults');

let db;

function open(file = config.DB_FILE) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;');
  return db;
}
function get() { if (!db) throw new Error('DB not open'); return db; }
function close() { if (db) { try { db.close(); } catch {} db = null; } }

/** Run fn inside a transaction (BEGIN IMMEDIATE so concurrent writers serialize). */
function tx(fn) {
  const d = get();
  d.exec('BEGIN IMMEDIATE');
  try { const r = fn(d); d.exec('COMMIT'); return r; }
  catch (e) { try { d.exec('ROLLBACK'); } catch {} throw e; }
}

function migrate({ backup = true } = {}) {
  const d = get();
  d.exec('CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT (datetime(\'now\')))');
  const dir = path.join(__dirname, 'migrations');
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
  const done = new Set(d.prepare('SELECT name FROM schema_migrations').all().map(r => r.name));
  const pending = files.filter(f => !done.has(f));
  if (!pending.length) return [];
  // Safety: back up an existing, non-empty database before altering it.
  if (backup && done.size > 0 && config.DB_FILE && d.prepare('SELECT 1 FROM admins LIMIT 1').get()) {
    try { backupTo(path.join(config.BACKUP_DIR, `pre-migration-${stamp()}.db`)); } catch (e) { console.error('pre-migration backup failed:', e.message); throw e; }
  }
  for (const f of pending) {
    const sql = fs.readFileSync(path.join(dir, f), 'utf8');
    d.exec('BEGIN');
    try {
      d.exec(sql);
      d.prepare('INSERT INTO schema_migrations(name) VALUES (?)').run(f);
      d.exec('COMMIT');
    } catch (e) { d.exec('ROLLBACK'); throw new Error(`Migration ${f} failed: ${e.message}`); }
  }
  return pending;
}

function stamp() { return new Date().toISOString().replace(/[:.]/g, '-'); }

/** Consistent online backup using VACUUM INTO. */
function backupTo(target) {
  fs.mkdirSync(path.dirname(target), { recursive: true });
  if (fs.existsSync(target)) throw new Error('backup target exists');
  get().prepare('VACUUM INTO ?').run(target);
  return target;
}

/** Insert first-run defaults (only when tables are empty — never overwrites owner data). */
function seed({ demoProducts = true } = {}) {
  const d = get();
  tx(() => {
    if (!d.prepare('SELECT 1 FROM wilayas LIMIT 1').get()) {
      const ins = d.prepare('INSERT INTO wilayas(code,name_ar,name_fr,fee_home,fee_desk) VALUES (?,?,?,?,?)');
      for (const w of WILAYAS) ins.run(w.code, w.name_ar, w.name_fr, w.fee_home, w.fee_desk);
    }
    for (const [k, v] of Object.entries(defaults.settings)) {
      d.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES (?,?)').run(k, JSON.stringify(v));
    }
    if (!d.prepare('SELECT 1 FROM pages LIMIT 1').get()) {
      const ins = d.prepare('INSERT INTO pages(slug,title,content,published,system) VALUES (?,?,?,1,1)');
      for (const p of defaults.pages) ins.run(p.slug, p.title, p.content);
    }
    if (!d.prepare('SELECT 1 FROM nav_items LIMIT 1').get()) {
      const ins = d.prepare('INSERT INTO nav_items(location,label,url,sort) VALUES (?,?,?,?)');
      defaults.nav.forEach((n, i) => ins.run(n[0], n[1], n[2], i));
    }
    if (!d.prepare('SELECT 1 FROM home_sections LIMIT 1').get()) {
      const ins = d.prepare('INSERT INTO home_sections(type,title,sort,data) VALUES (?,?,?,?)');
      defaults.sections.forEach((s, i) => ins.run(s.type, s.title, i, JSON.stringify(s.data)));
    }
    if (!d.prepare('SELECT 1 FROM sizes LIMIT 1').get()) {
      defaults.sizes.forEach((n, i) => d.prepare('INSERT INTO sizes(name,sort) VALUES (?,?)').run(n, i));
    }
    if (!d.prepare('SELECT 1 FROM colors LIMIT 1').get()) {
      defaults.colors.forEach((c, i) => d.prepare('INSERT INTO colors(name,hex,sort) VALUES (?,?,?)').run(c[0], c[1], i));
    }
    if (!d.prepare('SELECT 1 FROM categories LIMIT 1').get()) {
      defaults.categories.forEach((c, i) => d.prepare('INSERT INTO categories(slug,name,sort) VALUES (?,?,?)').run(c[0], c[1], i));
    }
    if (demoProducts && !d.prepare('SELECT 1 FROM products LIMIT 1').get() && !d.prepare('SELECT 1 FROM orders LIMIT 1').get()) {
      const cat = (slug) => d.prepare('SELECT id FROM categories WHERE slug=?').get(slug).id;
      for (const p of defaults.products) {
        const r = d.prepare(`INSERT INTO products(slug,name,description,category_id,price,status,featured,is_new)
          VALUES (?,?,?,?,?,'draft',1,1)`).run(p.slug, p.name, p.description, cat(p.category), p.price);
        const pid = Number(r.lastInsertRowid);
        d.prepare('INSERT INTO product_images(product_id,file,thumb,alt,sort) VALUES (?,?,?,?,0)').run(pid, p.image, p.image, p.alt);
        for (const size of p.sizes) for (const color of p.colors) {
          d.prepare('INSERT INTO product_variants(product_id,size,color,stock) VALUES (?,?,?,0)').run(pid, size, color);
        }
      }
    }
  });
}

module.exports = { open, get, close, tx, migrate, seed, backupTo, stamp };
