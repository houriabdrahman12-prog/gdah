'use strict';
const db = require('./db');
const store = require('./store');
const { esc, money, safeUrl, safeImg, safeHex, renderMarkup, waNumber } = require('./util');

/* Google Fonts allowlist (admin picks by name; arbitrary strings are never injected into CSS/HTML). */
const FONTS = {
  'Noto Kufi Arabic': 'Noto+Kufi+Arabic:wght@400;500;700;900', 'IBM Plex Sans Arabic': 'IBM+Plex+Sans+Arabic:wght@300;400;500;600',
  'Cairo': 'Cairo:wght@300;400;600;700;900', 'Tajawal': 'Tajawal:wght@300;400;500;700;900', 'Almarai': 'Almarai:wght@300;400;700;800',
  'Changa': 'Changa:wght@300;400;600;800', 'Reem Kufi': 'Reem+Kufi:wght@400;500;600;700', 'El Messiri': 'El+Messiri:wght@400;500;600;700',
  'Archivo': 'Archivo:wght@400;500;700;900', 'Montserrat': 'Montserrat:wght@400;500;700;900', 'Inter': 'Inter:wght@300;400;500;700;900',
};
const FONT_NAMES = Object.keys(FONTS);
const fontOr = (n, fb) => (FONTS[n] ? n : fb);

function themeCss() {
  const t = store.S('theme');
  const bg = safeHex(t.bg, '#000000'), ink = safeHex(t.ink, '#f5f5f5'), dim = safeHex(t.ink_dim, '#9a9d9f');
  const fd = fontOr(t.font_display, 'Noto Kufi Arabic'), fb = fontOr(t.font_body, 'IBM Plex Sans Arabic'), fl = fontOr(t.font_latin, 'Archivo');
  const px = Math.min(22, Math.max(13, parseInt(t.base_font_size, 10) || 16));
  const logo = Math.min(120, Math.max(24, parseInt(t.logo_size, 10) || 40));
  const a = store.S('anim');
  let css = `:root{--bg:${bg};--bg-soft:${safeHex(t.bg_soft, '#0a0a0a')};--surface:${safeHex(t.surface, '#111111')};--ink:${ink};--ink-dim:${dim};` +
    `--accent:${safeHex(t.accent, ink)};--accent-ink:${safeHex(t.accent_ink, bg)};--line:${ink}24;--logo-size:${logo}px;` +
    `--font-ar-display:"${fd}","IBM Plex Sans Arabic",Tahoma,sans-serif;--font-ar-body:"${fb}","Noto Kufi Arabic",Tahoma,sans-serif;--font-latin:"${fl}","${fd}",sans-serif}` +
    `html{font-size:${px}px}`;
  if (a.hover === false) css += '.product:hover .product__media img{transform:none!important}.btn-pill:hover .btn-pill__circle{transition:none}';
  if (a.orbit === false) css += '.hero__orbit-svg{animation:none!important}';
  if (a.marquee === false) css += '.marquee__track,.footer__track{animation:none!important}';
  return css;
}

function fontsLink() {
  const t = store.S('theme'); const names = new Set([fontOr(t.font_display, 'Noto Kufi Arabic'), fontOr(t.font_body, 'IBM Plex Sans Arabic'), fontOr(t.font_latin, 'Archivo')]);
  return 'https://fonts.googleapis.com/css2?' + [...names].map(n => 'family=' + FONTS[n]).join('&') + '&display=swap';
}

function navItems(loc) { return db.get().prepare('SELECT * FROM nav_items WHERE location=? AND visible=1 ORDER BY sort,id').all(loc); }
function activeFx() { const a = store.S('anim'); return Object.keys(a).filter(k => a[k]).join(' '); }

/* ---------------- Layout ---------------- */
function layout(ctx, o) {
  const st = store.S('store'), br = store.S('branding'), seo = store.S('seo'), ann = store.S('announcement'), foot = store.S('footer');
  const title = o.title ? `${o.title}${seo.title_suffix ?? ' — ' + st.name}` : `${st.name}${st.tagline ? ' — ' + st.tagline : ''}`;
  const desc = o.description || seo.default_description || st.description || '';
  const canonical = o.canonical === false ? '' : ctx.base + (o.path || ctx.path || '/');
  const ogImg = o.image || br.og_image || br.logo; const ogAbs = ogImg ? (ogImg.startsWith('http') ? ogImg : ctx.base + ogImg) : '';
  const hdr = navItems('header'), ftr = navItems('footer');
  const v = store.settingsVersion();
  const wa = waNumber(st.whatsapp);
  const link = (n) => `<a href="${esc(safeUrl(n.url))}">${esc(n.label)}</a>`;
  const logo = safeImg(br.logo);
  const social = [['instagram', 'إنستغرام', st.instagram], ['facebook', 'فيسبوك', st.facebook], ['tiktok', 'تيك توك', st.tiktok]]
    .filter(s => s[2]).map(s => `<a href="${esc(safeUrl(s[2]))}" target="_blank" rel="noopener noreferrer">${s[1]}</a>`).join('');
  const jsonld = o.jsonld ? `<script type="application/ld+json">${JSON.stringify(o.jsonld).replace(/</g, '\\u003c')}</script>` : '';
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl" class="no-js" data-fx="${esc(activeFx())}">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
<meta name="theme-color" content="${esc(safeHex(store.S('theme').bg, '#000000'))}">
${o.noindex ? '<meta name="robots" content="noindex, nofollow">' : ''}
${canonical ? `<link rel="canonical" href="${esc(canonical)}">` : ''}
<meta property="og:type" content="${o.ogType || 'website'}"><meta property="og:site_name" content="${esc(st.name)}">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}">
${canonical ? `<meta property="og:url" content="${esc(canonical)}">` : ''}${ogAbs ? `<meta property="og:image" content="${esc(ogAbs)}">` : ''}
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="${esc(safeImg(br.favicon) || '/assets/logo.jpeg')}">
<link rel="apple-touch-icon" href="${esc(safeImg(br.favicon) || '/assets/logo.jpeg')}">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="${esc(fontsLink())}">
<link rel="stylesheet" href="/css/base.css?v=2"><link rel="stylesheet" href="/css/shop.css?v=2"><link rel="stylesheet" href="/theme.css?v=${v}">
${jsonld}
</head>
<body class="${esc(o.bodyClass || '')}">
${o.preloader ? `<div class="preloader" id="preloader" aria-hidden="true"><div class="preloader__center"><p class="preloader__brand" id="preloaderBrand" lang="en" dir="ltr">${esc(st.name)}</p><p class="preloader__tag">${esc(st.tagline)}</p><div class="preloader__bar"><span class="preloader__progress" id="preloaderProgress"></span></div><p class="preloader__count" id="preloaderCount" dir="ltr">0%</p></div><div class="preloader__curtain preloader__curtain--top"></div><div class="preloader__curtain preloader__curtain--bottom"></div></div>` : ''}
<div class="cursor" id="cursor" aria-hidden="true"><span class="cursor__dot"></span><span class="cursor__label" id="cursorLabel"></span></div>
<a class="skip-link" href="#main">تخطَّ إلى المحتوى</a>
${ann.enabled && ann.text ? `<div class="announce" role="region" aria-label="إعلان">${ann.url ? `<a href="${esc(safeUrl(ann.url))}">${esc(ann.text)}</a>` : `<span>${esc(ann.text)}</span>`}</div>` : ''}
<header class="header ${o.solidHeader ? 'is-scrolled' : ''}" id="header">
  <a class="header__brand" href="/">${logo ? `<img class="header__logo" src="${esc(logo)}" alt="شعار ${esc(st.name)}" width="40" height="40">` : ''}<span class="header__name" lang="en" dir="ltr">${esc(st.name)}</span></a>
  <nav class="header__nav" aria-label="التنقل الرئيسي">${hdr.map(link).join('')}</nav>
  <a class="cart-link" href="/cart" aria-label="السلة"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M3 4h2l2.4 11.2a1 1 0 0 0 1 .8h8.8a1 1 0 0 0 1-.8L20 8H6"/><circle cx="9" cy="20" r="1.3"/><circle cx="17" cy="20" r="1.3"/></svg><span class="cart-link__count" id="cartCount" hidden>0</span></a>
  <a class="header__cta" href="/shop">تسوّق الآن</a>
  <button class="burger" id="burger" aria-label="فتح القائمة" aria-expanded="false" aria-controls="menuOverlay"><span></span><span></span></button>
</header>
<div class="menu-overlay" id="menuOverlay" aria-hidden="true"><nav class="menu-overlay__nav" aria-label="قائمة الجوال">${hdr.map(link).join('')}<a href="/shop">المتجر</a><a href="/cart">السلة</a></nav><p class="menu-overlay__foot" lang="en" dir="ltr">${esc(st.name)}</p></div>
<main id="main">
${o.body}
</main>
<footer class="footer">
  ${foot.show_marquee !== false ? `<div class="footer__marquee" aria-hidden="true"><div class="footer__track" id="footerTrack"><span lang="en" dir="ltr">${esc(st.name)} ✦ ${esc(st.name)} ✦ ${esc(st.name)} ✦ ${esc(st.name)} ✦ </span></div></div>` : ''}
  <div class="footer__cols">
    <div><h2 class="footer__h">${esc(st.name)}</h2><p class="footer__txt">${esc(foot.text || st.tagline)}</p><p class="footer__txt">الدفع نقداً عند الاستلام — التوصيل إلى 58 ولاية</p></div>
    <nav aria-label="روابط التذييل"><h2 class="footer__h">روابط</h2><div class="footer__links">${ftr.map(link).join('')}</div></nav>
    ${(st.phone || wa || st.email || social || st.address) ? `<div><h2 class="footer__h">تواصل معنا</h2><div class="footer__links">
      ${st.phone ? `<a href="tel:${esc(st.phone.replace(/[^\d+]/g, ''))}" dir="ltr">${esc(st.phone)}</a>` : ''}
      ${wa ? `<a href="https://wa.me/${wa}" target="_blank" rel="noopener noreferrer">واتساب</a>` : ''}
      ${st.email ? `<a href="mailto:${esc(st.email)}">${esc(st.email)}</a>` : ''}${social}
    </div>${st.address ? `<p class="footer__txt">${esc(st.address)}</p>` : ''}</div>` : ''}
  </div>
  <div class="footer__row"><p>© ${new Date().getFullYear()} ${esc(st.name)} — جميع الحقوق محفوظة</p></div>
</footer>
${wa ? `<a class="wa-float" href="https://wa.me/${wa}" target="_blank" rel="noopener noreferrer" aria-label="تواصل عبر واتساب"><svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.5 15.2L2 22l4.9-1.4A10 10 0 1 0 12 2zm0 2a8 8 0 1 1-4.2 14.8l-.4-.2-2.6.7.7-2.5-.3-.4A8 8 0 0 1 12 4zm-3 4c-.3 0-.7.2-.9.5-.4.5-.8 1.2-.6 2.2.3 1.3 1.6 3.1 3.2 4.2 1.8 1.3 3.2 1.6 4.1 1.4.8-.2 1.5-.9 1.7-1.5.1-.3 0-.5-.2-.6l-1.5-.7c-.2-.1-.4 0-.6.2l-.6.7c-.1.2-.3.2-.5.1-.7-.3-1.7-.9-2.4-1.9-.1-.2-.1-.4 0-.5l.5-.6c.1-.2.1-.3 0-.5l-.7-1.6c-.1-.2-.3-.3-.5-.3z"/></svg></a>` : ''}
<script src="/js/app.js?v=2" defer></script>
${o.scripts || ''}
</body></html>`;
}

/* ---------------- Product card ---------------- */
function card(p, { home = false, idx = 0 } = {}) {
  const img = p.images[0]; const src = img ? (img.thumb || img.file) : '';
  const badge = !p.in_stock ? '<span class="badge badge--out">نفد المخزون</span>' : p.on_sale ? '<span class="badge badge--sale">تخفيض</span>' : p.is_new ? '<span class="badge">جديد</span>' : '';
  return `<article class="product ${home ? 'product--offset-' + (idx % 3) : ''}" data-product>
  <a class="product__media ${home ? '' : 'is-revealed'}" ${home ? 'data-reveal="wipe" data-cursor="شاهد"' : ''} href="/product/${esc(p.slug)}" aria-label="${esc(p.name)}">
    ${src ? `<img src="${esc(src)}" alt="${esc(img.alt || p.name)}" loading="lazy" decoding="async" width="520" height="650">` : '<div class="product__ph" role="img" aria-label="صورة المنتج غير متوفرة بعد">لا توجد صورة</div>'}
    ${badge}${home ? `<span class="product__index" lang="en" dir="ltr">${String(idx + 1).padStart(2, '0')}</span>` : ''}
  </a>
  <div class="product__info"><h3><a href="/product/${esc(p.slug)}">${esc(p.name)}</a></h3>
    ${p.category_name ? `<p>${esc(p.category_name)}</p>` : ''}
    <div class="product__row"><span class="product__price">${p.on_sale ? `<s>${money(p.price)}</s> ` : ''}${money(p.final_price)}</span>
    <a class="btn-pill btn-pill--sm" href="/product/${esc(p.slug)}"><span class="btn-pill__circle" aria-hidden="true"></span><span class="btn-pill__text">${p.in_stock ? 'التفاصيل' : 'عرض'}</span></a></div></div>
</article>`;
}

/* ---------------- Home sections ---------------- */
function productsFor(d) {
  const o = { perPage: Math.min(12, Math.max(1, d.limit || 6)) };
  if (d.source === 'new') { o.isNew = true; o.sort = 'newest'; } else if (d.source === 'sale') o.sale = true;
  else if (d.source === 'category' && d.category_id) { const c = db.get().prepare('SELECT slug FROM categories WHERE id=?').get(d.category_id); if (c) o.category = c.slug; }
  else if (d.source === 'all') o.sort = 'newest'; else o.featured = true;
  return store.listProducts(o).items;
}
const label = (t) => (t ? `<p class="section-head__label">${esc(t)}</p>` : '');
function btn(text, url, cls = '') { return text ? `<a class="btn-pill ${cls}" href="${esc(safeUrl(url, '/shop'))}"><span class="btn-pill__circle" aria-hidden="true"></span><span class="btn-pill__text">${esc(text)}</span></a>` : ''; }

function renderSection(s, ctx) {
  const d = (() => { try { return JSON.parse(s.data); } catch { return {}; } })();
  const br = store.S('branding');
  switch (s.type) {
    case 'hero': {
      const media = safeImg(d.media) || safeImg(br.logo);
      let inner;
      if (d.media_type === 'video' && safeImg(d.media)) inner = `<video class="hero__video" src="${esc(d.media)}" ${safeImg(d.video_poster) ? `poster="${esc(d.video_poster)}"` : ''} autoplay muted loop playsinline preload="metadata" aria-label="فيديو"></video>`;
      else if (d.media_type === 'none') inner = '';
      else inner = `<img class="hero__logo ${d.media_type === 'image' ? 'hero__logo--wide' : ''}" src="${esc(d.media_type === 'logo' ? safeImg(br.logo) : media)}" alt="${esc(store.S('store').name)}" width="340" height="340" fetchpriority="high">`;
      return `<section class="hero" id="hero"><h1 class="hero__giant" id="heroGiant" lang="en" dir="ltr" aria-label="${esc(d.giant)}">${esc(d.giant)}</h1>
      <div class="hero__orbit">${d.media_type === 'video' ? '' : '<svg class="hero__orbit-svg" viewBox="0 0 600 600" fill="none" aria-hidden="true"><ellipse cx="300" cy="300" rx="270" ry="110" stroke="currentColor" stroke-width="1.5" transform="rotate(-18 300 300)"/><path d="M300 40 l12 26 26 12 -26 12 -12 26 -12 -26 -26 -12 26 -12 z" fill="currentColor"/></svg>'}${inner}</div>
      <div class="hero__text">${d.kicker ? `<p class="hero__kicker" lang="en" dir="ltr">${esc(d.kicker)}</p>` : ''}<h2 class="hero__title" data-words>${esc(d.title)}</h2>${btn(d.button_text, d.button_url)}</div>
      <div class="hero__scroll" aria-hidden="true"><span>مرّر للأسفل</span><span class="hero__scroll-line"></span></div></section>`;
    }
    case 'marquee': return `<div class="marquee" aria-hidden="true"><div class="marquee__track" id="marqueeTrack"><span class="marquee__item">${esc(d.text)}&nbsp;</span></div></div>`;
    case 'story': {
      const stats = (d.stats || []).slice(0, 4).map(x => { const num = /^\d{1,6}$/.test(String(x.value)); return `<li data-reveal><b class="stat-num" ${num ? `data-count="${esc(x.value)}"` : ''}>${esc(x.value)}</b><span>${esc(x.label)}</span></li>`; }).join('');
      return `<section class="story" id="story"><div class="section-head">${label(d.label)}<h3 class="section-head__title" data-words>${esc(d.heading)}</h3><div class="elastic-line" id="elasticLine" aria-hidden="true"><div class="elastic-line__box" id="elasticBox"></div><svg class="elastic-line__svg" preserveAspectRatio="none" viewBox="0 0 100 50"><path id="elasticPath" d="M0 25 Q 50 25, 100 25" stroke="currentColor" stroke-width="0.6" fill="none" vector-effect="non-scaling-stroke"/></svg></div></div>
      <div class="story__grid">${safeImg(d.image) ? `<figure class="story__visual" data-reveal><div class="story__visual-frame"><img src="${esc(d.image)}" alt="${esc(d.caption || '')}" loading="lazy" decoding="async"><span class="story__visual-star" aria-hidden="true">✦</span></div>${d.caption ? `<figcaption>${esc(d.caption)}</figcaption>` : ''}</figure>` : '<div></div>'}
      <div class="story__body">${(d.paragraphs || []).map(p => `<p class="story__para" data-reveal>${esc(p)}</p>`).join('')}${stats ? `<ul class="story__stats">${stats}</ul>` : ''}</div></div></section>`;
    }
    case 'products': {
      const items = productsFor(d);
      return `<section class="collection" id="${'sec-' + s.id}"><div class="section-head">${label(d.label)}<h3 class="section-head__title" data-words>${esc(d.heading)}</h3></div>
      ${items.length ? `<div class="collection__grid">${items.map((p, i) => card(p, { home: true, idx: i })).join('')}</div>` : '<p class="empty-note">المجموعة قادمة قريباً.</p>'}
      ${d.button_text ? `<div class="section-cta">${btn(d.button_text, d.button_url)}</div>` : ''}</section>`;
    }
    case 'banner': return `<section class="banner" ${''}>${safeImg(d.image) ? `<img class="banner__img" src="${esc(d.image)}" alt="" loading="lazy" decoding="async">` : ''}<div class="banner__body banner--${esc(['start', 'center', 'end'].includes(d.align) ? d.align : 'center')}" data-reveal>${d.title ? `<h3 class="banner__title">${esc(d.title)}</h3>` : ''}${d.text ? `<p>${esc(d.text)}</p>` : ''}${btn(d.button_text, d.button_url)}</div></section>`;
    case 'richtext': return `<section class="richtext"><div class="section-head">${label(d.label)}${d.heading ? `<h3 class="section-head__title" data-words>${esc(d.heading)}</h3>` : ''}</div><div class="prose prose--wide" data-reveal>${renderMarkup(d.body)}</div></section>`;
    case 'manifesto': return `<section class="manifesto" id="manifesto"><div class="manifesto__inner">${label(d.label).replace('section-head__label', 'manifesto__label')}<p class="manifesto__line" data-words>${esc(d.line1)}</p><p class="manifesto__line manifesto__line--alt" data-words>${esc(d.line2)}</p></div><svg class="manifesto__ring" viewBox="0 0 800 400" fill="none" aria-hidden="true"><ellipse cx="400" cy="200" rx="360" ry="130" stroke="currentColor" stroke-width="1" transform="rotate(-12 400 200)"/></svg></section>`;
    case 'finale': return `<section class="finale" id="finale">${d.label ? `<p class="finale__kicker">${esc(d.label)}</p>` : ''}<h3 class="finale__title" data-words>${esc(d.heading)}</h3>${safeImg(d.image) ? `<div class="finale__logo-wrap"><img class="finale__logo" id="finaleLogo" src="${esc(d.image)}" alt="" loading="lazy" decoding="async" width="300" height="300"></div>` : ''}${btn(d.button_text, d.button_url)}</section>`;
    default: return '';
  }
}

function homePage(ctx) {
  const secs = db.get().prepare('SELECT * FROM home_sections WHERE visible=1 ORDER BY sort,id').all();
  const hero = secs.find(s => s.type === 'hero');
  return layout(ctx, { path: '/', preloader: store.S('anim').preloader !== false && !!hero, bodyClass: 'is-home', body: secs.map(s => renderSection(s, ctx)).join('\n'), scripts: '<script src="/js/home.js?v=2" defer></script>' });
}

/* ---------------- Shop ---------------- */
function shopPage(ctx, q) {
  const opts = store.filterOptions();
  const qs = (over = {}) => { const m = { ...q, ...over }; const u = new URLSearchParams(); for (const [k, v] of Object.entries(m)) if (v !== '' && v != null && !(k === 'page' && +v === 1)) u.set(k, v); const s = u.toString(); return '/shop' + (s ? '?' + s : ''); };
  const r = store.listProducts({ q: q.q, category: q.category, size: q.size, color: q.color, min: q.min ? +q.min : null, max: q.max ? +q.max : null, sort: q.sort, page: q.page, perPage: 12, sale: q.sale === '1', isNew: q.new === '1' });
  const sel = (name, list, key, valKey = 'name') => `<label class="f"><span>${name}</span><select name="${key}"><option value="">الكل</option>${list.map(o => `<option value="${esc(valKey === 'slug' ? o.slug : o.name)}" ${(q[key] === (valKey === 'slug' ? o.slug : o.name)) ? 'selected' : ''}>${esc(o.name)}</option>`).join('')}</select></label>`;
  const body = `<section class="page-head"><h1 class="page-title">المتجر</h1><p class="page-sub">${r.total} منتج</p></section>
  <form class="filters" method="get" action="/shop" role="search">
    <label class="f f--grow"><span>بحث</span><input type="search" name="q" value="${esc(q.q || '')}" placeholder="ابحث عن منتج…" maxlength="60"></label>
    ${sel('الفئة', opts.categories, 'category', 'slug')}${sel('المقاس', opts.sizes, 'size')}${sel('اللون', opts.colors, 'color')}
    <label class="f f--sm"><span>السعر من</span><input type="number" name="min" min="0" value="${esc(q.min || '')}" inputmode="numeric"></label>
    <label class="f f--sm"><span>إلى</span><input type="number" name="max" min="0" value="${esc(q.max || '')}" inputmode="numeric"></label>
    <label class="f"><span>الترتيب</span><select name="sort"><option value="">الأبرز</option><option value="newest" ${q.sort === 'newest' ? 'selected' : ''}>الأحدث</option><option value="price_asc" ${q.sort === 'price_asc' ? 'selected' : ''}>السعر: الأقل</option><option value="price_desc" ${q.sort === 'price_desc' ? 'selected' : ''}>السعر: الأعلى</option></select></label>
    <div class="f f--actions"><button class="btn-solid" type="submit">تطبيق</button><a class="link-btn" href="/shop">مسح</a></div>
    <div class="chips"><a class="chip ${q.new === '1' ? 'is-on' : ''}" href="${qs({ new: q.new === '1' ? '' : '1', page: 1 })}">وصل حديثاً</a><a class="chip ${q.sale === '1' ? 'is-on' : ''}" href="${qs({ sale: q.sale === '1' ? '' : '1', page: 1 })}">تخفيضات</a></div>
  </form>
  ${r.items.length ? `<div class="grid">${r.items.map(p => card(p)).join('')}</div>` : `<div class="empty"><p>لا توجد منتجات مطابقة لبحثك.</p><a class="btn-solid" href="/shop">عرض كل المنتجات</a></div>`}
  ${r.pages > 1 ? `<nav class="pager" aria-label="الصفحات">${r.page > 1 ? `<a href="${qs({ page: r.page - 1 })}" rel="prev">السابق</a>` : ''}<span>${r.page} / ${r.pages}</span>${r.page < r.pages ? `<a href="${qs({ page: r.page + 1 })}" rel="next">التالي</a>` : ''}</nav>` : ''}`;
  return layout(ctx, { title: 'المتجر', path: '/shop', description: 'تسوّق مجموعتنا — توصيل إلى 58 ولاية والدفع عند الاستلام.', body, solidHeader: true, noindex: !!(q.q || q.min || q.max || q.size || q.color || q.sort || q.sale || q.new || (q.page && +q.page > 1)) });
}

/* ---------------- Product page ---------------- */
function productPage(ctx, p) {
  const st = store.S('store'); const rel = store.relatedProducts(p);
  const sizes = [...new Set(p.variants.map(v => v.size))], colors = [...new Set(p.variants.map(v => v.color))];
  const colorHex = Object.fromEntries(db.get().prepare('SELECT name,hex FROM colors').all().map(c => [c.name, safeHex(c.hex, '#888888')]));
  const data = { id: p.id, name: p.name, price: p.final_price, variants: p.variants.map(v => ({ id: v.id, size: v.size, color: v.color, stock: v.stock })), image: p.images[0] ? (p.images[0].thumb || p.images[0].file) : '', slug: p.slug, colorHex };
  const imgs = p.images;
  const gallery = imgs.length ? `<div class="gallery"><button class="gallery__main" type="button" id="galMain" aria-label="تكبير الصورة"><img id="galImg" src="${esc(imgs[0].file)}" alt="${esc(imgs[0].alt || p.name)}" width="800" height="1000" fetchpriority="high"></button>
    ${imgs.length > 1 ? `<div class="gallery__thumbs">${imgs.map((im, i) => `<button type="button" class="gallery__thumb ${i ? '' : 'is-on'}" data-src="${esc(im.file)}" data-alt="${esc(im.alt || p.name)}" aria-label="صورة ${i + 1}"><img src="${esc(im.thumb || im.file)}" alt="" loading="lazy" width="96" height="120"></button>`).join('')}</div>` : ''}</div>`
    : `<div class="gallery"><div class="gallery__main product__ph" role="img" aria-label="لا توجد صورة بعد">لا توجد صورة بعد</div></div>`;
  const del = store.S('delivery');
  const body = `<nav class="crumbs" aria-label="مسار التنقل"><a href="/">الرئيسية</a> / <a href="/shop">المتجر</a>${p.category_name ? ` / <a href="/shop?category=${esc(p.category_slug)}">${esc(p.category_name)}</a>` : ''}</nav>
  <section class="pdp">
    ${gallery}
    <div class="pdp__info">
      <h1 class="pdp__title">${esc(p.name)}</h1>
      <p class="pdp__price">${p.on_sale ? `<s>${money(p.price)}</s> ` : ''}<span>${money(p.final_price)}</span></p>
      ${p.description ? `<div class="prose">${renderMarkup(p.description)}</div>` : ''}
      <form id="buyForm" class="buy" novalidate>
        ${sizes.length && !(sizes.length === 1 && sizes[0] === '') ? `<fieldset class="opt"><legend>المقاس</legend><div class="opt__row" id="sizeRow">${sizes.map(s => `<button type="button" class="opt__btn" data-size="${esc(s)}" aria-pressed="false">${esc(s)}</button>`).join('')}</div></fieldset>` : ''}
        ${colors.length && !(colors.length === 1 && colors[0] === '') ? `<fieldset class="opt"><legend>اللون</legend><div class="opt__row" id="colorRow">${colors.map(c => `<button type="button" class="opt__btn opt__btn--color" data-color="${esc(c)}" aria-pressed="false"><i class="sw" data-bg="${esc(colorHex[c] || '#888888')}"></i>${esc(c)}</button>`).join('')}</div></fieldset>` : ''}
        <div class="opt"><label class="qty-l" for="qty">الكمية</label><div class="qty"><button type="button" id="qMinus" aria-label="إنقاص">−</button><input id="qty" type="number" min="1" max="99" value="1" inputmode="numeric"><button type="button" id="qPlus" aria-label="زيادة">+</button></div></div>
        <p class="stock" id="stockMsg" role="status">${p.in_stock ? '' : 'نفد المخزون حالياً'}</p>
        <p class="form-error" id="buyErr" role="alert" hidden></p>
        <div class="buy__actions"><button class="btn-solid btn-solid--lg" id="addBtn" type="submit" ${p.in_stock ? '' : 'disabled'}>أضف إلى السلة</button><a class="link-btn" href="/cart" id="goCart" hidden>عرض السلة ←</a></div>
      </form>
      <ul class="info-list"><li><b>التوصيل:</b> ${esc(del.info || '')}</li><li><b>الدفع:</b> نقداً عند الاستلام</li><li><a href="/p/returns">سياسة الاستبدال والإرجاع</a></li></ul>
    </div>
  </section>
  ${rel.length ? `<section class="related"><h2 class="section-title">قد يعجبك أيضاً</h2><div class="grid">${rel.map(r => card(r)).join('')}</div></section>` : ''}
  <script type="application/json" id="pdata">${JSON.stringify(data).replace(/</g, '\\u003c')}</script>
  <div class="lightbox" id="lightbox" hidden role="dialog" aria-modal="true" aria-label="معرض الصور"><button class="lightbox__close" type="button" id="lbClose" aria-label="إغلاق">×</button><img id="lbImg" alt=""></div>`;
  const ld = { '@context': 'https://schema.org', '@type': 'Product', name: p.name, description: (p.description || p.name).slice(0, 300), image: imgs.map(i => ctx.base + i.file), sku: String(p.id), brand: { '@type': 'Brand', name: st.name },
    offers: { '@type': 'Offer', priceCurrency: 'DZD', price: p.final_price, availability: p.in_stock ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock', url: ctx.base + '/product/' + p.slug } };
  return layout(ctx, { title: p.seo_title || p.name, description: p.seo_description || (p.description || '').replace(/[#>*\-\[\]()]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 160), path: '/product/' + p.slug, image: imgs[0] && imgs[0].file, ogType: 'product', body, jsonld: ld, solidHeader: true, scripts: '<script src="/js/product.js?v=2" defer></script>' });
}

function cartPage(ctx) {
  return layout(ctx, { title: 'السلة', path: '/cart', noindex: true, solidHeader: true, scripts: '<script src="/js/cart.js?v=2" defer></script>',
    body: `<section class="page-head"><h1 class="page-title">سلة التسوق</h1></section><div class="cart" id="cartRoot" aria-live="polite"><p class="empty-note">جاري التحميل…</p></div>` });
}

function checkoutPage(ctx) {
  const ws = db.get().prepare('SELECT * FROM wilayas WHERE enabled=1 ORDER BY code').all(); const del = store.S('delivery');
  const body = `<section class="page-head"><h1 class="page-title">إتمام الطلب</h1><p class="page-sub">الدفع نقداً عند الاستلام — لا حاجة لبطاقة بنكية</p></section>
  <div class="checkout" id="checkoutRoot"><p class="empty-note" id="coLoading">جاري التحميل…</p>
  <form id="coForm" class="co-form" novalidate hidden>
    <div class="co-grid">
      <div class="co-fields">
        <div class="fld"><label for="f_name">الاسم الكامل</label><input id="f_name" name="name" autocomplete="name" required maxlength="80"><p class="err" data-err="name"></p></div>
        <div class="fld"><label for="f_phone">رقم الهاتف</label><input id="f_phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="05 55 12 34 56" dir="ltr" required maxlength="20"><p class="err" data-err="phone"></p></div>
        <div class="fld"><label for="f_wilaya">الولاية</label><select id="f_wilaya" name="wilaya" required><option value="">اختر الولاية</option>${ws.map(w => `<option value="${w.code}">${String(w.code).padStart(2, '0')} - ${esc(w.name_ar)} (${esc(w.name_fr)})</option>`).join('')}</select><p class="err" data-err="wilaya"></p></div>
        <div class="fld"><label for="f_commune">البلدية</label><input id="f_commune" name="commune" autocomplete="address-level2" required maxlength="80"><p class="err" data-err="commune"></p></div>
        <div class="fld fld--full"><label for="f_address">عنوان التوصيل</label><input id="f_address" name="address" autocomplete="street-address" required maxlength="250"><p class="err" data-err="address"></p></div>
        <fieldset class="fld fld--full opt"><legend>طريقة التوصيل</legend><div class="opt__row">
          ${del.home_enabled ? '<label class="radio"><input type="radio" name="method" value="home" checked><span>إلى المنزل</span></label>' : ''}
          ${del.desk_enabled ? `<label class="radio"><input type="radio" name="method" value="desk" ${del.home_enabled ? '' : 'checked'}><span>إلى مكتب التسليم</span></label>` : ''}</div><p class="err" data-err="method"></p></fieldset>
        <div class="fld fld--full"><label for="f_notes">ملاحظات للتوصيل (اختياري)</label><textarea id="f_notes" name="notes" rows="2" maxlength="300"></textarea></div>
      </div>
      <aside class="co-summary" aria-label="ملخص الطلب"><h2 class="section-title">ملخص الطلب</h2><div id="coLines"></div>
        <dl class="totals"><div><dt>المجموع الفرعي</dt><dd id="coSub">—</dd></div><div><dt>التوصيل</dt><dd id="coFee">اختر الولاية</dd></div><div class="totals__final"><dt>الإجمالي</dt><dd id="coTotal">—</dd></div></dl>
        <p class="pay-note">الدفع نقداً عند الاستلام.</p>
        <p class="form-error" id="coErr" role="alert" hidden></p>
        <button class="btn-solid btn-solid--lg btn-block" id="coSubmit" type="submit">تأكيد الطلب</button>
        <p class="fine">بالضغط على «تأكيد الطلب» فإنك توافق على <a href="/p/terms">الشروط والأحكام</a> و<a href="/p/privacy">سياسة الخصوصية</a>.</p>
      </aside>
    </div>
  </form></div>`;
  return layout(ctx, { title: 'إتمام الطلب', path: '/checkout', noindex: true, solidHeader: true, body, scripts: '<script src="/js/cart.js?v=2" defer></script><script src="/js/checkout.js?v=2" defer></script>' });
}

function orderPage(ctx, o) {
  const st = store.S('store'); const wa = waNumber(st.whatsapp);
  const lines = o.items.map(i => `• ${i.name}${i.size ? ' / ' + i.size : ''}${i.color ? ' / ' + i.color : ''} × ${i.qty} = ${money(i.unit_price * i.qty)}`).join('\n');
  const msg = `السلام عليكم، لقد قمت بطلب رقم ${o.ref}\n${lines}\nالإجمالي: ${money(o.total)}\nالاسم: ${o.customer_name}\nالولاية: ${o.wilaya_name}`;
  const L = { new: 'تم استلام طلبك', pending: 'قيد المعالجة', confirmed: 'تم تأكيد الطلب', shipped: 'تم شحن الطلب', delivered: 'تم التسليم', cancelled: 'ملغى' };
  const body = `<section class="confirm"><p class="confirm__tick" aria-hidden="true">✓</p><h1 class="page-title">شكراً لك، ${esc(o.customer_name.split(' ')[0])}!</h1>
  <p class="page-sub">تم تسجيل طلبك بنجاح. سيتصل بك فريقنا على الرقم <b dir="ltr">${esc(o.phone)}</b> لتأكيده.</p>
  <div class="ref-box"><span>رقم الطلب</span><b dir="ltr" id="orderRef">${esc(o.ref)}</b></div>
  <p class="status-pill">الحالة: ${esc(L[o.status] || o.status)}</p>
  <div class="co-summary co-summary--flat"><table class="tbl"><thead><tr><th>المنتج</th><th>الكمية</th><th>السعر</th></tr></thead><tbody>${o.items.map(i => `<tr><td>${esc(i.name)}${i.size || i.color ? `<br><small>${esc([i.size, i.color].filter(Boolean).join(' · '))}</small>` : ''}</td><td>${i.qty}</td><td>${money(i.unit_price * i.qty)}</td></tr>`).join('')}</tbody></table>
    <dl class="totals"><div><dt>المجموع الفرعي</dt><dd>${money(o.subtotal)}</dd></div><div><dt>التوصيل (${o.delivery_method === 'home' ? 'إلى المنزل' : 'إلى المكتب'})</dt><dd>${o.delivery_fee ? money(o.delivery_fee) : 'مجاني'}</dd></div><div class="totals__final"><dt>الإجمالي عند الاستلام</dt><dd>${money(o.total)}</dd></div></dl>
    <p class="fine">${esc(o.wilaya_name)} — ${esc(o.commune)} — ${esc(o.address)}</p></div>
  <div class="confirm__actions">${wa ? `<a class="btn-solid" href="https://wa.me/${wa}?text=${encodeURIComponent(msg)}" target="_blank" rel="noopener noreferrer">تواصل معنا عبر واتساب</a>` : ''}<a class="link-btn" href="/shop">متابعة التسوق</a></div>
  <p class="fine">احتفظ برقم الطلب. هذه الصفحة خاصة بك — لا تشاركها مع الآخرين.</p></section>`;
  return layout(ctx, { title: 'تأكيد الطلب', path: '/order/' + o.ref, noindex: true, canonical: false, solidHeader: true, body, scripts: '<script src="/js/cart.js?v=2" defer></script><script src="/js/confirm.js?v=2" defer></script>' });
}

function contentPage(ctx, pg) {
  const body = `<article class="doc"><h1 class="page-title">${esc(pg.title)}</h1><div class="prose prose--wide">${renderMarkup(pg.content)}</div></article>`;
  return layout(ctx, { title: pg.seo_title || pg.title, description: pg.seo_description || '', path: '/p/' + pg.slug, body, solidHeader: true });
}

function messagePage(ctx, status, title, text) {
  return layout(ctx, { title, noindex: true, canonical: false, solidHeader: true, body: `<section class="empty empty--big"><p class="empty__code" lang="en" dir="ltr">${status}</p><h1 class="page-title">${esc(title)}</h1><p>${esc(text)}</p><a class="btn-solid" href="/">العودة إلى الرئيسية</a></section>` });
}

module.exports = { layout, themeCss, homePage, shopPage, productPage, cartPage, checkoutPage, orderPage, contentPage, messagePage, FONT_NAMES };
