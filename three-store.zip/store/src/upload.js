'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const config = require('./config');
const db = require('./db');
const { HttpError } = require('./http');

let sharp = null;
try { sharp = require('sharp'); } catch { /* optional dependency — images are stored as uploaded when absent */ }

/** Detect real file type from magic bytes (never trust the extension or client MIME). */
function detect(buf) {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { ext: 'jpg', kind: 'image' };
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { ext: 'png', kind: 'image' };
  if (buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return { ext: 'webp', kind: 'image' };
  if (buf[0] === 0 && buf[1] === 0 && buf[2] === 1 && buf[3] === 0) return { ext: 'ico', kind: 'image' };
  if (buf.subarray(4, 8).toString('latin1') === 'ftyp') return { ext: 'mp4', kind: 'video' };
  if (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return { ext: 'webm', kind: 'video' };
  return null;
}

/** Validate + store an uploaded file. `allowVideo` only for hero media. Returns { url, thumb, kind, id }. */
async function saveUpload(file, { allowVideo = false } = {}) {
  const type = detect(file.data);
  if (!type) throw new HttpError(400, 'نوع الملف غير مسموح. المسموح: JPG, PNG, WebP' + (allowVideo ? ', MP4, WebM' : ''));
  if (type.kind === 'video' && !allowVideo) throw new HttpError(400, 'الفيديو غير مسموح هنا');
  const max = type.kind === 'video' ? config.MAX_VIDEO_BYTES : config.MAX_IMAGE_BYTES;
  if (file.data.length > max) throw new HttpError(413, `الحجم الأقصى ${Math.round(max / 1048576)}MB`);
  fs.mkdirSync(config.UPLOAD_DIR, { recursive: true });
  const id = crypto.randomBytes(12).toString('hex');
  let data = file.data, ext = type.ext, thumbName = null;
  if (sharp && type.kind === 'image' && type.ext !== 'ico') {
    try {
      const img = sharp(file.data, { failOn: 'error' }).rotate();           // auto-orient, strips EXIF
      data = await img.clone().resize({ width: 1600, height: 1600, fit: 'inside', withoutEnlargement: true }).webp({ quality: 82 }).toBuffer();
      ext = 'webp';
      const t = await img.clone().resize({ width: 520, withoutEnlargement: true }).webp({ quality: 74 }).toBuffer();
      thumbName = `${id}-t.webp`; fs.writeFileSync(path.join(config.UPLOAD_DIR, thumbName), t);
    } catch { throw new HttpError(400, 'الصورة تالفة أو غير مدعومة'); }
  }
  const name = `${id}.${ext}`;
  fs.writeFileSync(path.join(config.UPLOAD_DIR, name), data, { mode: 0o644 });
  const r = db.get().prepare('INSERT INTO media(file,thumb,kind,original_name,size) VALUES (?,?,?,?,?)')
    .run(name, thumbName, type.kind, String(file.filename || '').replace(/[^\w.\- ؀-ۿ]/g, '').slice(0, 100), data.length);
  return { id: Number(r.lastInsertRowid), url: '/uploads/' + name, thumb: '/uploads/' + (thumbName || name), kind: type.kind };
}

function deleteMedia(id) {
  const m = db.get().prepare('SELECT * FROM media WHERE id=?').get(id);
  if (!m) return false;
  for (const f of [m.file, m.thumb]) if (f && /^[\w.\-]+$/.test(f)) { try { fs.unlinkSync(path.join(config.UPLOAD_DIR, f)); } catch {} }
  db.get().prepare('DELETE FROM media WHERE id=?').run(id);
  return true;
}
module.exports = { saveUpload, deleteMedia, detect, hasSharp: () => !!sharp };
