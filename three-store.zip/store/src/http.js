'use strict';
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const config = require('./config');

class HttpError extends Error { constructor(status, message, extra) { super(message); this.status = status; this.extra = extra; } }

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.ico': 'image/x-icon',
  '.mp4': 'video/mp4', '.webm': 'video/webm', '.woff2': 'font/woff2', '.svg': 'image/svg+xml',
};
const COMPRESSIBLE = new Set(['.html', '.css', '.js', '.json', '.txt', '.xml', '.svg']);

function clientIp(req) {
  if (config.TRUST_PROXY) {
    const f = req.headers['fly-client-ip'] || (req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (f) return f;
  }
  return req.socket.remoteAddress || '';
}
function isHttps(req) { return !!req.socket.encrypted || (config.TRUST_PROXY && req.headers['x-forwarded-proto'] === 'https'); }

function parseCookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('='); if (i < 0) continue;
    const k = part.slice(0, i).trim(); if (!k) continue;
    try { out[k] = decodeURIComponent(part.slice(i + 1).trim()); } catch { /* ignore */ }
  }
  return out;
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const declared = parseInt(req.headers['content-length'] || '0', 10);
    if (declared > limit) { req.resume(); return reject(new HttpError(413, 'الحجم كبير جداً')); }
    const chunks = []; let size = 0;
    req.on('data', c => { size += c.length; if (size > limit) { reject(new HttpError(413, 'الحجم كبير جداً')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
async function readJson(req) {
  const ct = (req.headers['content-type'] || '').toLowerCase();
  if (!ct.startsWith('application/json')) throw new HttpError(415, 'Content-Type must be application/json');
  const buf = await readBody(req, config.MAX_JSON_BYTES);
  if (!buf.length) return {};
  try { const v = JSON.parse(buf.toString('utf8')); if (v === null || typeof v !== 'object') throw 0; return v; }
  catch { throw new HttpError(400, 'JSON غير صالح'); }
}

/** Minimal multipart/form-data parser (in-memory, size-limited). Returns { fields, files:[{name, filename, data}] } */
async function readMultipart(req, limit) {
  const ct = req.headers['content-type'] || '';
  const m = ct.match(/^multipart\/form-data;\s*boundary=(?:"([^"]+)"|([^;]+))/i);
  if (!m) throw new HttpError(415, 'multipart/form-data مطلوب');
  const boundary = Buffer.from('--' + (m[1] || m[2]));
  const body = await readBody(req, limit);
  const fields = {}, files = [];
  let pos = body.indexOf(boundary);
  while (pos !== -1) {
    const start = pos + boundary.length;
    if (body[start] === 0x2d && body[start + 1] === 0x2d) break;
    const next = body.indexOf(boundary, start);
    if (next === -1) break;
    const part = body.subarray(start + 2, next - 2); // strip CRLF around
    const headEnd = part.indexOf('\r\n\r\n');
    if (headEnd > 0) {
      const head = part.subarray(0, headEnd).toString('utf8');
      const data = part.subarray(headEnd + 4);
      const cd = head.match(/content-disposition:[^\r\n]*?[;\s]name="([^"]*)"(?:[^\r\n]*?[;\s]filename="([^"]*)")?/i);
      if (cd) { if (cd[2] !== undefined && cd[2] !== '') files.push({ name: cd[1], filename: cd[2], data }); else if (cd[2] === undefined) fields[cd[1]] = data.toString('utf8'); }
    }
    pos = next;
  }
  return { fields, files };
}

function send(res, status, body, headers = {}, req) {
  const h = { ...headers };
  let buf = Buffer.isBuffer(body) ? body : Buffer.from(body ?? '');
  const ae = req && req.headers['accept-encoding'] || '';
  const ct = String(h['Content-Type'] || '');
  if (buf.length > 1024 && /text|json|javascript|xml|svg/.test(ct) && /\bgzip\b/.test(ae)) {
    buf = zlib.gzipSync(buf, { level: 6 }); h['Content-Encoding'] = 'gzip'; h['Vary'] = 'Accept-Encoding';
  }
  h['Content-Length'] = buf.length;
  res.writeHead(status, h);
  res.end(req && req.method === 'HEAD' ? undefined : buf);
}
const json = (res, status, obj, headers = {}, req) => send(res, status, JSON.stringify(obj), { 'Content-Type': MIME['.json'], 'Cache-Control': 'no-store', ...headers }, req);
const html = (res, status, body, headers = {}, req) => send(res, status, body, { 'Content-Type': MIME['.html'], ...headers }, req);
const redirect = (res, loc, status = 302, headers = {}) => { res.writeHead(status, { Location: loc, ...headers }); res.end(); };

/** Serve a file from `root` safely (no traversal, no dotfiles). */
function serveFile(req, res, root, rel, { cache = 'public, max-age=3600', headers = {} } = {}) {
  let decoded; try { decoded = decodeURIComponent(rel); } catch { return false; }
  if (decoded.includes('\0') || decoded.split(/[\\/]/).some(seg => seg === '..' || seg.startsWith('.'))) return false;
  const full = path.resolve(root, '.' + path.posix.normalize('/' + decoded));
  if (!full.startsWith(path.resolve(root) + path.sep)) return false;
  let st; try { st = fs.statSync(full); } catch { return false; }
  if (!st.isFile()) return false;
  const ext = path.extname(full).toLowerCase();
  const type = MIME[ext]; if (!type) return false;
  const etag = `W/"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}"`;
  const base = { 'Content-Type': type, 'Cache-Control': cache, ETag: etag, 'Last-Modified': st.mtime.toUTCString(), ...headers };
  if (req.headers['if-none-match'] === etag) { res.writeHead(304, base); res.end(); return true; }
  // Range support for video
  const range = req.headers.range && /^bytes=(\d*)-(\d*)$/.exec(req.headers.range);
  if (range && (ext === '.mp4' || ext === '.webm')) {
    let s = range[1] === '' ? Math.max(0, st.size - parseInt(range[2], 10)) : parseInt(range[1], 10);
    let e = range[1] === '' || range[2] === '' ? st.size - 1 : Math.min(parseInt(range[2], 10), st.size - 1);
    if (s > e || s >= st.size) { res.writeHead(416, { 'Content-Range': `bytes */${st.size}` }); res.end(); return true; }
    res.writeHead(206, { ...base, 'Content-Range': `bytes ${s}-${e}/${st.size}`, 'Accept-Ranges': 'bytes', 'Content-Length': e - s + 1 });
    if (req.method === 'HEAD') return res.end(), true;
    fs.createReadStream(full, { start: s, end: e }).pipe(res); return true;
  }
  if (COMPRESSIBLE.has(ext) && st.size < 2_000_000 && /\bgzip\b/.test(req.headers['accept-encoding'] || '') ) {
    send(res, 200, fs.readFileSync(full), base, req); return true;
  }
  res.writeHead(200, { ...base, 'Content-Length': st.size, 'Accept-Ranges': 'bytes' });
  if (req.method === 'HEAD') return res.end(), true;
  fs.createReadStream(full).pipe(res); return true;
}

module.exports = { HttpError, MIME, clientIp, isHttps, parseCookies, readBody, readJson, readMultipart, send, json, html, redirect, serveFile };
