'use strict';
const fs = require('node:fs');
const path = require('node:path');
const db = require('./db');
const config = require('./config');
const sec = require('./security');
const store = require('./store');
const upload = require('./upload');
const views = require('./views');
const { HttpError, json, readJson, readMultipart, parseCookies, clientIp, isHttps, send } = require('./http');
const { str, clampInt, strictInt, slugify, safeUrl, safeImg, safeHex, normalizePhone } = require('./util');

const COOKIE = 'three_sid';
const cookieName = () => COOKIE;

/* ---------------- helpers ---------------- */
function audit(ctx, action, entity = '', id = '', detail = '') {
  db.get().prepare('INSERT INTO audit_log(admin_id,admin_name,action,entity,entity_id,detail,ip) VALUES (?,?,?,?,?,?,?)')
    .run(ctx.session ? ctx.session.adminId : null, ctx.session ? ctx.session.username : '', action, entity, String(id), String(detail).slice(0, 500), ctx.ip || '');
}
function autoBackup(label) {
  try {
    const f = path.join(config.BACKUP_DIR, `auto-${label}-${db.stamp()}.db`); db.backupTo(f);
    const olds = fs.readdirSync(config.BACKUP_DIR).filter(n => n.startsWith('auto-')).sort();
    while (olds.length > 30) { try { fs.unlinkSync(path.join(config.BACKUP_DIR, olds.shift())); } catch {} }
    return path.basename(f);
  } catch (e) { console.error('auto backup failed:', e.message); return null; }
}
const bool = (v) => v === true || v === 1 || v === '1' || v === 'true';
const owner = (ctx) => { if (ctx.session.role !== 'owner') throw new HttpError(403, 'هذه العملية للمالك فقط'); };
function reauth(ctx, password) {
  const a = db.get().prepare('SELECT password_hash FROM admins WHERE id=?').get(ctx.session.adminId);
  const rk = 'reauth:' + ctx.session.adminId;
  if (!sec.rateCheck(rk, 5)) throw new HttpError(429, 'محاولات كثيرة، حاول لاحقاً');
  if (typeof password !== 'string' || !a || !sec.verifyPassword(password, a.password_hash)) { sec.rateLimit(rk, 5, 15 * 60 * 1000); throw new HttpError(403, 'كلمة المرور غير صحيحة'); }
  sec.rateReset(rk);
}
const needConfirm = (ctx) => { if (ctx.url.searchParams.get('confirm') !== '1') throw new HttpError(400, 'يتطلب تأكيداً (confirm=1)'); };
const uniqueSlug = (table, base, exceptId = 0) => {
  let s = slugify(base), n = 1, cand = s;
  while (db.get().prepare(`SELECT 1 FROM ${table} WHERE slug=? AND id!=?`).get(cand, exceptId)) cand = `${s}-${++n}`;
  return cand;
};

/* ---------------- settings schema ---------------- */
const SETTINGS_SCHEMA = {
  store: { name: 's:60', tagline: 's:120', description: 's:300', phone: 'phone', whatsapp: 'phone', email: 'email', instagram: 'social:instagram', facebook: 'social:facebook', tiktok: 'social:tiktok', address: 's:200', currency_label: 's:10' },
  status: { open: 'bool', maintenance_message: 's:300' },
  announcement: { enabled: 'bool', text: 's:160', url: 'url' },
  delivery: { home_enabled: 'bool', desk_enabled: 'bool', cod_enabled: 'bool', free_threshold: 'int:0-10000000', info: 's:300' },
  theme: { bg: 'hex', bg_soft: 'hex', surface: 'hex', ink: 'hex', ink_dim: 'hex', accent: 'hex', accent_ink: 'hex', font_display: 'font', font_body: 'font', font_latin: 'font', logo_size: 'int:24-120', base_font_size: 'int:13-22' },
  anim: { preloader: 'bool', cursor: 'bool', reveal: 'bool', words: 'bool', parallax: 'bool', marquee: 'bool', elastic: 'bool', orbit: 'bool', hover: 'bool' },
  branding: { logo: 'img', favicon: 'img', og_image: 'img' },
  seo: { title_suffix: 's:40', default_description: 's:300' },
  footer: { text: 's:200', show_marquee: 'bool' },
};
function cleanValue(type, v, key) {
  const [t, arg] = type.split(/:(.*)/s);
  switch (t) {
    case 's': return str(v, parseInt(arg, 10));
    case 'bool': return bool(v);
    case 'int': { const [a, b] = arg.split('-').map(Number); const n = parseInt(v, 10); if (!Number.isFinite(n) || n < a || n > b) throw new HttpError(422, `القيمة خارج النطاق: ${key}`); return n; }
    case 'hex': if (!/^#[0-9a-fA-F]{6}$/.test(String(v))) throw new HttpError(422, `لون غير صالح: ${key}`); return String(v).toLowerCase();
    case 'font': if (!views.FONT_NAMES.includes(v)) throw new HttpError(422, 'خط غير مسموح'); return v;
    case 'url': { v = str(v, 300); if (v && safeUrl(v, '') === '') throw new HttpError(422, 'رابط غير صالح'); return v; }
    case 'img': { v = str(v, 200); if (v && !safeImg(v)) throw new HttpError(422, 'صورة غير صالحة'); return v; }
    case 'phone': { v = str(v, 30); if (v && !/^[+\d\s\-().]{6,30}$/.test(v)) throw new HttpError(422, 'رقم هاتف غير صالح'); return v; }
    case 'email': { v = str(v, 100); if (v && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) throw new HttpError(422, 'بريد إلكتروني غير صالح'); return v; }
    case 'social': { v = str(v, 200); if (!v) return ''; if (/^https?:\/\//i.test(v)) return v; const h = v.replace(/^@/, ''); if (!/^[\w.\-]{2,60}$/.test(h)) throw new HttpError(422, 'حساب غير صالح'); return `https://${arg}.com/${h}`; }
    default: return v;
  }
}
function cleanGroup(group, input) {
  const schema = SETTINGS_SCHEMA[group]; if (!schema) throw new HttpError(404, 'مجموعة إعدادات غير معروفة');
  const cur = store.S(group), out = { ...cur };
  for (const [k, type] of Object.entries(schema)) if (Object.prototype.hasOwnProperty.call(input, k)) out[k] = cleanValue(type, input[k], k);   // allowlist: unknown keys ignored (no mass assignment)
  if (group === 'store' && !out.name) throw new HttpError(422, 'اسم المتجر مطلوب');
  return out;
}

/* ---------------- home section schema ---------------- */
const SECTION_SCHEMA = {
  hero: { giant: 's:40', kicker: 's:60', title: 's:200', button_text: 's:40', button_url: 'url', media_type: 'enum:logo|image|video|none', media: 'img', video_poster: 'img' },
  marquee: { text: 's:200' },
  story: { label: 's:60', heading: 's:160', paragraphs: 'arr:600:4', image: 'img', caption: 's:120', stats: 'stats' },
  products: { label: 's:60', heading: 's:160', source: 'enum:featured|new|sale|category|all', category_id: 'int:0-1000000', limit: 'int:1-12', button_text: 's:40', button_url: 'url' },
  banner: { image: 'img', title: 's:120', text: 's:300', button_text: 's:40', button_url: 'url', align: 'enum:start|center|end' },
  richtext: { label: 's:60', heading: 's:160', body: 's:8000' },
  manifesto: { label: 's:60', line1: 's:120', line2: 's:120' },
  finale: { label: 's:60', heading: 's:160', image: 'img', button_text: 's:40', button_url: 'url' },
};
function cleanSection(type, input, current = {}) {
  const schema = SECTION_SCHEMA[type]; const out = { ...current };
  for (const [k, t] of Object.entries(schema)) {
    if (!Object.prototype.hasOwnProperty.call(input, k)) continue;
    const v = input[k];
    if (t.startsWith('enum:')) { if (!t.slice(5).split('|').includes(v)) throw new HttpError(422, `قيمة غير صالحة: ${k}`); out[k] = v; }
    else if (t.startsWith('arr:')) { const [, max, n] = t.split(':'); out[k] = (Array.isArray(v) ? v : []).slice(0, +n).map(x => str(x, +max)).filter(Boolean); }
    else if (t === 'stats') out[k] = (Array.isArray(v) ? v : []).slice(0, 4).map(x => ({ value: str(x && x.value, 8), label: str(x && x.label, 30) })).filter(x => x.value || x.label);
    else out[k] = cleanValue(t, v, k);
  }
  return out;
}

/* ---------------- product save ---------------- */
function saveProduct(ctx, id, b) {
  const d = db.get();
  const name = str(b.name, 120); if (name.length < 2) throw new HttpError(422, 'اسم المنتج مطلوب');
  const price = strictInt(b.price, 0, 10_000_000); if (price === null) throw new HttpError(422, 'السعر غير صالح');
  let sale = (b.sale_price === '' || b.sale_price == null) ? null : strictInt(b.sale_price, 0, 10_000_000);
  if (b.sale_price !== '' && b.sale_price != null && sale === null) throw new HttpError(422, 'سعر التخفيض غير صالح');
  if (sale !== null && sale >= price) throw new HttpError(422, 'سعر التخفيض يجب أن يكون أقل من السعر الأصلي');
  const status = ['draft', 'published', 'archived'].includes(b.status) ? b.status : 'draft';
  const cat = b.category_id ? clampInt(b.category_id, 1, 1e9, 0) : null;
  if (cat && !d.prepare('SELECT 1 FROM categories WHERE id=?').get(cat)) throw new HttpError(422, 'فئة غير موجودة');
  const variants = []; const seen = new Set();
  for (const v of (Array.isArray(b.variants) ? b.variants : []).slice(0, 200)) {
    const size = str(v.size, 40), color = str(v.color, 40), key = size + '\u0000' + color;
    if (seen.has(key)) throw new HttpError(422, 'متغيّر مكرر (نفس المقاس واللون)'); seen.add(key);
    const stock = strictInt(v.stock, 0, 1_000_000); if (stock === null) throw new HttpError(422, 'كمية مخزون غير صالحة');
    variants.push({ size, color, stock });
  }
  if (status === 'published') {
    if (price <= 0) throw new HttpError(422, 'حدّد سعراً أكبر من صفر قبل النشر');
    if (!variants.length) throw new HttpError(422, 'أضف مقاساً/لوناً واحداً على الأقل قبل النشر');
  }
  const images = [];
  for (const im of (Array.isArray(b.images) ? b.images : []).slice(0, 12)) {
    const file = safeImg(im.file); if (!file) throw new HttpError(422, 'مسار صورة غير صالح');
    images.push({ file, thumb: safeImg(im.thumb) || file, alt: str(im.alt, 150) });
  }
  const fields = [name, str(b.description, 4000), cat, price, sale, status, bool(b.featured) ? 1 : 0, bool(b.is_new) ? 1 : 0, str(b.tags, 200), str(b.seo_title, 120), str(b.seo_description, 300)];
  return db.tx(() => {
    let pid = id;
    if (id) {
      if (!d.prepare('SELECT 1 FROM products WHERE id=?').get(id)) throw new HttpError(404, 'المنتج غير موجود');
      d.prepare(`UPDATE products SET name=?,description=?,category_id=?,price=?,sale_price=?,status=?,featured=?,is_new=?,tags=?,seo_title=?,seo_description=?,updated_at=datetime('now') WHERE id=?`).run(...fields, id);
      if (b.slug && str(b.slug, 80)) d.prepare('UPDATE products SET slug=? WHERE id=?').run(uniqueSlug('products', b.slug, id), id);
    } else {
      const r = d.prepare(`INSERT INTO products(name,description,category_id,price,sale_price,status,featured,is_new,tags,seo_title,seo_description,slug) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(...fields, uniqueSlug('products', b.slug || name));
      pid = Number(r.lastInsertRowid);
    }
    // variants: match by (size,color) to keep ids stable
    const existing = d.prepare('SELECT * FROM product_variants WHERE product_id=?').all(pid);
    for (const e of existing) if (!seen.has(e.size + '\u0000' + e.color)) d.prepare('DELETE FROM product_variants WHERE id=?').run(e.id);
    for (const v of variants) {
      const e = existing.find(x => x.size === v.size && x.color === v.color);
      if (e) d.prepare('UPDATE product_variants SET stock=? WHERE id=?').run(v.stock, e.id);
      else d.prepare('INSERT INTO product_variants(product_id,size,color,stock) VALUES (?,?,?,?)').run(pid, v.size, v.color, v.stock);
    }
    d.prepare('DELETE FROM product_images WHERE product_id=?').run(pid);
    images.forEach((im, i) => d.prepare('INSERT INTO product_images(product_id,file,thumb,alt,sort) VALUES (?,?,?,?,?)').run(pid, im.file, im.thumb, im.alt, i));
    d.prepare('DELETE FROM product_related WHERE product_id=?').run(pid);
    for (const rid of (Array.isArray(b.related) ? b.related : []).slice(0, 12)) {
      const n = clampInt(rid, 1, 1e9, 0); if (n && n !== pid && d.prepare('SELECT 1 FROM products WHERE id=?').get(n)) d.prepare('INSERT OR IGNORE INTO product_related(product_id,related_id) VALUES (?,?)').run(pid, n);
    }
    audit(ctx, id ? 'product.update' : 'product.create', 'product', pid, name);
    return pid;
  });
}
function productFull(id) {
  const p = store.getProductById(id); if (!p) return null;
  p.related = db.get().prepare('SELECT related_id FROM product_related WHERE product_id=?').all(id).map(r => r.related_id);
  return p;
}

/* ---------------- orders ---------------- */
function orderQuery(url) {
  const g = (k) => url.searchParams.get(k) || '';
  const where = [], args = [];
  const status = g('status'); if (status && store.STATUSES.includes(status)) { where.push('status=?'); args.push(status); }
  const w = clampInt(g('wilaya'), 0, 58, 0); if (w) { where.push('wilaya_code=?'); args.push(w); }
  if (/^\d{4}-\d{2}-\d{2}$/.test(g('from'))) { where.push('date(created_at) >= ?'); args.push(g('from')); }
  if (/^\d{4}-\d{2}-\d{2}$/.test(g('to'))) { where.push('date(created_at) <= ?'); args.push(g('to')); }
  const q = str(g('q'), 60); if (q) { const l = '%' + q.replace(/[\\%_]/g, '\\$&') + '%'; where.push("(ref LIKE ? ESCAPE '\\' OR customer_name LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\' OR commune LIKE ? ESCAPE '\\')"); args.push(l, l, l, l); }
  const order = { oldest: 'id ASC', total_desc: 'total DESC, id DESC', total_asc: 'total ASC, id DESC' }[g('sort')] || 'id DESC';
  return { clause: where.length ? 'WHERE ' + where.join(' AND ') : '', args, order };
}
const csvCell = (v) => { let s = String(v ?? ''); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };

/* ---------------- main handler ---------------- */
async function handle(req, res, url) {
  const ip = clientIp(req); const p = url.pathname.slice('/api/admin'.length) || '/'; const method = req.method;
  const ctx = { req, res, url, ip, session: null };
  const sid = parseCookies(req)[COOKIE]; ctx.sid = sid;
  const d = db.get();

  // Same-origin check for state-changing requests
  if (method !== 'GET' && method !== 'HEAD') {
    const origin = req.headers.origin;
    if (origin) { try { if (new URL(origin).host !== req.headers.host) throw 0; } catch { throw new HttpError(403, 'Origin غير مسموح'); } }
  }

  if (p === '/login' && method === 'POST') return login(ctx);

  ctx.session = sec.getSession(sid);
  if (!ctx.session) throw new HttpError(401, 'يجب تسجيل الدخول');
  if (method !== 'GET' && method !== 'HEAD') {
    if (!sec.safeEqual(req.headers['x-csrf-token'] || '', ctx.session.csrf)) throw new HttpError(403, 'رمز CSRF غير صالح');
  }
  const R = (re) => { const m = p.match(re); return m ? m.slice(1) : null; };
  let m;

  if (p === '/me' && method === 'GET') return json(res, 200, { username: ctx.session.username, role: ctx.session.role, csrf: ctx.session.csrf, totp_enabled: ctx.session.totp_enabled, fonts: views.FONT_NAMES, sharp: upload.hasSharp() });
  if (p === '/logout' && method === 'POST') { sec.destroySession(sid); audit(ctx, 'logout'); return json(res, 200, { ok: true }, { 'Set-Cookie': clearCookie(req) }); }

  if (p === '/password' && method === 'POST') {
    const b = await readJson(req); reauth(ctx, b.current);
    const prob = sec.passwordProblem(b.new); if (prob) throw new HttpError(422, prob);
    d.prepare('UPDATE admins SET password_hash=? WHERE id=?').run(sec.hashPassword(b.new), ctx.session.adminId);
    sec.destroyAllSessions(ctx.session.adminId, ctx.session.hash);
    audit(ctx, 'password.change'); return json(res, 200, { ok: true });
  }
  if (p === '/totp/setup' && method === 'POST') {
    const b = await readJson(req); reauth(ctx, b.password);
    const secret = sec.totpNewSecret(); d.prepare('UPDATE admins SET totp_secret=?, totp_enabled=0 WHERE id=?').run(secret, ctx.session.adminId);
    return json(res, 200, { secret, uri: `otpauth://totp/${encodeURIComponent(store.S('store').name)}:${encodeURIComponent(ctx.session.username)}?secret=${secret}&issuer=${encodeURIComponent(store.S('store').name)}` });
  }
  if (p === '/totp/enable' && method === 'POST') {
    const b = await readJson(req); const a = d.prepare('SELECT totp_secret FROM admins WHERE id=?').get(ctx.session.adminId);
    if (!a.totp_secret || !sec.totpVerify(a.totp_secret, b.code)) throw new HttpError(422, 'الرمز غير صحيح');
    d.prepare('UPDATE admins SET totp_enabled=1 WHERE id=?').run(ctx.session.adminId); audit(ctx, 'totp.enable'); return json(res, 200, { ok: true });
  }
  if (p === '/totp/disable' && method === 'POST') {
    const b = await readJson(req); reauth(ctx, b.password);
    d.prepare('UPDATE admins SET totp_enabled=0, totp_secret=NULL WHERE id=?').run(ctx.session.adminId); audit(ctx, 'totp.disable'); return json(res, 200, { ok: true });
  }

  /* ----- admins (owner) ----- */
  if (p === '/admins' && method === 'GET') { owner(ctx); return json(res, 200, { items: d.prepare('SELECT id,username,role,active,totp_enabled,created_at,last_login_at FROM admins ORDER BY id').all() }); }
  if (p === '/admins' && method === 'POST') {
    owner(ctx); const b = await readJson(req); reauth(ctx, b.password_confirm);
    const username = str(b.username, 40); if (!/^[\w.\-]{3,40}$/.test(username)) throw new HttpError(422, 'اسم مستخدم غير صالح (حروف لاتينية وأرقام)');
    const prob = sec.passwordProblem(b.password); if (prob) throw new HttpError(422, prob);
    if (d.prepare('SELECT 1 FROM admins WHERE username=?').get(username)) throw new HttpError(409, 'اسم المستخدم مستخدم');
    const r = d.prepare('INSERT INTO admins(username,password_hash,role) VALUES (?,?,?)').run(username, sec.hashPassword(b.password), b.role === 'owner' ? 'owner' : 'staff');
    audit(ctx, 'admin.create', 'admin', r.lastInsertRowid, username); return json(res, 201, { id: Number(r.lastInsertRowid) });
  }
  if ((m = R(/^\/admins\/(\d+)$/))) {
    owner(ctx); const id = +m[0];
    if (method === 'PATCH') {
      const b = await readJson(req); reauth(ctx, b.password_confirm);
      const a = d.prepare('SELECT * FROM admins WHERE id=?').get(id); if (!a) throw new HttpError(404, 'غير موجود');
      if (id === ctx.session.adminId && (b.active === false || (b.role && b.role !== 'owner'))) throw new HttpError(400, 'لا يمكنك تعطيل نفسك');
      if (b.password) { const prob = sec.passwordProblem(b.password); if (prob) throw new HttpError(422, prob); d.prepare('UPDATE admins SET password_hash=? WHERE id=?').run(sec.hashPassword(b.password), id); sec.destroyAllSessions(id); }
      if (b.role) d.prepare('UPDATE admins SET role=? WHERE id=?').run(b.role === 'owner' ? 'owner' : 'staff', id);
      if (typeof b.active === 'boolean') { d.prepare('UPDATE admins SET active=? WHERE id=?').run(b.active ? 1 : 0, id); if (!b.active) sec.destroyAllSessions(id); }
      audit(ctx, 'admin.update', 'admin', id, a.username); return json(res, 200, { ok: true });
    }
    if (method === 'DELETE') {
      needConfirm(ctx); const b = await readJson(req).catch(() => ({})); reauth(ctx, b.password_confirm);
      if (id === ctx.session.adminId) throw new HttpError(400, 'لا يمكنك حذف نفسك');
      d.prepare('DELETE FROM admins WHERE id=?').run(id); audit(ctx, 'admin.delete', 'admin', id); return json(res, 200, { ok: true });
    }
  }

  /* ----- dashboard ----- */
  if (p === '/dashboard' && method === 'GET') return json(res, 200, store.dashboard());

  /* ----- orders ----- */
  if (p === '/orders' && method === 'GET') {
    const { clause, args, order } = orderQuery(url); const per = 25, page = clampInt(url.searchParams.get('page'), 1, 100000, 1);
    const total = d.prepare(`SELECT COUNT(*) n FROM orders ${clause}`).get(...args).n;
    const items = d.prepare(`SELECT id,ref,customer_name,phone,wilaya_name,commune,total,delivery_fee,status,created_at FROM orders ${clause} ORDER BY ${order} LIMIT ? OFFSET ?`).all(...args, per, (page - 1) * per);
    return json(res, 200, { items, total, page, pages: Math.max(1, Math.ceil(total / per)) });
  }
  if (p === '/orders.csv' && method === 'GET') {
    const { clause, args, order } = orderQuery(url);
    const rows = d.prepare(`SELECT * FROM orders ${clause} ORDER BY ${order} LIMIT 20000`).all(...args);
    const itemsBy = new Map(); for (const it of d.prepare('SELECT * FROM order_items').all()) { (itemsBy.get(it.order_id) || itemsBy.set(it.order_id, []).get(it.order_id)).push(it); }
    const head = ['ref', 'created_at', 'status', 'name', 'phone', 'wilaya', 'commune', 'address', 'delivery', 'items', 'subtotal', 'delivery_fee', 'total', 'actual_delivery_cost', 'tracking', 'customer_notes', 'admin_notes'];
    const lines = [head.join(',')];
    for (const o of rows) lines.push([o.ref, o.created_at, o.status, o.customer_name, o.phone, o.wilaya_name, o.commune, o.address, o.delivery_method,
      (itemsBy.get(o.id) || []).map(i => `${i.name} [${[i.size, i.color].filter(Boolean).join('/')}] x${i.qty}`).join(' | '), o.subtotal, o.delivery_fee, o.total, o.actual_delivery_cost ?? '', o.tracking_number, o.customer_notes, o.admin_notes].map(csvCell).join(','));
    audit(ctx, 'orders.export', 'order', '', `${rows.length} rows`);
    return send(res, 200, '﻿' + lines.join('\r\n'), { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="orders-${new Date().toISOString().slice(0, 10)}.csv"`, 'Cache-Control': 'no-store' });
  }
  if (p === '/orders/bulk' && method === 'POST') {
    const b = await readJson(req); const ids = (Array.isArray(b.ids) ? b.ids : []).map(n => clampInt(n, 1, 1e9, 0)).filter(Boolean).slice(0, 200);
    if (!ids.length || !store.STATUSES.includes(b.status)) throw new HttpError(422, 'بيانات غير صالحة');
    if (b.status === 'cancelled' && !str(b.reason, 300)) throw new HttpError(422, 'سبب الإلغاء مطلوب');
    if (ids.length > 1) autoBackup('bulk-orders');
    let ok = 0, failed = [];
    for (const id of ids) { try { store.setOrderStatus(id, b.status, { reason: b.reason, adminId: ctx.session.adminId }); ok++; } catch (e) { failed.push({ id, error: e.message }); } }
    audit(ctx, 'orders.bulk_status', 'order', ids.join(','), b.status); return json(res, 200, { ok, failed });
  }
  if ((m = R(/^\/orders\/(\d+)$/))) {
    const id = +m[0];
    if (method === 'GET') {
      const o = d.prepare('SELECT * FROM orders WHERE id=?').get(id); if (!o) throw new HttpError(404, 'الطلب غير موجود');
      delete o.token_hash; o.items = d.prepare('SELECT * FROM order_items WHERE order_id=?').all(id); o.events = d.prepare('SELECT e.*, a.username FROM order_events e LEFT JOIN admins a ON a.id=e.admin_id WHERE order_id=? ORDER BY e.id').all(id);
      return json(res, 200, o);
    }
    if (method === 'PATCH') {
      const b = await readJson(req); const o = d.prepare('SELECT * FROM orders WHERE id=?').get(id); if (!o) throw new HttpError(404, 'الطلب غير موجود');
      if (b.status !== undefined && b.status !== o.status) {
        if (b.status === 'cancelled' && !str(b.cancel_reason, 300)) throw new HttpError(422, 'سبب الإلغاء مطلوب');
        store.setOrderStatus(id, b.status, { reason: b.cancel_reason, adminId: ctx.session.adminId });
      }
      const sets = [], args = [];
      const add = (col, val) => { sets.push(`${col}=?`); args.push(val); };
      if (b.admin_notes !== undefined) add('admin_notes', str(b.admin_notes, 2000));
      if (b.tracking_number !== undefined) add('tracking_number', str(b.tracking_number, 60));
      if (b.actual_delivery_cost !== undefined) add('actual_delivery_cost', b.actual_delivery_cost === null || b.actual_delivery_cost === '' ? null : clampInt(b.actual_delivery_cost, 0, 10_000_000, 0));
      if (b.customer_name !== undefined) { const n = str(b.customer_name, 80); if (n.length < 3) throw new HttpError(422, 'اسم غير صالح'); add('customer_name', n); }
      if (b.phone !== undefined) { const ph = normalizePhone(b.phone); if (!ph) throw new HttpError(422, 'هاتف غير صالح'); add('phone', ph); }
      if (b.commune !== undefined) add('commune', str(b.commune, 80));
      if (b.address !== undefined) add('address', str(b.address, 250));
      if (sets.length) { d.prepare(`UPDATE orders SET ${sets.join(',')}, updated_at=datetime('now') WHERE id=?`).run(...args, id); d.prepare('INSERT INTO order_events(order_id,admin_id,event,detail) VALUES (?,?,?,?)').run(id, ctx.session.adminId, 'edit', 'تعديل بيانات'); }
      audit(ctx, 'order.update', 'order', id, o.ref); return json(res, 200, { ok: true });
    }
  }

  /* ----- products ----- */
  if (p === '/products' && method === 'GET') {
    const st = url.searchParams.get('status') || ''; const q = str(url.searchParams.get('q'), 60);
    const where = [], args = []; if (['draft', 'published', 'archived'].includes(st)) { where.push('p.status=?'); args.push(st); } else where.push("p.status != 'archived'");
    if (q) { where.push("p.name LIKE ? ESCAPE '\\'"); args.push('%' + q.replace(/[\\%_]/g, '\\$&') + '%'); }
    const rows = d.prepare(`SELECT p.*, c.name category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE ${where.join(' AND ')} ORDER BY p.id DESC LIMIT 500`).all(...args);
    return json(res, 200, { items: store.decorate(rows).map(r => ({ id: r.id, slug: r.slug, name: r.name, price: r.price, sale_price: r.sale_price, status: r.status, featured: r.featured, is_new: r.is_new, category_name: r.category_name, stock: r.stock, image: r.images[0] ? (r.images[0].thumb || r.images[0].file) : '', variants: r.variants.length })) });
  }
  if (p === '/products' && method === 'POST') { const b = await readJson(req); const id = saveProduct(ctx, 0, b); return json(res, 201, productFull(id)); }
  if (p === '/products/bulk' && method === 'POST') {
    const b = await readJson(req); const ids = (Array.isArray(b.ids) ? b.ids : []).map(n => clampInt(n, 1, 1e9, 0)).filter(Boolean).slice(0, 200);
    if (!ids.length || !['publish', 'hide', 'archive', 'delete'].includes(b.action)) throw new HttpError(422, 'بيانات غير صالحة');
    if (b.action === 'delete') needConfirm(ctx);
    autoBackup('bulk-products');
    db.tx(() => { for (const id of ids) {
      if (b.action === 'delete') d.prepare('DELETE FROM products WHERE id=?').run(id);
      else if (b.action === 'publish') { const pr = d.prepare('SELECT price FROM products WHERE id=?').get(id); const nv = d.prepare('SELECT COUNT(*) n FROM product_variants WHERE product_id=?').get(id).n; if (pr && pr.price > 0 && nv) d.prepare("UPDATE products SET status='published', updated_at=datetime('now') WHERE id=?").run(id); }
      else d.prepare("UPDATE products SET status=?, updated_at=datetime('now') WHERE id=?").run(b.action === 'hide' ? 'draft' : 'archived', id);
    } });
    audit(ctx, 'products.bulk_' + b.action, 'product', ids.join(',')); return json(res, 200, { ok: true });
  }
  if ((m = R(/^\/products\/(\d+)$/))) {
    const id = +m[0];
    if (method === 'GET') { const pr = productFull(id); if (!pr) throw new HttpError(404, 'غير موجود'); return json(res, 200, pr); }
    if (method === 'PUT') { const b = await readJson(req); saveProduct(ctx, id, b); return json(res, 200, productFull(id)); }
    if (method === 'DELETE') {
      needConfirm(ctx); autoBackup('delete-product'); const pr = d.prepare('SELECT name FROM products WHERE id=?').get(id);
      d.prepare('DELETE FROM products WHERE id=?').run(id); audit(ctx, 'product.delete', 'product', id, pr && pr.name); return json(res, 200, { ok: true });
    }
  }
  if ((m = R(/^\/products\/(\d+)\/stock$/)) && method === 'PATCH') {   // quick stock edit
    const b = await readJson(req); const v = d.prepare('UPDATE product_variants SET stock=? WHERE id=? AND product_id=?').run(clampInt(b.stock, 0, 1e6, 0), clampInt(b.variant_id, 1, 1e9, 0), +m[0]);
    audit(ctx, 'stock.update', 'product', m[0], `variant ${b.variant_id} = ${b.stock}`); return json(res, 200, { ok: v.changes === 1 });
  }

  /* ----- taxonomy: categories, sizes, colors ----- */
  if ((m = R(/^\/(categories|sizes|colors)$/))) {
    const t = m[0];
    if (method === 'GET') return json(res, 200, { items: d.prepare(`SELECT * FROM ${t} ORDER BY sort,id`).all() });
    if (method === 'POST') {
      const b = await readJson(req); const name = str(b.name, 60); if (!name) throw new HttpError(422, 'الاسم مطلوب');
      const sort = d.prepare(`SELECT COALESCE(MAX(sort),0)+1 n FROM ${t}`).get().n;
      try {
        const r = t === 'categories' ? d.prepare('INSERT INTO categories(slug,name,sort) VALUES (?,?,?)').run(uniqueSlug('categories', b.slug || name), name, sort)
          : t === 'sizes' ? d.prepare('INSERT INTO sizes(name,sort) VALUES (?,?)').run(name, sort)
            : d.prepare('INSERT INTO colors(name,hex,sort) VALUES (?,?,?)').run(name, safeHex(b.hex, '#000000'), sort);
        audit(ctx, t + '.create', t, r.lastInsertRowid, name); return json(res, 201, { id: Number(r.lastInsertRowid) });
      } catch (e) { if (/UNIQUE/.test(e.message)) throw new HttpError(409, 'الاسم موجود مسبقاً'); throw e; }
    }
  }
  if ((m = R(/^\/(categories|sizes|colors)\/order$/)) && method === 'PUT') {
    const b = await readJson(req); (Array.isArray(b.ids) ? b.ids : []).forEach((id, i) => d.prepare(`UPDATE ${m[0]} SET sort=? WHERE id=?`).run(i, clampInt(id, 1, 1e9, 0))); return json(res, 200, { ok: true });
  }
  if ((m = R(/^\/(categories|sizes|colors)\/(\d+)$/))) {
    const [t, id] = [m[0], +m[1]];
    if (method === 'PUT') {
      const b = await readJson(req); const name = str(b.name, 60); if (!name) throw new HttpError(422, 'الاسم مطلوب');
      try {
        if (t === 'categories') d.prepare('UPDATE categories SET name=?, visible=? WHERE id=?').run(name, bool(b.visible) ? 1 : 0, id);
        else if (t === 'sizes') d.prepare('UPDATE sizes SET name=?, visible=? WHERE id=?').run(name, bool(b.visible) ? 1 : 0, id);
        else d.prepare('UPDATE colors SET name=?, hex=?, visible=? WHERE id=?').run(name, safeHex(b.hex, '#000000'), bool(b.visible) ? 1 : 0, id);
      } catch (e) { if (/UNIQUE/.test(e.message)) throw new HttpError(409, 'الاسم موجود مسبقاً'); throw e; }
      audit(ctx, t + '.update', t, id, name); return json(res, 200, { ok: true });
    }
    if (method === 'DELETE') { needConfirm(ctx); d.prepare(`DELETE FROM ${t} WHERE id=?`).run(id); audit(ctx, t + '.delete', t, id); return json(res, 200, { ok: true }); }
  }

  /* ----- delivery ----- */
  if (p === '/wilayas' && method === 'GET') return json(res, 200, { items: d.prepare('SELECT * FROM wilayas ORDER BY code').all() });
  if (p === '/wilayas' && method === 'PUT') {
    owner(ctx); const b = await readJson(req); const list = Array.isArray(b.items) ? b.items : [];
    autoBackup('wilayas');
    db.tx(() => { for (const w of list) { const code = clampInt(w.code, 1, 58, 0); if (!code) continue;
      d.prepare('UPDATE wilayas SET fee_home=?, fee_desk=?, enabled=? WHERE code=?').run(clampInt(w.fee_home, 0, 1e6, 0), clampInt(w.fee_desk, 0, 1e6, 0), bool(w.enabled) ? 1 : 0, code); } });
    audit(ctx, 'wilayas.update', 'wilaya', '', `${list.length} rows`); return json(res, 200, { ok: true });
  }

  /* ----- settings ----- */
  if (p === '/settings' && method === 'GET') { const o = {}; for (const g of Object.keys(SETTINGS_SCHEMA)) o[g] = store.S(g); return json(res, 200, o); }
  if ((m = R(/^\/settings\/(\w+)$/)) && method === 'PUT') {
    owner(ctx); const b = await readJson(req); const val = cleanGroup(m[0], b); store.setSetting(m[0], val); audit(ctx, 'settings.update', 'settings', m[0]); return json(res, 200, val);
  }

  /* ----- home sections ----- */
  if (p === '/sections' && method === 'GET') return json(res, 200, { items: d.prepare('SELECT * FROM home_sections ORDER BY sort,id').all().map(s => ({ ...s, data: JSON.parse(s.data) })), core: ['hero', 'marquee', 'story', 'manifesto', 'finale'] });
  if (p === '/sections' && method === 'POST') {
    owner(ctx); const b = await readJson(req); if (!['products', 'banner', 'richtext'].includes(b.type)) throw new HttpError(422, 'نوع غير مسموح');
    const data = cleanSection(b.type, {}, b.type === 'products' ? { source: 'new', limit: 6, heading: 'وصل حديثاً' } : {});
    const r = d.prepare('INSERT INTO home_sections(type,title,sort,data) VALUES (?,?,?,?)').run(b.type, str(b.title, 60) || b.type, d.prepare('SELECT COALESCE(MAX(sort),0)+1 n FROM home_sections').get().n, JSON.stringify(data));
    audit(ctx, 'section.create', 'section', r.lastInsertRowid, b.type); return json(res, 201, { id: Number(r.lastInsertRowid) });
  }
  if (p === '/sections/order' && method === 'PUT') {
    owner(ctx); const b = await readJson(req); (Array.isArray(b.ids) ? b.ids : []).forEach((id, i) => d.prepare('UPDATE home_sections SET sort=? WHERE id=?').run(i, clampInt(id, 1, 1e9, 0)));
    store.invalidate(); audit(ctx, 'sections.reorder'); return json(res, 200, { ok: true });
  }
  if ((m = R(/^\/sections\/(\d+)$/))) {
    owner(ctx); const id = +m[0]; const s = d.prepare('SELECT * FROM home_sections WHERE id=?').get(id); if (!s) throw new HttpError(404, 'غير موجود');
    if (method === 'PUT') {
      const b = await readJson(req); const data = cleanSection(s.type, b.data || {}, JSON.parse(s.data));
      d.prepare('UPDATE home_sections SET data=?, visible=?, title=? WHERE id=?').run(JSON.stringify(data), b.visible === undefined ? s.visible : (bool(b.visible) ? 1 : 0), b.title !== undefined ? str(b.title, 60) : s.title, id);
      store.invalidate(); audit(ctx, 'section.update', 'section', id, s.type); return json(res, 200, { ok: true });
    }
    if (method === 'DELETE') { needConfirm(ctx); if (!['products', 'banner', 'richtext'].includes(s.type)) throw new HttpError(400, 'لا يمكن حذف القسم الأساسي، يمكنك إخفاؤه'); d.prepare('DELETE FROM home_sections WHERE id=?').run(id); audit(ctx, 'section.delete', 'section', id); return json(res, 200, { ok: true }); }
  }

  /* ----- navigation ----- */
  if (p === '/nav' && method === 'GET') return json(res, 200, { items: d.prepare('SELECT * FROM nav_items ORDER BY location,sort,id').all() });
  if (p === '/nav' && method === 'PUT') {
    owner(ctx); const b = await readJson(req); const items = (Array.isArray(b.items) ? b.items : []).slice(0, 40);
    db.tx(() => { d.prepare('DELETE FROM nav_items').run(); items.forEach((n, i) => {
      const label = str(n.label, 40), u = str(n.url, 300); if (!label || !u || safeUrl(u, '') === '') throw new HttpError(422, 'عنصر قائمة غير صالح: ' + label);
      d.prepare('INSERT INTO nav_items(location,label,url,sort,visible) VALUES (?,?,?,?,?)').run(n.location === 'footer' ? 'footer' : 'header', label, u, i, bool(n.visible === undefined ? true : n.visible) ? 1 : 0); }); });
    store.invalidate(); audit(ctx, 'nav.update'); return json(res, 200, { ok: true });
  }

  /* ----- pages ----- */
  if (p === '/pages' && method === 'GET') return json(res, 200, { items: d.prepare('SELECT * FROM pages ORDER BY system DESC, id').all() });
  if (p === '/pages' && method === 'POST') {
    owner(ctx); const b = await readJson(req); const title = str(b.title, 120); if (!title) throw new HttpError(422, 'العنوان مطلوب');
    const slug = uniqueSlug('pages', b.slug || title); if (['admin', 'api'].includes(slug)) throw new HttpError(422, 'عنوان محجوز');
    const r = d.prepare('INSERT INTO pages(slug,title,content,published,seo_title,seo_description) VALUES (?,?,?,?,?,?)').run(slug, title, str(b.content, 20000), bool(b.published) ? 1 : 0, str(b.seo_title, 120), str(b.seo_description, 300));
    audit(ctx, 'page.create', 'page', r.lastInsertRowid, title); return json(res, 201, { id: Number(r.lastInsertRowid), slug });
  }
  if ((m = R(/^\/pages\/(\d+)$/))) {
    owner(ctx); const id = +m[0]; const pg = d.prepare('SELECT * FROM pages WHERE id=?').get(id); if (!pg) throw new HttpError(404, 'غير موجود');
    if (method === 'PUT') {
      const b = await readJson(req); const title = str(b.title, 120); if (!title) throw new HttpError(422, 'العنوان مطلوب');
      d.prepare("UPDATE pages SET title=?, content=?, published=?, seo_title=?, seo_description=?, updated_at=datetime('now') WHERE id=?").run(title, str(b.content, 20000), bool(b.published) ? 1 : 0, str(b.seo_title, 120), str(b.seo_description, 300), id);
      audit(ctx, 'page.update', 'page', id, title); return json(res, 200, { ok: true });
    }
    if (method === 'DELETE') { needConfirm(ctx); if (pg.system) throw new HttpError(400, 'صفحة أساسية — يمكنك إلغاء نشرها فقط'); d.prepare('DELETE FROM pages WHERE id=?').run(id); audit(ctx, 'page.delete', 'page', id); return json(res, 200, { ok: true }); }
  }

  /* ----- media ----- */
  if (p === '/media' && method === 'GET') return json(res, 200, { items: d.prepare('SELECT * FROM media ORDER BY id DESC LIMIT 300').all().map(x => ({ ...x, url: '/uploads/' + x.file, thumb_url: '/uploads/' + (x.thumb || x.file) })) });
  if (p === '/upload' && method === 'POST') {
    const lim = ctx.session && sec.rateLimit('upload:' + ctx.session.adminId, 120, 60 * 60 * 1000); if (!lim.ok) throw new HttpError(429, 'رفع كثير، حاول لاحقاً');
    const { files, fields } = await readMultipart(req, config.MAX_VIDEO_BYTES + 1024 * 1024);
    if (!files.length) throw new HttpError(400, 'لم يتم اختيار ملف');
    const out = []; for (const f of files.slice(0, 12)) out.push(await upload.saveUpload(f, { allowVideo: fields.allowVideo === '1' }));
    audit(ctx, 'media.upload', 'media', out.map(o => o.id).join(',')); return json(res, 201, { items: out });
  }
  if ((m = R(/^\/media\/(\d+)$/)) && method === 'DELETE') {
    needConfirm(ctx); const med = d.prepare('SELECT file FROM media WHERE id=?').get(+m[0]);
    if (med) { const u = '/uploads/' + med.file; const used = d.prepare('SELECT 1 FROM product_images WHERE file=? OR thumb=?').get(u, u) || d.prepare('SELECT 1 FROM home_sections WHERE data LIKE ?').get('%' + u + '%') || d.prepare('SELECT 1 FROM settings WHERE value LIKE ?').get('%' + u + '%');
      if (used) throw new HttpError(409, 'الملف مستخدم حالياً في الموقع، أزله منه أولاً'); }
    upload.deleteMedia(+m[0]); audit(ctx, 'media.delete', 'media', m[0]); return json(res, 200, { ok: true });
  }

  /* ----- audit + backups ----- */
  if (p === '/audit' && method === 'GET') { owner(ctx); return json(res, 200, { items: d.prepare('SELECT * FROM audit_log ORDER BY id DESC LIMIT 300').all() }); }
  if (p === '/backups' && method === 'GET') {
    owner(ctx); fs.mkdirSync(config.BACKUP_DIR, { recursive: true });
    return json(res, 200, { items: fs.readdirSync(config.BACKUP_DIR).filter(n => n.endsWith('.db')).sort().reverse().slice(0, 50).map(n => ({ name: n, size: fs.statSync(path.join(config.BACKUP_DIR, n)).size })) });
  }
  if (p === '/backups' && method === 'POST') { owner(ctx); const f = path.join(config.BACKUP_DIR, `manual-${db.stamp()}.db`); db.backupTo(f); audit(ctx, 'backup.create', 'backup', path.basename(f)); return json(res, 201, { name: path.basename(f) }); }
  if (p === '/backups/download' && method === 'POST') {
    owner(ctx); const b = await readJson(req); reauth(ctx, b.password);
    const tmp = path.join(config.BACKUP_DIR, `download-${db.stamp()}.db`); db.backupTo(tmp);
    const buf = fs.readFileSync(tmp); fs.unlinkSync(tmp);
    audit(ctx, 'backup.download'); return send(res, 200, buf, { 'Content-Type': 'application/octet-stream', 'Content-Disposition': 'attachment; filename="store-backup.db"', 'Cache-Control': 'no-store' });
  }

  throw new HttpError(404, 'غير موجود');
}

/* ---------------- login ---------------- */
function cookieAttrs(req, maxAge) { return `Path=/; HttpOnly; SameSite=Strict${config.SECURE_COOKIES || isHttps(req) ? '; Secure' : ''}${maxAge !== undefined ? `; Max-Age=${maxAge}` : ''}`; }
const clearCookie = (req) => `${COOKIE}=; ${cookieAttrs(req, 0)}`;

async function login(ctx) {
  const { req, res, ip } = ctx; const b = await readJson(req);
  const username = str(b.username, 60), password = typeof b.password === 'string' ? b.password.slice(0, 300) : '';
  const k1 = 'login:ip:' + ip, k2 = 'login:user:' + username.toLowerCase();
  if (!sec.rateCheck(k1, 10) || !sec.rateCheck(k2, 5)) throw new HttpError(429, 'محاولات كثيرة. حاول بعد 15 دقيقة.');
  const a = db.get().prepare('SELECT * FROM admins WHERE username=? AND active=1').get(username);
  let ok = false;
  if (a) ok = sec.verifyPassword(password, a.password_hash); else sec.dummyVerify(password);
  if (ok && a.totp_enabled && !sec.totpVerify(a.totp_secret, b.totp)) {
    if (!b.totp) return json(res, 200, { need_totp: true });
    ok = false;
  }
  if (!ok) {
    sec.rateLimit(k1, 10, 15 * 60 * 1000); sec.rateLimit(k2, 5, 15 * 60 * 1000);
    ctx.session = null; db.get().prepare('INSERT INTO audit_log(admin_name,action,ip) VALUES (?,?,?)').run(username.slice(0, 40), 'login.failed', ip);
    throw new HttpError(401, 'بيانات الدخول غير صحيحة');
  }
  sec.rateReset(k2);
  sec.purgeSessions();
  const s = sec.createSession(a.id, ip);
  db.get().prepare("UPDATE admins SET last_login_at=datetime('now') WHERE id=?").run(a.id);
  ctx.session = { adminId: a.id, username: a.username }; audit(ctx, 'login');
  return json(res, 200, { ok: true, csrf: s.csrf, username: a.username, role: a.role }, { 'Set-Cookie': `${COOKIE}=${s.id}; ${cookieAttrs(req, Math.floor(config.SESSION_MAX_MS / 1000))}` });
}

module.exports = { handle, audit, autoBackup, cleanGroup, cleanSection, cookieName };
