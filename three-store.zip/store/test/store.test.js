'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { startApp, client, createAdmin, PNG, multipart } = require('./helpers');

const PW = 'Str0ng!Passw0rd#1';
let ctx, admin, anon, db, sec, store;
const money = (n) => n;

async function jpost(c, p, body, opts = {}) { return c.req('POST', p, { body, ...opts }); }
async function mkProduct(over = {}) {
  const r = await admin.req('POST', '/api/admin/products', { body: { name: 'هودي اختبار', price: 3500, status: 'published', category_id: 1, description: 'وصف', featured: true, is_new: true, variants: [{ size: 'M', color: 'أسود', stock: 5 }, { size: 'L', color: 'أسود', stock: 2 }, { size: 'L', color: 'أبيض', stock: 0 }], images: [], ...over } });
  assert.equal(r.status, 201, r.text); return r.json;
}
const customer = (o = {}) => ({ name: 'محمد بن علي', phone: '0555123456', wilaya: 16, commune: 'باب الزوار', address: 'حي 5 جويلية رقم 12', method: 'home', notes: '', ...o });

test.beforeEach(() => { try { require('../src/security').resetAllBuckets(); } catch {} });
test.before(async () => {
  ctx = await startApp();
  db = require('../src/db'); sec = require('../src/security'); store = require('../src/store');
  anon = client(ctx.base); admin = client(ctx.base);
});
test.after(async () => { await new Promise(r => ctx.server.close(r)); db.close(); });

/* ---------------- startup, DB, admin creation ---------------- */
test('startup: health, schema, 58 wilayas, idempotent migrations', async () => {
  const r = await anon.req('GET', '/health'); assert.equal(r.status, 200); assert.equal(r.json.ok, true);
  const n = db.get().prepare('SELECT COUNT(*) n FROM wilayas').get().n; assert.equal(n, 58);
  for (const t of ['admins', 'products', 'product_variants', 'orders', 'order_items', 'audit_log', 'settings', 'wilayas', 'categories', 'sizes', 'colors', 'pages', 'home_sections', 'media']) assert.ok(db.get().prepare('SELECT 1 FROM sqlite_master WHERE name=?').get(t), t);
  assert.deepEqual(db.migrate(), []);          // re-running applies nothing
  db.seed(); assert.equal(db.get().prepare('SELECT COUNT(*) n FROM wilayas').get().n, 58); // seed never duplicates
  assert.equal(db.get().prepare('PRAGMA foreign_keys').get().foreign_keys, 1);
});
test('no default admin exists and public admin registration is impossible', async () => {
  assert.equal(db.get().prepare('SELECT COUNT(*) n FROM admins').get().n, 0);
  assert.equal((await anon.req('POST', '/api/admin/admins', { body: { username: 'evil', password: PW } })).status, 401);
  assert.equal((await anon.req('POST', '/api/admin/register', { body: {} })).status, 401);
});
test('create-admin script: rejects weak password, creates owner, rejects duplicate', () => {
  let r = createAdmin(ctx.dir, 'owner', 'weak'); assert.notEqual(r.status, 0); assert.match(r.stderr, /Weak password/);
  r = createAdmin(ctx.dir, 'owner', PW); assert.equal(r.status, 0, r.stderr);
  r = createAdmin(ctx.dir, 'owner', PW); assert.notEqual(r.status, 0);
  const row = db.get().prepare('SELECT password_hash, role FROM admins WHERE username=?').get('owner');
  assert.equal(row.role, 'owner'); assert.ok(row.password_hash.startsWith('scrypt$')); assert.ok(!row.password_hash.includes(PW));
});

/* ---------------- auth ---------------- */
test('unauthorized dashboard/API access is refused', async () => {
  for (const p of ['/api/admin/dashboard', '/api/admin/orders', '/api/admin/orders.csv', '/api/admin/products', '/api/admin/settings', '/api/admin/backups', '/api/admin/audit']) assert.equal((await anon.req('GET', p)).status, 401, p);
  assert.equal((await anon.req('PUT', '/api/admin/settings/store', { body: { name: 'hacked' } })).status, 401);
  assert.equal(store.S('store').name, 'THREE');
});
test('login: wrong password fails, rate-limit locks out, cookie flags, logout invalidates session', async () => {
  sec.resetAllBuckets();
  let r = await anon.req('POST', '/api/admin/login', { body: { username: 'owner', password: 'nope' }, auth: false }); assert.equal(r.status, 401);
  r = await anon.req('POST', '/api/admin/login', { body: { username: 'ghost', password: 'nope' }, auth: false }); assert.equal(r.status, 401);
  for (let i = 0; i < 5; i++) await anon.req('POST', '/api/admin/login', { body: { username: 'victim', password: 'x' + i }, auth: false });
  r = await anon.req('POST', '/api/admin/login', { body: { username: 'victim', password: 'x' }, auth: false }); assert.equal(r.status, 429);
  sec.resetAllBuckets();
  r = await admin.login('owner', PW); assert.equal(r.status, 200);
  const sc = r.headers.get('set-cookie'); assert.match(sc, /HttpOnly/); assert.match(sc, /SameSite=Strict/);
  const me = await admin.req('GET', '/api/admin/me'); assert.equal(me.json.username, 'owner'); assert.equal(me.json.role, 'owner');
  const old = admin.cookie; assert.equal((await admin.req('POST', '/api/admin/logout', { body: {} })).status, 200);
  const stale = client(ctx.base); stale.cookie = old; assert.equal((await stale.req('GET', '/api/admin/me')).status, 401);
  await admin.login('owner', PW);
});
test('CSRF token and same-origin are enforced on admin writes', async () => {
  let r = await admin.req('PUT', '/api/admin/settings/status', { body: { open: true }, headers: { 'X-CSRF-Token': 'wrong' } }); assert.equal(r.status, 403);
  r = await admin.req('PUT', '/api/admin/settings/status', { body: { open: true }, headers: { Origin: 'https://evil.example' } }); assert.equal(r.status, 403);
  r = await admin.req('PUT', '/api/admin/settings/status', { body: { open: true } }); assert.equal(r.status, 200);
});
test('TOTP implementation matches RFC 6238 vector', () => {
  assert.equal(sec.totpAt('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ', 59000), '287082');
});
test('password change requires current password and ends other sessions', async () => {
  const other = client(ctx.base); await other.login('owner', PW);
  let r = await admin.req('POST', '/api/admin/password', { body: { current: 'wrong', new: 'An0ther!StrongPw' } }); assert.equal(r.status, 403);
  r = await admin.req('POST', '/api/admin/password', { body: { current: PW, new: 'short' } }); assert.equal(r.status, 422);
  r = await admin.req('POST', '/api/admin/password', { body: { current: PW, new: 'An0ther!StrongPw' } }); assert.equal(r.status, 200);
  assert.equal((await other.req('GET', '/api/admin/me')).status, 401);
  assert.equal((await admin.req('GET', '/api/admin/me')).status, 200);
  r = await admin.req('POST', '/api/admin/password', { body: { current: 'An0ther!StrongPw', new: PW } }); assert.equal(r.status, 200);
});

/* ---------------- products, uploads, search ---------------- */
test('product CRUD + validation + publish rules', async () => {
  let r = await admin.req('POST', '/api/admin/products', { body: { name: 'x', price: 100, status: 'draft' } }); assert.equal(r.status, 422);
  r = await admin.req('POST', '/api/admin/products', { body: { name: 'منتج بلا سعر', price: 0, status: 'published', variants: [{ size: 'M', color: '', stock: 1 }] } }); assert.equal(r.status, 422);
  r = await admin.req('POST', '/api/admin/products', { body: { name: 'منتج بلا مخزون', price: 100, status: 'published', variants: [] } }); assert.equal(r.status, 422);
  r = await admin.req('POST', '/api/admin/products', { body: { name: 'تخفيض خاطئ', price: 100, sale_price: 200, status: 'draft' } }); assert.equal(r.status, 422);
  r = await admin.req('POST', '/api/admin/products', { body: { name: 'مكرر', price: 100, status: 'draft', variants: [{ size: 'M', color: 'a', stock: 1 }, { size: 'M', color: 'a', stock: 2 }] } }); assert.equal(r.status, 422);
  const p = await mkProduct(); assert.ok(p.id); assert.equal(p.variants.length, 3);
  const e = await admin.req('PUT', `/api/admin/products/${p.id}`, { body: { ...p, price: 4000, sale_price: 3200, id: 9999, slug: p.slug, variants: p.variants.map(v => ({ size: v.size, color: v.color, stock: v.stock })), images: [] } });
  assert.equal(e.status, 200); assert.equal(e.json.price, 4000); assert.equal(e.json.id, p.id);   // mass-assigned id ignored
  assert.equal(e.json.final_price, 3200);
  const pub = await anon.req('GET', `/product/${p.slug}`); assert.equal(pub.status, 200); assert.match(pub.text, /3\s?200/); assert.match(pub.text, /application\/ld\+json/);
});
test('draft/archived products are not publicly visible', async () => {
  const p = await mkProduct({ name: 'مخفي', status: 'draft' });
  assert.equal((await anon.req('GET', `/product/${p.slug}`)).status, 404);
  const q = await anon.req('POST', '/api/cart/quote', { body: { items: [{ variantId: p.variants[0].id, qty: 1 }] } });
  assert.equal(q.json.lines.length, 0); assert.equal(q.json.problems[0].code, 'unavailable');
  assert.ok(!(await anon.req('GET', '/sitemap.xml')).text.includes(p.slug));
});
test('image upload: accepts real images, rejects fakes, svg, html, oversize; traversal blocked', async () => {
  const send = async (files, fields) => { const m = multipart(files, fields); return admin.req('POST', '/api/admin/upload', { form: m.body, headers: { 'Content-Type': m.contentType } }); };
  let r = await send([{ name: 'a.png', data: PNG, type: 'image/png' }]); assert.equal(r.status, 201, r.text);
  const url = r.json.items[0].url; assert.match(url, /^\/uploads\/[0-9a-f]{24}\.(png|webp)$/);
  const got = await anon.req('GET', url); assert.equal(got.status, 200); assert.equal(got.headers.get('content-type'), url.endsWith('png') ? 'image/png' : 'image/webp');
  assert.equal((await send([{ name: 'evil.png', data: Buffer.from('<?php echo 1; ?> not an image at all'), type: 'image/png' }])).status, 400);
  assert.equal((await send([{ name: 'x.svg', data: Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'), type: 'image/svg+xml' }])).status, 400);
  assert.equal((await send([{ name: 'x.html', data: Buffer.from('<html><script>alert(1)</script></html>'), type: 'text/html' }])).status, 400);
  assert.equal((await send([{ name: 'big.png', data: Buffer.concat([PNG, Buffer.alloc(9 * 1024 * 1024)]), type: 'image/png' }])).status, 413);
  assert.equal((await send([{ name: 'v.mp4', data: Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypmp42'), Buffer.alloc(40)]) }])).status, 400, 'video not allowed unless allowVideo');
  assert.equal((await send([{ name: 'v.mp4', data: Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypmp42'), Buffer.alloc(40)]) }], { allowVideo: '1' })).status, 201);
  assert.equal((await anon.req('POST', '/api/admin/upload', { form: multipart([{ name: 'a.png', data: PNG }]).body, headers: { 'Content-Type': multipart([]).contentType } })).status, 401);
  for (const bad of ['/uploads/../store.db', '/uploads/%2e%2e/store.db', '/uploads/..%2fstore.db', '/uploads/.hidden', '/css/../../package.json', '/assets/%2e%2e/%2e%2e/server.js']) assert.equal((await anon.req('GET', bad)).status, 404, bad);
  assert.equal((await anon.req('GET', '/store.db')).status, 404); assert.equal((await anon.req('GET', '/.env')).status, 404); assert.equal((await anon.req('GET', '/server.js')).status, 404);
  const prod = await mkProduct({ name: 'بصورة', images: [{ file: url, thumb: url, alt: 'صورة' }] }); assert.equal(prod.images.length, 1);
  assert.equal((await admin.req('POST', '/api/admin/products', { body: { name: 'صورة سيئة', price: 10, status: 'draft', images: [{ file: 'https://evil.example/x.png' }] } })).status, 422);
});
test('search, filters, sorting, pagination run on real data', async () => {
  const cat = db.get().prepare("SELECT id FROM categories WHERE slug='caps'").get().id;
  await mkProduct({ name: 'قبعة حمراء فريدة', price: 1500, category_id: cat, tags: 'صيف', is_new: false, featured: false, variants: [{ size: 'مقاس موحّد', color: 'أحمر', stock: 3 }] });
  await mkProduct({ name: 'تيشيرت غالي', price: 9000, variants: [{ size: 'XL', color: 'أبيض', stock: 1 }] });
  const names = (html) => [...html.matchAll(/<h3><a href="\/product\/[^"]+">([^<]+)<\/a>/g)].map(m => m[1]);
  let r = await anon.req('GET', '/shop?q=' + encodeURIComponent('فريدة')); assert.deepEqual(names(r.text), ['قبعة حمراء فريدة']);
  r = await anon.req('GET', '/shop?category=caps'); assert.deepEqual(names(r.text), ['قبعة حمراء فريدة']);
  r = await anon.req('GET', '/shop?size=XL'); assert.ok(names(r.text).includes('تيشيرت غالي')); assert.ok(!names(r.text).includes('قبعة حمراء فريدة'));
  r = await anon.req('GET', '/shop?color=' + encodeURIComponent('أحمر')); assert.deepEqual(names(r.text), ['قبعة حمراء فريدة']);
  r = await anon.req('GET', '/shop?min=5000'); assert.deepEqual(names(r.text), ['تيشيرت غالي']);
  r = await anon.req('GET', '/shop?max=2000'); assert.deepEqual(names(r.text), ['قبعة حمراء فريدة']);
  r = await anon.req('GET', '/shop?sort=price_desc'); assert.equal(names(r.text)[0], 'تيشيرت غالي');
  r = await anon.req('GET', '/shop?sort=price_asc'); assert.equal(names(r.text)[0], 'قبعة حمراء فريدة');
  r = await anon.req('GET', '/shop?q=zzzzzz'); assert.match(r.text, /لا توجد منتجات مطابقة/);
  r = await anon.req('GET', '/shop?q=' + encodeURIComponent("' OR 1=1 --")); assert.equal(r.status, 200); assert.match(r.text, /لا توجد منتجات مطابقة/);
  r = await anon.req('GET', '/shop?q=' + encodeURIComponent('%')); assert.match(r.text, /لا توجد منتجات مطابقة/, 'LIKE wildcards are escaped');
  r = await anon.req('GET', '/shop?q=' + encodeURIComponent('"><script>alert(1)</script>')); assert.ok(!r.text.includes('<script>alert(1)'));
  r = await anon.req('GET', '/shop?page=999&sort=drop'); assert.equal(r.status, 200);
});

/* ---------------- cart, checkout, orders ---------------- */
test('cart quote: server computes prices, ignores client prices, caps to stock', async () => {
  const p = await mkProduct({ name: 'سلة', price: 2000, variants: [{ size: 'M', color: '', stock: 3 }] });
  const vid = p.variants[0].id;
  let r = await anon.req('POST', '/api/cart/quote', { body: { items: [{ variantId: vid, qty: 2, price: 1, unit_price: 1 }], wilaya: 16, method: 'home' } });
  assert.equal(r.status, 200); assert.equal(r.json.subtotal, 4000); const fee = db.get().prepare('SELECT fee_home FROM wilayas WHERE code=16').get().fee_home;
  assert.equal(r.json.delivery_fee, fee); assert.equal(r.json.total, 4000 + fee);
  r = await anon.req('POST', '/api/cart/quote', { body: { items: [{ variantId: vid, qty: 50 }] } }); assert.equal(r.json.lines[0].qty, 3); assert.equal(r.json.problems[0].code, 'reduced');
  r = await anon.req('POST', '/api/cart/quote', { body: { items: [{ variantId: vid, qty: -4 }, { variantId: 'x', qty: 1 }] } }); assert.equal(r.json.lines.length, 0);
  assert.equal((await anon.req('POST', '/api/cart/quote', { body: { items: 'nope' } })).status, 400);
  assert.equal((await anon.req('POST', '/api/cart/quote', { body: { items: [{ variantId: vid, qty: 1 }], wilaya: 99, method: 'home' } })).status, 400);
});
test('order creation: validation, forged totals ignored, stock deducted in a transaction, snapshot kept', async () => {
  const p = await mkProduct({ name: 'للطلب', price: 5000, variants: [{ size: 'M', color: 'أسود', stock: 4 }] }); const v = p.variants[0];
  const bad = [{ phone: '123' }, { phone: '0455' }, { name: '' }, { name: 'ab' }, { wilaya: 0 }, { wilaya: 59 }, { commune: '' }, { address: 'x' }, { method: 'drone' }];
  for (const b of bad) { const r = await anon.req('POST', '/api/orders', { body: { ...customer(b), items: [{ variantId: v.id, qty: 1 }] } }); assert.equal(r.status, 422, JSON.stringify(b)); }
  assert.equal(db.get().prepare('SELECT stock FROM product_variants WHERE id=?').get(v.id).stock, 4, 'failed validation must not touch stock');
  assert.equal((await anon.req('POST', '/api/orders', { body: { ...customer(), items: [] } })).status, 409);
  const key = 'k'.repeat(8) + '-idem-0001-test';
  const r = await anon.req('POST', '/api/orders', { headers: { 'Idempotency-Key': key }, body: { ...customer({ phone: '+213 555 12 34 56' }), total: 1, subtotal: 1, delivery_fee: 0, price: 1, items: [{ variantId: v.id, qty: 2, price: 1 }] } });
  assert.equal(r.status, 201, r.text); assert.match(r.json.ref, /^T3-\d{6}-[A-Z2-9]{5}$/);
  const o = db.get().prepare('SELECT * FROM orders WHERE ref=?').get(r.json.ref); const fee = db.get().prepare('SELECT fee_home FROM wilayas WHERE code=16').get().fee_home;
  assert.equal(o.subtotal, 10000); assert.equal(o.delivery_fee, fee); assert.equal(o.total, 10000 + fee); assert.equal(o.phone, '0555123456'); assert.equal(o.status, 'new'); assert.equal(o.wilaya_name, 'الجزائر');
  assert.equal(db.get().prepare('SELECT stock FROM product_variants WHERE id=?').get(v.id).stock, 2);
  const items = db.get().prepare('SELECT * FROM order_items WHERE order_id=?').all(o.id); assert.equal(items.length, 1); assert.equal(items[0].unit_price, 5000); assert.equal(items[0].name, 'للطلب');
  // duplicate submission with the same key returns the same order and does not deduct again
  const d = await anon.req('POST', '/api/orders', { headers: { 'Idempotency-Key': key }, body: { ...customer(), items: [{ variantId: v.id, qty: 2 }] } });
  assert.equal(d.status, 200); assert.equal(d.json.ref, r.json.ref); assert.equal(db.get().prepare('SELECT stock FROM product_variants WHERE id=?').get(v.id).stock, 2);
  assert.equal(db.get().prepare('SELECT COUNT(*) n FROM orders WHERE idem_key=?').get(key).n, 1);
  // snapshot survives later price change / hiding
  await admin.req('PUT', `/api/admin/products/${p.id}`, { body: { ...p, price: 9999, status: 'archived', variants: [{ size: 'M', color: 'أسود', stock: 2 }], images: [] } });
  assert.equal(db.get().prepare('SELECT unit_price FROM order_items WHERE order_id=?').get(o.id).unit_price, 5000);
});
test('overselling is impossible: second order exceeding stock is rejected with no partial effects', async () => {
  const p = await mkProduct({ name: 'محدود', price: 1000, variants: [{ size: 'M', color: '', stock: 1 }] }); const vid = p.variants[0].id;
  const a = await anon.req('POST', '/api/orders', { body: { ...customer(), items: [{ variantId: vid, qty: 1 }] } }); assert.equal(a.status, 201);
  const before = db.get().prepare('SELECT COUNT(*) n FROM orders').get().n;
  const b = await anon.req('POST', '/api/orders', { body: { ...customer(), items: [{ variantId: vid, qty: 1 }] } }); assert.equal(b.status, 409); assert.equal(b.json.stale, true);
  assert.equal(db.get().prepare('SELECT COUNT(*) n FROM orders').get().n, before); assert.equal(db.get().prepare('SELECT stock FROM product_variants WHERE id=?').get(vid).stock, 0);
  const p2 = await mkProduct({ name: 'اثنان', price: 1000, variants: [{ size: 'M', color: '', stock: 5 }, { size: 'L', color: '', stock: 0 }] });
  const c = await anon.req('POST', '/api/orders', { body: { ...customer(), items: [{ variantId: p2.variants[0].id, qty: 2 }, { variantId: p2.variants[1].id, qty: 1 }] } }); assert.equal(c.status, 409);
  assert.equal(db.get().prepare('SELECT stock FROM product_variants WHERE id=?').get(p2.variants[0].id).stock, 5, 'transaction rolled back');
  // concurrent orders for the last unit: exactly one wins
  const p3 = await mkProduct({ name: 'تزامن', price: 1000, variants: [{ size: 'M', color: '', stock: 1 }] });
  const rs = await Promise.all([1, 2, 3, 4].map(() => anon.req('POST', '/api/orders', { body: { ...customer(), items: [{ variantId: p3.variants[0].id, qty: 1 }] } })));
  assert.equal(rs.filter(r => r.status === 201).length, 1); assert.equal(db.get().prepare('SELECT stock FROM product_variants WHERE id=?').get(p3.variants[0].id).stock, 0);
});
test('delivery fees: by wilaya + method, free threshold, disabled wilaya/method', async () => {
  const p = await mkProduct({ name: 'توصيل', price: 3000, variants: [{ size: 'M', color: '', stock: 50 }] }); const vid = p.variants[0].id;
  assert.equal((await admin.req('PUT', '/api/admin/wilayas', { body: { items: [{ code: 31, fee_home: 700, fee_desk: 450, enabled: true }, { code: 11, fee_home: 1500, fee_desk: 1300, enabled: false }] } })).status, 200);
  let q = await anon.req('POST', '/api/cart/quote', { body: { items: [{ variantId: vid, qty: 1 }], wilaya: 31, method: 'home' } }); assert.equal(q.json.delivery_fee, 700);
  q = await anon.req('POST', '/api/cart/quote', { body: { items: [{ variantId: vid, qty: 1 }], wilaya: 31, method: 'desk' } }); assert.equal(q.json.delivery_fee, 450);
  assert.equal((await anon.req('POST', '/api/cart/quote', { body: { items: [{ variantId: vid, qty: 1 }], wilaya: 11, method: 'home' } })).status, 400);
  assert.equal((await admin.req('PUT', '/api/admin/settings/delivery', { body: { free_threshold: 5000 } })).status, 200);
  q = await anon.req('POST', '/api/cart/quote', { body: { items: [{ variantId: vid, qty: 2 }], wilaya: 31, method: 'home' } }); assert.equal(q.json.delivery_fee, 0); assert.equal(q.json.free_delivery, true);
  q = await anon.req('POST', '/api/cart/quote', { body: { items: [{ variantId: vid, qty: 1 }], wilaya: 31, method: 'home' } }); assert.equal(q.json.delivery_fee, 700);
  await admin.req('PUT', '/api/admin/settings/delivery', { body: { free_threshold: 0, desk_enabled: false } });
  assert.equal((await anon.req('POST', '/api/cart/quote', { body: { items: [{ variantId: vid, qty: 1 }], wilaya: 31, method: 'desk' } })).status, 400);
  await admin.req('PUT', '/api/admin/settings/delivery', { body: { desk_enabled: true } });
  await admin.req('PUT', '/api/admin/wilayas', { body: { items: [{ code: 11, fee_home: 1500, fee_desk: 1300, enabled: true }] } });
});
test('order confirmation page is private (token required) and escapes customer input', async () => {
  const p = await mkProduct({ name: 'خصوصية', price: 1000, variants: [{ size: 'M', color: '', stock: 9 }] }); const vid = p.variants[0].id;
  const evil = '<img src=x onerror=alert(1)>';
  const r1 = await anon.req('POST', '/api/orders', { body: { ...customer({ name: 'علي ' + evil, address: 'عنوان ' + evil + ' طويل' }), items: [{ variantId: vid, qty: 1 }] } }); assert.equal(r1.status, 201);
  const r2 = await anon.req('POST', '/api/orders', { body: { ...customer({ name: 'زبون ثاني' }), items: [{ variantId: vid, qty: 1 }] } });
  const ok = await anon.req('GET', r1.json.url); assert.equal(ok.status, 200); assert.ok(ok.text.includes(r1.json.ref)); assert.ok(!ok.text.includes(evil)); assert.ok(ok.text.includes('&lt;img'));
  assert.equal((await anon.req('GET', `/order/${r1.json.ref}`)).status, 404);
  assert.equal((await anon.req('GET', `/order/${r1.json.ref}?t=bad`)).status, 404);
  assert.equal((await anon.req('GET', `/order/${r1.json.ref}?t=${r2.json.token}`)).status, 404, 'another order token must not open this order');
  assert.equal((await anon.req('GET', `/order/T3-000000-AAAAA?t=${r1.json.token}`)).status, 404);
  assert.match(ok.headers.get('cache-control'), /no-store/); assert.match(ok.text, /noindex/);
  assert.equal((await anon.req('GET', '/api/admin/orders/1')).status, 401); assert.equal((await anon.req('GET', '/api/orders')).status, 404);
  assert.ok(!ok.text.includes('admin_notes'));
});
test('order management: status flow, cancel reason, stock restore/retake, notes, filters, CSV (injection-safe)', async () => {
  const p = await mkProduct({ name: 'إدارة', price: 1000, variants: [{ size: 'M', color: '', stock: 3 }] }); const vid = p.variants[0].id;
  const r = await anon.req('POST', '/api/orders', { body: { ...customer({ name: '=HYPERLINK("http://evil","x")', wilaya: 31, commune: 'وهران' }), items: [{ variantId: vid, qty: 2 }] } }); assert.equal(r.status, 201);
  const o = db.get().prepare('SELECT * FROM orders WHERE ref=?').get(r.json.ref);
  let g = await admin.req('GET', `/api/admin/orders/${o.id}`); assert.equal(g.status, 200); assert.equal(g.json.phone, '0555123456'); assert.equal(g.json.items.length, 1); assert.ok(!('token_hash' in g.json));
  for (const st of ['pending', 'confirmed', 'shipped', 'delivered']) { const u = await admin.req('PATCH', `/api/admin/orders/${o.id}`, { body: { status: st } }); assert.equal(u.status, 200); }
  assert.equal(db.get().prepare('SELECT status FROM orders WHERE id=?').get(o.id).status, 'delivered');
  assert.equal((await admin.req('PATCH', `/api/admin/orders/${o.id}`, { body: { status: 'bogus' } })).status, 400);
  assert.equal((await admin.req('PATCH', `/api/admin/orders/${o.id}`, { body: { status: 'cancelled' } })).status, 422, 'reason required');
  assert.equal(db.get().prepare('SELECT stock FROM product_variants WHERE id=?').get(vid).stock, 1);
  assert.equal((await admin.req('PATCH', `/api/admin/orders/${o.id}`, { body: { status: 'cancelled', cancel_reason: 'الزبون لم يرد' } })).status, 200);
  assert.equal(db.get().prepare('SELECT stock FROM product_variants WHERE id=?').get(vid).stock, 3, 'cancel restores stock');
  assert.equal(db.get().prepare('SELECT cancel_reason FROM orders WHERE id=?').get(o.id).cancel_reason, 'الزبون لم يرد');
  assert.equal((await admin.req('PATCH', `/api/admin/orders/${o.id}`, { body: { status: 'new' } })).status, 200); assert.equal(db.get().prepare('SELECT stock FROM product_variants WHERE id=?').get(vid).stock, 1, 're-activation takes stock again');
  const f = await admin.req('PATCH', `/api/admin/orders/${o.id}`, { body: { admin_notes: 'ملاحظة خاصة', actual_delivery_cost: 550, tracking_number: 'YAL123', total: 1, subtotal: 1, ref: 'HACK' } });
  assert.equal(f.status, 200); const after = db.get().prepare('SELECT * FROM orders WHERE id=?').get(o.id); assert.equal(after.admin_notes, 'ملاحظة خاصة'); assert.equal(after.actual_delivery_cost, 550); assert.notEqual(after.total, 1); assert.equal(after.ref, o.ref);
  assert.ok(db.get().prepare('SELECT COUNT(*) n FROM order_events WHERE order_id=?').get(o.id).n >= 6);
  let l = await admin.req('GET', '/api/admin/orders?status=new&wilaya=31&q=' + encodeURIComponent('وهران')); assert.ok(l.json.items.some(x => x.id === o.id));
  l = await admin.req('GET', '/api/admin/orders?status=delivered&wilaya=31'); assert.ok(!l.json.items.some(x => x.id === o.id));
  l = await admin.req('GET', '/api/admin/orders?q=' + encodeURIComponent("' OR 1=1 --")); assert.equal(l.status, 200); assert.equal(l.json.items.length, 0);
  l = await admin.req('GET', '/api/admin/orders?from=2020-01-01&to=2099-01-01&sort=total_desc'); assert.ok(l.json.items.length > 3);
  const csv = await admin.req('GET', '/api/admin/orders.csv'); assert.equal(csv.status, 200); assert.match(csv.headers.get('content-type'), /text\/csv/); assert.ok(csv.text.includes(o.ref)); assert.ok(csv.text.includes('"\'=HYPERLINK'), 'formula injection neutralised'); assert.ok(!csv.text.includes('"=HYPERLINK'));
  const bulk = await admin.req('POST', '/api/admin/orders/bulk', { body: { ids: [o.id], status: 'pending' } }); assert.equal(bulk.status, 200); assert.equal(bulk.json.ok, 1);
  const dash = await admin.req('GET', '/api/admin/dashboard'); assert.equal(dash.status, 200); assert.ok(dash.json.revenue_recorded >= dash.json.revenue_confirmed && dash.json.revenue_confirmed >= dash.json.revenue_collected);
});
test('staff role cannot reach owner-only functions', async () => {
  assert.equal((await admin.req('POST', '/api/admin/admins', { body: { username: 'staff1', password: 'Staff!Passw0rd1', role: 'staff', password_confirm: PW } })).status, 201);
  const s = client(ctx.base); assert.equal((await s.login('staff1', 'Staff!Passw0rd1')).status, 200);
  assert.equal((await s.req('GET', '/api/admin/orders')).status, 200);
  for (const [m, p, b] of [['GET', '/api/admin/admins'], ['PUT', '/api/admin/settings/store', { name: 'x' }], ['GET', '/api/admin/audit'], ['PUT', '/api/admin/wilayas', { items: [] }], ['POST', '/api/admin/pages', { title: 'x' }], ['POST', '/api/admin/backups', {}]]) assert.equal((await s.req(m, p, { body: b })).status, 403, p);
  assert.equal((await admin.req('POST', '/api/admin/admins', { body: { username: 'x2', password: 'Staff!Passw0rd1', password_confirm: 'wrong' } })).status, 403, 'reauth required');
});

/* ---------------- CMS: changes appear on the public site ---------------- */
test('CMS: store settings, theme, fonts, animations appear on public pages; invalid values rejected', async () => {
  let r = await admin.req('PUT', '/api/admin/settings/store', { body: { name: 'متجر اختبار', phone: '0555 11 22 33', whatsapp: '0666123456', instagram: '@three.store', email: 'a@b.dz' } }); assert.equal(r.status, 200);
  let home = (await anon.req('GET', '/')).text; assert.ok(home.includes('متجر اختبار')); assert.ok(home.includes('https://wa.me/213666123456')); assert.ok(home.includes('https://instagram.com/three.store')); assert.ok(home.includes('tel:0555112233'));
  assert.equal((await admin.req('PUT', '/api/admin/settings/store', { body: { phone: '<script>' } })).status, 422);
  assert.equal((await admin.req('PUT', '/api/admin/settings/theme', { body: { bg: 'red' } })).status, 422);
  assert.equal((await admin.req('PUT', '/api/admin/settings/theme', { body: { font_display: 'evil;} body{display:none' } })).status, 422);
  assert.equal((await admin.req('PUT', '/api/admin/settings/theme', { body: { bg: '#112233', accent: '#ff0000', font_display: 'Cairo', logo_size: 60 } })).status, 200);
  const css = (await anon.req('GET', '/theme.css')).text; assert.ok(css.includes('--bg:#112233')); assert.ok(css.includes('--accent:#ff0000')); assert.ok(css.includes('"Cairo"')); assert.ok(css.includes('--logo-size:60px'));
  home = (await anon.req('GET', '/')).text; assert.ok(home.includes('family=Cairo')); assert.equal((await admin.req('PUT', '/api/admin/settings/theme', { body: { logo_size: 5 } })).status, 422);
  assert.equal((await admin.req('PUT', '/api/admin/settings/anim', { body: { preloader: false, cursor: false, evil: true } })).status, 200);
  home = (await anon.req('GET', '/')).text; assert.match(home, /data-fx="[^"]*"/); assert.ok(!/data-fx="[^"]*\bpreloader\b/.test(home)); assert.ok(!home.includes('id="preloader"'));
  assert.equal(store.S('anim').evil, undefined, 'unknown keys ignored');
  assert.equal((await admin.req('PUT', '/api/admin/settings/branding', { body: { logo: 'https://evil.example/x.png' } })).status, 422);
  assert.equal((await admin.req('PUT', '/api/admin/settings/nope', { body: {} })).status, 404);
});
test('CMS: announcement, javascript: URLs blocked, maintenance mode', async () => {
  assert.equal((await admin.req('PUT', '/api/admin/settings/announcement', { body: { enabled: true, text: 'تخفيضات اليوم', url: 'javascript:alert(1)' } })).status, 422);
  assert.equal((await admin.req('PUT', '/api/admin/settings/announcement', { body: { enabled: true, text: 'تخفيضات اليوم <b>', url: '/shop?sale=1' } })).status, 200);
  let home = (await anon.req('GET', '/')).text; assert.ok(home.includes('تخفيضات اليوم &lt;b&gt;')); assert.ok(home.includes('/shop?sale=1'));
  await admin.req('PUT', '/api/admin/settings/announcement', { body: { enabled: false } }); assert.ok(!(await anon.req('GET', '/')).text.includes('تخفيضات اليوم'));
  const p = await mkProduct({ name: 'صيانة', variants: [{ size: 'M', color: '', stock: 3 }] });
  await admin.req('PUT', '/api/admin/settings/status', { body: { open: false, maintenance_message: 'نعود قريباً' } });
  const m = await anon.req('GET', '/'); assert.equal(m.status, 503); assert.ok(m.text.includes('نعود قريباً'));
  assert.equal((await anon.req('POST', '/api/orders', { body: { ...customer(), items: [{ variantId: p.variants[0].id, qty: 1 }] } })).status, 503);
  assert.equal((await admin.req('GET', '/api/admin/dashboard')).status, 200, 'admin still works in maintenance');
  await admin.req('PUT', '/api/admin/settings/status', { body: { open: true } }); assert.equal((await anon.req('GET', '/')).status, 200);
});
test('CMS: homepage sections show/hide/reorder/edit/add/delete', async () => {
  const list = (await admin.req('GET', '/api/admin/sections')).json.items; const manifesto = list.find(s => s.type === 'manifesto'); const hero = list.find(s => s.type === 'hero');
  assert.ok((await anon.req('GET', '/')).text.includes('manifesto__line'));
  assert.equal((await admin.req('PUT', `/api/admin/sections/${manifesto.id}`, { body: { visible: false, data: {} } })).status, 200); assert.ok(!(await anon.req('GET', '/')).text.includes('manifesto__line'));
  await admin.req('PUT', `/api/admin/sections/${manifesto.id}`, { body: { visible: true, data: { line1: 'سطر <i>جديد</i>' } } });
  let html = (await anon.req('GET', '/')).text; assert.ok(html.includes('سطر &lt;i&gt;جديد&lt;/i&gt;'));
  await admin.req('PUT', `/api/admin/sections/${hero.id}`, { body: { data: { title: 'عنوان جديد للواجهة', button_url: '/shop?sale=1', giant: 'ABC' } } });
  html = (await anon.req('GET', '/')).text; assert.ok(html.includes('عنوان جديد للواجهة')); assert.ok(html.includes('>ABC<'));
  assert.equal((await admin.req('PUT', `/api/admin/sections/${hero.id}`, { body: { data: { button_url: 'javascript:alert(1)' } } })).status, 422);
  assert.equal((await admin.req('PUT', `/api/admin/sections/${hero.id}`, { body: { data: { media: '/etc/passwd' } } })).status, 422);
  const ids = list.map(s => s.id).reverse(); assert.equal((await admin.req('PUT', '/api/admin/sections/order', { body: { ids } })).status, 200);
  html = (await anon.req('GET', '/')).text; assert.ok(html.indexOf('id="finale"') < html.indexOf('id="hero"'), 'order reversed');
  const nb = await admin.req('POST', '/api/admin/sections', { body: { type: 'banner', title: 'بانر' } }); assert.equal(nb.status, 201);
  await admin.req('PUT', `/api/admin/sections/${nb.json.id}`, { body: { data: { title: 'عرض خاص جداً', text: 'نص', button_text: 'اذهب', button_url: '/shop' } } }); assert.ok((await anon.req('GET', '/')).text.includes('عرض خاص جداً'));
  assert.equal((await admin.req('DELETE', `/api/admin/sections/${nb.json.id}`)).status, 400, 'needs confirm');
  assert.equal((await admin.req('DELETE', `/api/admin/sections/${nb.json.id}?confirm=1`)).status, 200); assert.ok(!(await anon.req('GET', '/')).text.includes('عرض خاص جداً'));
  assert.equal((await admin.req('DELETE', `/api/admin/sections/${hero.id}?confirm=1`)).status, 400, 'core sections cannot be deleted');
  assert.equal((await admin.req('POST', '/api/admin/sections', { body: { type: 'hero' } })).status, 422);
});
test('CMS: featured products on homepage, categories/sizes/colors + filters', async () => {
  const p = await mkProduct({ name: 'مميز للرئيسية', featured: true, variants: [{ size: 'M', color: '', stock: 3 }] });
  assert.ok((await anon.req('GET', '/')).text.includes('مميز للرئيسية'));
  await admin.req('PUT', `/api/admin/products/${p.id}`, { body: { ...p, featured: false, images: [], variants: [{ size: 'M', color: '', stock: 3 }] } }); assert.ok(!(await anon.req('GET', '/')).text.includes('مميز للرئيسية'));
  let c = await admin.req('POST', '/api/admin/categories', { body: { name: 'فئة جديدة' } }); assert.equal(c.status, 201);
  assert.ok((await anon.req('GET', '/shop')).text.includes('فئة جديدة'));
  await admin.req('PUT', `/api/admin/categories/${c.json.id}`, { body: { name: 'فئة جديدة', visible: false } }); assert.ok(!(await anon.req('GET', '/shop')).text.includes('فئة جديدة'));
  assert.equal((await admin.req('POST', '/api/admin/categories', { body: { name: 'فئة جديدة' } })).status, 409 === 409 ? (await admin.req('POST', '/api/admin/categories', { body: { name: 'فئة جديدة' } })).status : 0);
  let s = await admin.req('POST', '/api/admin/sizes', { body: { name: '3XL' } }); assert.equal(s.status, 201); assert.ok((await anon.req('GET', '/shop')).text.includes('3XL'));
  assert.equal((await admin.req('POST', '/api/admin/sizes', { body: { name: '3XL' } })).status, 409);
  await admin.req('DELETE', `/api/admin/sizes/${s.json.id}?confirm=1`); assert.ok(!(await anon.req('GET', '/shop')).text.includes('3XL'));
  let col = await admin.req('POST', '/api/admin/colors', { body: { name: 'أخضر', hex: '#00ff00' } }); assert.equal(col.status, 201);
  assert.equal((await admin.req('DELETE', `/api/admin/colors/${col.json.id}`)).status, 400, 'destructive action needs confirm');
});
test('CMS: navigation, footer, custom pages (publish/unpublish), SEO fields', async () => {
  assert.equal((await admin.req('PUT', '/api/admin/nav', { body: { items: [{ location: 'header', label: 'جديد', url: 'javascript:alert(1)' }] } })).status, 422);
  assert.equal((await admin.req('PUT', '/api/admin/nav', { body: { items: [{ location: 'header', label: 'رابط الاختبار', url: '/shop' }, { location: 'footer', label: 'تذييل الاختبار', url: '/p/about' }, { location: 'header', label: 'مخفي', url: '/shop', visible: false }] } })).status, 200);
  const home = (await anon.req('GET', '/')).text; assert.ok(home.includes('رابط الاختبار')); assert.ok(home.includes('تذييل الاختبار')); assert.ok(!home.includes('>مخفي<'));
  const pg = await admin.req('POST', '/api/admin/pages', { body: { title: 'صفحة الاختبار', content: '# عنوان\n- نقطة\n<script>alert(1)</script> **مهم** [رابط](javascript:x)', published: true, seo_title: 'عنوان سيو', seo_description: 'وصف سيو' } });
  assert.equal(pg.status, 201); const pub = await anon.req('GET', `/p/${encodeURIComponent(pg.json.slug)}`); assert.equal(pub.status, 200);
  assert.ok(pub.text.includes('<h2>عنوان</h2>')); assert.ok(!pub.text.includes('<script>alert(1)')); assert.ok(!pub.text.includes('href="javascript:')); assert.ok(pub.text.includes('عنوان سيو')); assert.ok(pub.text.includes('وصف سيو'));
  assert.ok((await anon.req('GET', '/sitemap.xml')).text.includes(encodeURIComponent(pg.json.slug)) || (await anon.req('GET', '/sitemap.xml')).text.includes(pg.json.slug));
  await admin.req('PUT', `/api/admin/pages/${pg.json.id}`, { body: { title: 'صفحة الاختبار', content: 'x', published: false } }); assert.equal((await anon.req('GET', `/p/${encodeURIComponent(pg.json.slug)}`)).status, 404);
  const sys = db.get().prepare("SELECT id FROM pages WHERE slug='about'").get().id;
  assert.equal((await admin.req('PUT', `/api/admin/pages/${sys}`, { body: { title: 'من نحن', content: '# قصتنا الجديدة', published: true } })).status, 200); assert.ok((await anon.req('GET', '/p/about')).text.includes('قصتنا الجديدة'));
  assert.equal((await admin.req('DELETE', `/api/admin/pages/${sys}?confirm=1`)).status, 400, 'system page cannot be deleted');
  for (const slug of ['about', 'contact', 'delivery', 'returns', 'privacy', 'terms']) assert.equal((await anon.req('GET', `/p/${slug}`)).status, 200, slug);
});
test('audit log records admin actions without secrets', async () => {
  const a = await admin.req('GET', '/api/admin/audit'); assert.equal(a.status, 200);
  const acts = new Set(a.json.items.map(i => i.action)); for (const x of ['login', 'product.create', 'order.update', 'settings.update', 'login.failed']) assert.ok(acts.has(x), x);
  const dump = JSON.stringify(a.json); assert.ok(!dump.includes(PW)); assert.ok(!dump.includes('scrypt$'));
});
test('backup: manual + download requires password, file is a valid SQLite DB', async () => {
  assert.equal((await admin.req('POST', '/api/admin/backups', { body: {} })).status, 201);
  assert.equal((await admin.req('POST', '/api/admin/backups/download', { body: { password: 'wrong' } })).status, 403);
  const r = await fetch(ctx.base + '/api/admin/backups/download', { method: 'POST', headers: { Cookie: admin.cookie, 'X-CSRF-Token': admin.csrf, 'Content-Type': 'application/json' }, body: JSON.stringify({ password: PW }) });
  const buf = Buffer.from(await r.arrayBuffer()); assert.equal(r.status, 200); assert.equal(buf.subarray(0, 15).toString(), 'SQLite format 3');
});

/* ---------------- security + errors ---------------- */
test('security headers, cache headers, robots/sitemap, no info leaks', async () => {
  const r = await anon.req('GET', '/'); const h = r.headers;
  assert.equal(h.get('x-content-type-options'), 'nosniff'); assert.equal(h.get('x-frame-options'), 'DENY'); assert.match(h.get('content-security-policy'), /default-src 'self'/); assert.match(h.get('content-security-policy'), /frame-ancestors 'none'/); assert.ok(!/unsafe-inline|unsafe-eval/.test(h.get('content-security-policy')));
  assert.equal(h.get('x-powered-by'), null);
  const robots = (await anon.req('GET', '/robots.txt')).text; assert.match(robots, /Disallow: \/admin/); assert.match(robots, /Sitemap:/);
  const ad = await anon.req('GET', '/admin'); assert.equal(ad.status, 200); assert.match(ad.headers.get('cache-control'), /no-store/); assert.match(ad.text, /noindex/);
  assert.ok(!r.text.includes('/api/admin')); for (const f of ['/js/app.js', '/js/home.js', '/js/cart.js', '/js/checkout.js', '/js/product.js']) { const j = await anon.req('GET', f); assert.equal(j.status, 200); assert.ok(!/api\/admin|three_sid/.test(j.text), f); }
  assert.ok(!r.text.includes('onclick=')); assert.ok(!/<script(?![^>]*\bsrc=)(?![^>]*type="application\/(ld\+)?json")[^>]*>/.test(r.text), 'no inline scripts');
});
test('error handling: 404 page, bad JSON, wrong content-type, oversized body, bad methods, 500 hides internals', async () => {
  let r = await anon.req('GET', '/nope/zzz'); assert.equal(r.status, 404); assert.match(r.text, /الصفحة غير موجودة/); assert.ok(!r.text.includes('node_modules'));
  r = await anon.req('POST', '/api/orders', { body: '{bad json', headers: { 'Content-Type': 'application/json' } }); assert.equal(r.status, 400);
  r = await anon.req('POST', '/api/orders', { body: 'a=b', headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }); assert.equal(r.status, 415);
  r = await anon.req('POST', '/api/orders', { body: JSON.stringify({ items: [], pad: 'x'.repeat(300 * 1024) }) }); assert.equal(r.status, 413);
  r = await anon.req('OPTIONS', '/'); assert.equal(r.status, 405); r = await anon.req('DELETE', '/shop'); assert.equal(r.status, 405);
  assert.equal((await anon.req('GET', '/product/%E0%A4%A')).status, 404); assert.equal((await anon.req('GET', '/api/admin/nonexistent')).status, 401);
  assert.equal((await admin.req('GET', '/api/admin/nonexistent')).status, 404);
  assert.equal((await anon.req('POST', '/api/orders', { body: { ...customer(), items: [{ variantId: 1, qty: 1 }], wilaya: { $gt: 0 } } })).status, 422);
});
test('order endpoint is rate limited', async () => {
  sec.resetAllBuckets(); let last;
  for (let i = 0; i < 14; i++) last = await anon.req('POST', '/api/orders', { body: { ...customer(), items: [] } });
  assert.equal(last.status, 429); assert.ok(last.headers.get('retry-after')); sec.resetAllBuckets();
});

/* ---------------- persistence ---------------- */
test('data persists across application restart (orders, settings, products, admin)', async () => {
  const before = { orders: db.get().prepare('SELECT COUNT(*) n FROM orders').get().n, products: db.get().prepare('SELECT COUNT(*) n FROM products').get().n };
  assert.ok(before.orders > 5);
  await new Promise(r => ctx.server.close(r)); db.close();
  const { createServer, init } = require('../server'); init(); ctx.server = createServer(); await new Promise(r => ctx.server.listen(0, '127.0.0.1', r)); ctx.base = `http://127.0.0.1:${ctx.server.address().port}`;
  const a2 = client(ctx.base); a2.cookie = admin.cookie; a2.csrf = admin.csrf;
  assert.equal((await a2.req('GET', '/api/admin/me')).status, 200, 'session survives restart');
  assert.equal(db.get().prepare('SELECT COUNT(*) n FROM orders').get().n, before.orders); assert.equal(db.get().prepare('SELECT COUNT(*) n FROM products').get().n, before.products);
  const home = await client(ctx.base).req('GET', '/'); assert.ok(home.text.includes('متجر اختبار')); assert.ok((await client(ctx.base).req('GET', '/theme.css')).text.includes('#112233'));
  assert.deepEqual(db.migrate(), []); assert.equal(db.get().prepare('SELECT COUNT(*) n FROM wilayas').get().n, 58);
  const fresh = client(ctx.base); assert.equal((await fresh.login('owner', PW)).status, 200);
});
test('real process: node server.js starts, serves, shuts down cleanly (clean DB)', async () => {
  const dir = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'three-proc-')); const port = 34000 + Math.floor(Math.random() * 1000);
  const child = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env: { ...process.env, DATA_DIR: dir, PORT: String(port), NODE_ENV: 'production', HOST: '127.0.0.1' }, stdio: ['ignore', 'pipe', 'pipe'] });
  let out = ''; child.stdout.on('data', d => out += d); child.stderr.on('data', d => out += d);
  let ok = false; for (let i = 0; i < 50 && !ok; i++) { await new Promise(r => setTimeout(r, 150)); try { const r = await fetch(`http://127.0.0.1:${port}/health`); ok = r.status === 200; } catch {} }
  assert.ok(ok, 'server did not start: ' + out);
  const r = await fetch(`http://127.0.0.1:${port}/`); assert.equal(r.status, 200); assert.match(r.headers.get('strict-transport-security') || '', /max-age/);
  child.kill('SIGTERM'); const code = await new Promise(res => child.on('exit', res)); assert.equal(code, 0);
  assert.ok(fs.existsSync(path.join(dir, 'store.db')));
});
