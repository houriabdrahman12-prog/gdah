'use strict';
const os = require('node:os');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

function setupEnv() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'three-test-'));
  process.env.DATA_DIR = dir; process.env.NODE_ENV = 'test'; process.env.PORT = '0';
  delete process.env.DB_FILE; delete process.env.UPLOAD_DIR; delete process.env.BACKUP_DIR; delete process.env.SITE_URL;
  return dir;
}

async function startApp() {
  const dir = setupEnv();
  const app = require('../server');
  app.init();
  const server = app.createServer();
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  return { dir, server, base, app };
}

function client(base) {
  const c = { cookie: '', csrf: '' };
  c.req = async (method, p, { body, headers = {}, raw, auth = true, form } = {}) => {
    const h = { ...headers };
    if (auth && c.cookie) h.Cookie = c.cookie;
    if (auth && c.csrf && method !== 'GET' && !h['X-CSRF-Token']) h['X-CSRF-Token'] = c.csrf;
    let payload;
    if (form) payload = form; else if (body !== undefined) { h['Content-Type'] = h['Content-Type'] || 'application/json'; payload = typeof body === 'string' ? body : JSON.stringify(body); }
    const r = await fetch(base + p, { method, headers: h, body: payload, redirect: 'manual' });
    const text = await r.text(); let json = null; try { json = JSON.parse(text); } catch {}
    return { status: r.status, headers: r.headers, text, json };
  };
  c.login = async (username, password, extra = {}) => {
    const r = await c.req('POST', '/api/admin/login', { body: { username, password, ...extra }, auth: false });
    if (r.status === 200 && r.json.ok) { c.cookie = r.headers.get('set-cookie').split(';')[0]; c.csrf = r.json.csrf; }
    return r;
  };
  return c;
}

function createAdmin(dir, username, password, extraEnv = {}) {
  return spawnSync(process.execPath, [path.join(__dirname, '..', 'scripts', 'create-admin.js')], { env: { ...process.env, DATA_DIR: dir, ADMIN_USERNAME: username, ADMIN_PASSWORD: password, ...extraEnv }, encoding: 'utf8' });
}

// 1x1 PNG
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
function multipart(files, fields = {}) {
  const b = '----testboundary' + Math.random().toString(16).slice(2); const parts = [];
  for (const [k, v] of Object.entries(fields)) parts.push(Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`));
  for (const f of files) { parts.push(Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="file"; filename="${f.name}"\r\nContent-Type: ${f.type || 'application/octet-stream'}\r\n\r\n`)); parts.push(f.data); parts.push(Buffer.from('\r\n')); }
  parts.push(Buffer.from(`--${b}--\r\n`));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${b}` };
}
module.exports = { startApp, client, createAdmin, PNG, multipart };
