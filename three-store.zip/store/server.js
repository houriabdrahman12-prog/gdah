'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const config = require('./src/config');
const db = require('./src/db');
const sec = require('./src/security');
const store = require('./src/store');
const views = require('./src/views');
const admin = require('./src/admin');
const { HttpError, json, html, send, redirect, readJson, serveFile, clientIp, isHttps } = require('./src/http');
const { esc, clampInt, str } = require('./src/util');

function baseUrl(req) {
  if (config.SITE_URL) return config.SITE_URL;
  const proto = isHttps(req) ? 'https' : 'http'; const host = String(req.headers.host || 'localhost').replace(/[^\w.\-:\[\]]/g, '');
  return `${proto}://${host}`;
}
const SEC_PUBLIC = sec.securityHeaders(false), SEC_ADMIN = sec.securityHeaders(true);

function sameOrigin(req) {
  const o = req.headers.origin; if (!o) return true;
  try { return new URL(o).host === req.headers.host; } catch { return false; }
}

async function publicApi(req, res, url) {
  const ip = clientIp(req); const p = url.pathname;
  if (req.method === 'POST' && (p === '/api/cart/quote' || p === '/api/orders')) {
    if (!sameOrigin(req)) throw new HttpError(403, 'Origin غير مسموح');
    const lim = sec.rateLimit((p === '/api/orders' ? 'order:' : 'quote:') + ip, p === '/api/orders' ? 12 : 240, p === '/api/orders' ? 3600_000 : 600_000);
    if (!lim.ok) throw new HttpError(429, 'طلبات كثيرة، حاول لاحقاً', { retryAfter: lim.retryAfter });
    const b = await readJson(req);
    if (!store.S('status').open) throw new HttpError(503, store.S('status').maintenance_message);
    if (p === '/api/cart/quote') return json(res, 200, store.quote(b.items, b.wilaya, b.method));
    const r = store.createOrder(b, req.headers['idempotency-key']);
    return json(res, r.duplicate ? 200 : 201, { ref: r.ref, token: r.token, url: `/order/${r.ref}?t=${r.token}` });
  }
  throw new HttpError(404, 'غير موجود');
}

function sitemap(base) {
  const d = db.get(); const urls = [['/', 1.0], ['/shop', 0.9]];
  for (const p of d.prepare("SELECT slug FROM products WHERE status='published'").all()) urls.push(['/product/' + p.slug, 0.8]);
  for (const p of d.prepare('SELECT slug FROM pages WHERE published=1').all()) urls.push(['/p/' + p.slug, 0.4]);
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(([u, pr]) => `<url><loc>${esc(base + u)}</loc><priority>${pr}</priority></url>`).join('\n')}\n</urlset>`;
}

async function route(req, res) {
  const url = new URL(req.url, 'http://x'); const p = url.pathname; const m = req.method;
  const ctx = { base: baseUrl(req), path: p };
  const isAdminArea = p === '/admin' || p.startsWith('/admin/') || p.startsWith('/api/admin');
  const headers = isAdminArea ? SEC_ADMIN : SEC_PUBLIC;
  const origWriteHead = res.writeHead.bind(res);
  res.writeHead = (status, h) => origWriteHead(status, { ...headers, ...(h || {}) });

  if (m !== 'GET' && m !== 'HEAD' && m !== 'POST' && m !== 'PUT' && m !== 'PATCH' && m !== 'DELETE') throw new HttpError(405, 'Method not allowed');

  if (p === '/health') { db.get().prepare('SELECT 1').get(); return json(res, 200, { ok: true }); }

  /* admin */
  if (p.startsWith('/api/admin')) return admin.handle(req, res, url);
  if (p === '/admin' || p === '/admin/') return html(res, 200, fs.readFileSync(path.join(config.PUBLIC_DIR, 'admin', 'index.html')), { 'X-Robots-Tag': 'noindex, nofollow' }, req);
  if (p.startsWith('/admin/')) { if (serveFile(req, res, path.join(config.PUBLIC_DIR, 'admin'), p.slice(7), { cache: 'no-cache', headers: { 'X-Robots-Tag': 'noindex' } })) return; throw new HttpError(404, 'Not found'); }

  /* static assets */
  if (p === '/theme.css') return send(res, 200, views.themeCss(), { 'Content-Type': 'text/css; charset=utf-8', 'Cache-Control': 'public, max-age=300' }, req);
  if (p.startsWith('/uploads/')) { if (serveFile(req, res, config.UPLOAD_DIR, p.slice(9), { cache: 'public, max-age=31536000, immutable' })) return; throw new HttpError(404, 'Not found'); }
  for (const dir of ['css', 'js', 'assets']) if (p.startsWith('/' + dir + '/')) { if (serveFile(req, res, path.join(config.PUBLIC_DIR, dir), p.slice(dir.length + 2), { cache: dir === 'assets' ? 'public, max-age=86400' : 'public, max-age=3600' })) return; throw new HttpError(404, 'Not found'); }
  if (p === '/favicon.ico') return redirect(res, store.S('branding').favicon || '/assets/logo.jpeg', 302);
  if (p === '/robots.txt') return send(res, 200, `User-agent: *\nDisallow: /admin\nDisallow: /api/\nDisallow: /cart\nDisallow: /checkout\nDisallow: /order/\nSitemap: ${ctx.base}/sitemap.xml\n`, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'public, max-age=3600' }, req);
  if (p === '/sitemap.xml') return send(res, 200, sitemap(ctx.base), { 'Content-Type': 'application/xml; charset=utf-8', 'Cache-Control': 'public, max-age=900' }, req);
  if (p === '/.well-known/security.txt') return send(res, 200, `Contact: ${store.S('store').email ? 'mailto:' + store.S('store').email : ctx.base + '/p/contact'}\nExpires: 2027-10-09T00:00:00.000Z\nPreferred-Languages: ar, en, fr\nCanonical: ${ctx.base}/.well-known/security.txt\n`, { 'Content-Type': 'text/plain; charset=utf-8' }, req);

  /* public API */
  if (p.startsWith('/api/')) return publicApi(req, res, url);

  /* storefront (GET only) */
  if (m !== 'GET' && m !== 'HEAD') throw new HttpError(405, 'Method not allowed');
  if (!store.S('status').open) return html(res, 503, views.messagePage(ctx, 503, 'المتجر مغلق مؤقتاً', store.S('status').maintenance_message), { 'Retry-After': '3600', 'Cache-Control': 'no-store' }, req);

  if (p === '/') return html(res, 200, views.homePage(ctx), { 'Cache-Control': 'no-cache' }, req);
  if (p === '/shop') { const q = {}; for (const k of ['q', 'category', 'size', 'color', 'min', 'max', 'sort', 'page', 'sale', 'new']) q[k] = str(url.searchParams.get(k) || '', 60); return html(res, 200, views.shopPage(ctx, q), { 'Cache-Control': 'no-cache' }, req); }
  let mm;
  if ((mm = p.match(/^\/product\/([^/]+)$/))) {
    let slug; try { slug = decodeURIComponent(mm[1]); } catch { throw new HttpError(404, 'Not found'); }
    const prod = store.getProductBySlug(slug); if (!prod) throw new HttpError(404, 'Not found');
    return html(res, 200, views.productPage(ctx, prod), { 'Cache-Control': 'no-cache' }, req);
  }
  if (p === '/cart') return html(res, 200, views.cartPage(ctx), { 'Cache-Control': 'no-store' }, req);
  if (p === '/checkout') return html(res, 200, views.checkoutPage(ctx), { 'Cache-Control': 'no-store' }, req);
  if ((mm = p.match(/^\/order\/([A-Z0-9-]{6,30})$/))) {
    const o = store.getOrderPublic(mm[1], url.searchParams.get('t'));
    if (!o) throw new HttpError(404, 'Not found');
    return html(res, 200, views.orderPage(ctx, o), { 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' }, req);
  }
  if ((mm = p.match(/^\/p\/([^/]+)$/))) {
    let slug; try { slug = decodeURIComponent(mm[1]); } catch { throw new HttpError(404, 'Not found'); }
    const pg = db.get().prepare('SELECT * FROM pages WHERE slug=? AND published=1').get(slug); if (!pg) throw new HttpError(404, 'Not found');
    return html(res, 200, views.contentPage(ctx, pg), { 'Cache-Control': 'no-cache' }, req);
  }
  throw new HttpError(404, 'Not found');
}

function errorResponse(req, res, e) {
  const status = e instanceof HttpError ? e.status : 500;
  if (status >= 500) console.error(`[${new Date().toISOString()}] ${req.method} ${String(req.url).split('?')[0]} →`, config.PRODUCTION ? e.message : e.stack);
  if (res.headersSent) return res.end();
  const url = String(req.url || ''); const wantsJson = url.startsWith('/api/') || (req.headers.accept || '').includes('application/json') && !(req.headers.accept || '').includes('text/html');
  const msg = status >= 500 ? 'حدث خطأ في الخادم' : e.message;
  const hdr = {}; if (e.extra && e.extra.retryAfter) hdr['Retry-After'] = e.extra.retryAfter;
  if (wantsJson) return json(res, status, { error: msg, ...(e.extra || {}) }, hdr, req);
  try { return html(res, status, views.messagePage({ base: baseUrl(req), path: '/' }, status, status === 404 ? 'الصفحة غير موجودة' : 'حدث خطأ', status === 404 ? 'الرابط الذي طلبته غير موجود أو تم نقله.' : msg), hdr, req); }
  catch { return send(res, status, msg, { 'Content-Type': 'text/plain; charset=utf-8' }); }
}

function createServer() {
  const server = http.createServer((req, res) => {
    route(req, res).catch(e => errorResponse(req, res, e));
  });
  server.requestTimeout = 60_000; server.headersTimeout = 20_000; server.keepAliveTimeout = 5_000;
  return server;
}

function init() {
  db.open(); db.migrate(); db.seed();
  fs.mkdirSync(config.UPLOAD_DIR, { recursive: true }); fs.mkdirSync(config.BACKUP_DIR, { recursive: true });
  store.appSecret();
}

function start() {
  init();
  const server = createServer();
  const sweep = setInterval(() => { sec.sweepBuckets(); try { sec.purgeSessions(); } catch {} }, 10 * 60 * 1000); sweep.unref();
  // Daily automatic backup (keeps last 14 daily files)
  const daily = setInterval(() => { try {
    const f = path.join(config.BACKUP_DIR, `daily-${new Date().toISOString().slice(0, 10)}.db`);
    if (!fs.existsSync(f)) db.backupTo(f);
    const olds = fs.readdirSync(config.BACKUP_DIR).filter(n => n.startsWith('daily-')).sort(); while (olds.length > 14) fs.unlinkSync(path.join(config.BACKUP_DIR, olds.shift()));
  } catch (e) { console.error('daily backup failed', e.message); } }, 60 * 60 * 1000); daily.unref();
  server.listen(config.PORT, config.HOST, () => console.log(`THREE store listening on http://${config.HOST}:${config.PORT} (${config.NODE_ENV})`));
  const stop = () => { console.log('shutting down…'); server.close(() => { db.close(); process.exit(0); }); setTimeout(() => process.exit(1), 8000).unref(); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
  process.on('unhandledRejection', (e) => console.error('unhandledRejection', e));
  return server;
}

if (require.main === module) start();
module.exports = { createServer, init, start, route };
