# Backup and restore

Everything important is in `DATA_DIR` (default `./data`; `/data` on Fly): `store.db` (orders, products, settings), `uploads/` (photos), `backups/`.

## What happens automatically
* A **daily backup** `backups/daily-YYYY-MM-DD.db` (last 14 kept) while the server runs.
* A backup **before every bulk action** (bulk order/product changes, delivery price bulk save, product deletes) → `backups/auto-*.db` (last 30 kept).
* A backup **before applying a database migration** → `backups/pre-migration-*.db`.
These live on the same disk, so they protect against mistakes, **not** against losing the server. Do the next step too.

## Off-server backup (do this weekly)
* Admin → **Backups → "Download a copy to my computer"** (asks your password). Keep the file private (it contains customer data).
* The photos in `uploads/` are not inside the .db file. On Fly: `fly ssh sftp shell` then `get -r /data/uploads` — or simply keep your original photos.
* Command line: `npm run backup` (writes a consistent copy using SQLite `VACUUM INTO`, safe while the store runs).

## Restore
1. **Stop the server** (Fly: `fly scale count 0`; VPS: `systemctl stop three-store`).
2. Put the backup file on the server (Fly: `fly ssh sftp shell` → `put store-backup.db /data/restore.db`).
3. Run: `node scripts/restore.js /data/restore.db` — it checks the file is a healthy store database, saves the current DB as `backups/before-restore-*.db`, then replaces it.
4. Start the server again (Fly: `fly scale count 1`) and check `/admin`.

Restoring `uploads/`: copy the folder contents back into `DATA_DIR/uploads/`.

## Retention suggestion
Keep order data as long as accounting/legal rules require; delete old customer data you no longer need (ask a professional about Algerian retention rules).
