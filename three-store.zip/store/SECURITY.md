# Security

## Implemented (and covered by automated tests unless noted)
* **Passwords**: scrypt (N=32768) with per-password salt; policy 12+ chars/3 classes; no default or hardcoded admin; no public registration route.
* **Sessions**: random 256-bit id in an `HttpOnly`, `SameSite=Strict`, `Secure` (production/HTTPS) cookie; only a SHA-256 hash is stored; 2h idle / 12h absolute expiry; invalidated on logout, password change, admin deactivation.
* **CSRF**: per-session token required on every admin write + same-origin (`Origin`) check; public JSON endpoints require `application/json`.
* **Brute force**: login limited per IP (10/15 min) and per username (5/15 min); order endpoint 12/hour/IP; uploads limited. (In-memory counters — reset on restart.)
* **Authorization**: every `/api/admin/*` route checks the session; owner-only routes check role; sensitive actions (password change, admin management, DB download) require the current password; optional TOTP 2-step login (RFC 6238, verified against the RFC vector).
* **Injection**: all SQL is parameterized; `LIKE` wildcards escaped; tested with SQL-injection strings. **XSS**: all output escaped server-side; admin UI builds DOM with `textContent` only; CSP forbids inline scripts/styles (`script-src 'self'`); user "markup" is escaped before formatting; `javascript:` URLs rejected.
* **Mass assignment**: settings/sections/products accept only allow-listed fields; order edits cannot change totals/ref.
* **Prices/stock**: the browser's prices/totals are ignored; server recomputes from the database; stock decremented atomically inside a `BEGIN IMMEDIATE` transaction (tested with concurrent orders); idempotency key prevents duplicate orders.
* **Uploads**: type determined by magic bytes (JPG/PNG/WebP/ICO, MP4/WebM only for hero video), SVG/HTML rejected, size limits, random server-side names, served only from a dedicated folder with traversal protection (tested). With `sharp`, images are re-encoded and EXIF stripped.
* **Customer privacy**: order confirmation pages need an unguessable per-order token (HMAC); `noindex`, `no-store`; admin data never embedded in public JS (tested); CSV export neutralises spreadsheet formulas.
* **Headers**: CSP, `X-Frame-Options: DENY`, `nosniff`, Referrer-Policy, Permissions-Policy, HSTS (production). Errors never leak stack traces in production.
* **Audit log** of admin actions; **backups** before bulk operations and migrations.

## Remaining risks / your responsibilities
* No software is "completely secure". This code has had an automated test review, **not an independent penetration test**.
* Use HTTPS only (hosts above provide it). Set `TRUST_PROXY=1` only behind a trusted proxy.
* Keep Node.js updated (security releases) and rebuild/redeploy regularly; run `npm audit` if you install `sharp`.
* Back up off-server; the backup file contains customer data — store it privately.
* Enable 2-step login on the owner account (Admin → My account).
* Rate limiting is per instance and in memory; a determined attacker with many IPs can still try passwords slowly — use a long unique password.
* Google Fonts are loaded from Google (privacy trade-off); self-host the fonts if that matters to you.
* Policy pages are templates, not legal advice. Check Algerian e-commerce/data-protection rules (e.g. Law 18-07 on personal data) with a professional.

Report a vulnerability: Admin → Settings → email, shown at `/.well-known/security.txt`.
